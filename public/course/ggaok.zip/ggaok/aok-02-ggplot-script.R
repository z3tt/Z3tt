################################################################################
#                                                                              #
#               Effektive Datenvisualisierung: Konzepte & Praxis               #
#                     Reproduzierbare Grafiken mit ggplot2                     #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                              16. Dezember 2025                               #
#                                                                              #
################################################################################


## Setup =======================================================================

# install.packages("ggplot2") # run once after installing R
library(ggplot2) # run every time you open R

ggplot() # a function
diamonds # a data set

pkgs <- c(
  "readr", "dplyr", "stringr", "forcats", "lubridate", "purrr", "scales",
  "colorspace", "systemfonts", "ggbeeswarm", "ggdist", "ggridges",
  "ggpointdensity", "ggdensity", "ggtext", "marquee", "ggrepel", "ggforce",
  "concaveman", "patchwork", "ggiraph", "scico", "rcartocolor", "remotes"
)
install.packages(setdiff(pkgs, rownames(installed.packages())))

remotes::install_github("AllanCameron/geomtextpath")

# to install the previous version of ggplot2:
# install.packages("remotes")
# remotes::install_version(
#   package = "ggplot2", version = "3.5.2", repos = "http://cran.us.r-project.org"
# )


## Data ========================================================================

# gapminder <- readr::read_csv("./data/gapminder-1950-2023.csv")
# gapminder <- readr::read_csv(file.path("data", "gapminder-1950-2023.csv"))
# gapminder <- readr::read_csv(here::here("data", "gapminder-1950-2023.csv"))
gapminder <- readr::read_csv("https://www.cedricscherer.com/data/gapminder-1950-2023.csv")


## A Basic ggplot ==============================================================

# ?ggplot

ggplot(data = gm_2023)

ggplot(data = gm_2023) +
  aes(x = gdp_pcap, y = life_exp)

# ggplot(data = gm_2023) + aes(x = gdp_pcap, y = life_exp)
# ggplot(data = gm_2023, mapping = aes(x = gdp_pcap, y = life_exp))
# ggplot(gm_2023, aes(gdp_pcap, life_exp))
# ggplot(data = gm_2023, aes(x = gdp_pcap, y = life_exp))

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_hex()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_text(
    aes(label = country)
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_smooth()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  stat_smooth()

ggplot(gm_2023, aes(x = gdp_pcap, y = life_exp)) +
  geom_point(stat = "identity") # default

ggplot(gm_2023, aes(x = gdp_pcap, y = life_exp)) +
  stat_identity(geom = "point") # default

ggplot(gm_2023, aes(x = continent)) +
  geom_bar(stat = "count") # default

ggplot(gm_2023, aes(x = continent)) +
  stat_count(geom = "bar") # default

ggplot(gm_2023, aes(x = gdp_pcap, y = life_exp)) +
  geom_smooth(stat = "smooth") # default

ggplot(gm_2023, aes(x = gdp_pcap, y = life_exp)) +
  stat_smooth(geom = "smooth") # default

ggplot(gm_2023, aes(x = gdp_pcap, y = life_exp)) +
  stat_smooth(geom = "pointrange")

ggplot(gm_2023, aes(x = continent)) +
  stat_count(geom = "text", aes(label = after_stat(count)))

ggplot(
  data = gm_2023,
  aes(
    x = income_daily,
    y = region
  )
) +
  geom_boxplot(
    outliers = FALSE # ggplot2 v4
  ) +
  geom_point(
    position = position_identity(), # or "identity"
    alpha = .3
  )

ggplot(
  data = gm_2023,
  aes(
    x = income_daily,
    y = region
  )
) +
  geom_boxplot(
    outliers = FALSE # ggplot2 v4
  ) +
  geom_point(
    position = position_jitter(),
    alpha = .3
  )

ggplot(
  data = gm_2023,
  aes(
    x = income_daily,
    y = region
  )
) +
  geom_boxplot(
    outliers = FALSE # ggplot2 v4
  ) +
  geom_point(
    position = position_jitter(
      height = .2,
      seed = 2025
    ),
    alpha = .3
  )

ggplot(
  data = gm_2023,
  aes(
    x = income_daily,
    y = region
  )
) +
  geom_boxplot(
    width = .4,
    position = position_nudge(y = -.1),
  ) +
  geom_point(
    position = position_nudge(y = .25),
    alpha = .3
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      color = continent,
      size = pop
    )
  )

ggplot(
  data = gm_2023,
  aes(
    x = log10(gdp_pcap),
    y = scales::rescale(life_exp)
  )
) +
  geom_point(
    aes(
      color = continent,
      size = pop
    )
  )

ggplot(
  data = gm_2023,
  aes(
    x = scales::rescale(income_daily),
    y = forcats::fct_reorder(region, -income_daily)
  )
) +
  geom_boxplot(
    width = .4,
    position = position_nudge(y = -.1),
  ) +
  geom_point(
    position = position_nudge(y = .25),
    alpha = .3
  )

ggplot(
  data = gm_2023,
  aes(
    x = scales::rescale(income_daily),
    y = forcats::fct_reorder(region, income_daily, .fun = max)
  )
) +
  geom_boxplot(
    width = .4,
    position = position_nudge(y = -.1),
  ) +
  geom_point(
    position = position_nudge(y = .25),
    alpha = .3
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      color = pop >= 10^8,
      size = pop
    ),
    alpha = .5
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      color = continent != "Europe",
      size = pop
    ),
    alpha = .5
  )

ggplot(
  data = gm_2023,
  aes(
    x = gdp_pcap, y = life_exp,
    color = continent,
    size = pop
  )
) +
  geom_point(
    alpha = .5
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "GDP per capita (int$)",
    y = "Life expectancy at birth (years)",
    color = "Continent:",
    size = "Population:"
  )

ggplot(
  data = gm_2023,
  aes(
    x = gdp_pcap, y = life_exp,
    color = continent,
    size = pop
  )
) +
  geom_point(
    alpha = .5
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = NULL,
    y = "Life expectancy at birth (years)",
    color = NULL,
    size = "Population:"
  )

ggplot(
  data = gm_2023,
  aes(
    x = gdp_pcap, y = life_exp,
    color = continent,
    size = pop
  )
) +
  geom_point(
    alpha = .5
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "",
    y = "Life expectancy at birth (years)",
    color = NULL,
    size = "Population:"
  )

g1 <-
  ggplot(
    data = gm_2023,
    aes(x = gdp_pcap, y = life_exp)
  ) +
  geom_point(
    aes(
      color = continent,
      size = pop
    ),
    alpha = .7
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "GDP per capita (int$)",
    y = "Life expectancy (years)",
    color = NULL,
    size = "Population:"
  )

g1 + geom_smooth()


## Scales ======================================================================

g1 +
  # default scales:
  # x ⇄ gdp_pcap
  scale_x_continuous() +
  # y ⇄ life_exp
  scale_y_continuous() +
  # color ⇄ continent
  scale_color_discrete() +
  # size ⇄ pop
  scale_size()

g1 +
  geom_smooth(method = "lm") +
  scale_x_log10()

g1 +
  geom_smooth(method = "lm") +
  coord_transform(x = "log10") # coord_trans in ggplot v3

ggplot(
  data = gm_2023,
  aes(x = continent, y = life_exp)
) +
  geom_boxplot() +
  scale_y_continuous(limits = c(70, NA))

ggplot(
  data = gm_2023,
  aes(x = continent, y = life_exp)
) +
  geom_boxplot() +
  coord_cartesian(ylim = c(70, NA))

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = c("#00D9EE", "#4CF101", "#FF4670", "#FFE702", "#CA4ADC")
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = c(Africa = "#00D9EE", Americas = "#4CF101", Asia = "#FF4670", Europe = "#FFE702", Oceania = "#CA4ADC")
  )

pal <- c(Africa = "#00D9EE", Americas = "#4CF101", Asia = "#FF4670", Europe = "#FFE702", Oceania = "#CA4ADC")

pal_dark <- colorspace::darken(pal, .2)
pal_dark

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = pal_dark
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = pal_dark
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(
      scale = 1 / 10^6,
      suffix = "M"
    )
  )

g2 <- g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = pal_dark
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(
      scale = 1 / 10^6,
      suffix = "M"
    )
  )

ggplot(
  data = gm_2023,
  aes(
    x = income_daily,
    y = forcats::fct_reorder(region, -income_daily)
  )
) +
  geom_boxplot(
    width = .4,
    position = position_nudge(y = -.1),
  ) +
  geom_point(
    position = position_nudge(y = .25),
    alpha = .3
  ) +
  scale_y_discrete(
    labels = scales::label_wrap(16),
    name = NULL
  ) +
  theme(
    axis.text.y = element_text(hjust = 0)
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      color = continent != "Europe",
      size = pop
    ),
    alpha = .5
  ) +
  scale_x_log10() +
  scale_color_discrete(
    labels = c("European countries", "Other countries"),
    name = NULL
  )

## Theming =====================================================================

g2 + theme_grey() # or theme_gray()

g2 + theme_classic()

g2 + theme_bw()

g2 + theme_light()

g2 + theme_minimal()

g2 +
  theme_light(
    base_size = 10, # default is 11
    base_family = "Verdana"
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Georgia"
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Verdana",
    header_family = "Georgia", # ggplot v4
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Verdana",
    header_family = "Georgia", # ggplot v4
    paper = "#F8F8F8", # ggplot v4
    ink = "turquoise4" # ggplot v4
  )

g2 +
  geom_smooth() +
  theme_light(
    base_size = 13,
    base_family = "Verdana",
    header_family = "Georgia", # ggplot v4
    paper = "#F8F8F8",
    ink = "turquoise4", # ggplot v4
    accent = "darkorange" # ggplot v4
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Verdana"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(
      face = "bold"
    ),
    plot.title.position = "plot",
    plot.caption.position = "plot",
    panel.background = element_rect(
      fill = "#F8F8F8", color = NA
    )
  )

set_theme(theme_light())
# theme_set(theme_light()) in ggplot2 v3

g2

set_theme(theme_light(
  base_size = 13,
  base_family = "Verdana"
))

g2

update_theme( # theme_update() in ggplot2 v3
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  plot.caption.position = "plot",
  panel.background = element_rect(
    fill = "#F8F8F8", color = NA
  )
)

g2

update_theme(
  geom = element_geom( # ggplot v4
    pointsize = 2.5,
    pointshape = 4,
    borderwidth = 1
  ),
  palette.color.continuous = scico::scico(20, palette = "devon", end = .75, direction = -1), # ggplot v4
  palette.fill.continuous = rcartocolor::carto_pal(20, name = "Emrld"), # ggplot v4
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  plot.caption.position = "plot",
  panel.background = element_rect(
    fill = "#F8F8F8", color = NA
  )
)

ggplot(
  data = gm_2023,
  aes(x = continent, y = life_exp)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = fertility),
    width = .2
  )

ggplot(
  data = gm_2023,
  aes(x = continent, y = life_exp)
) +
  geom_boxplot() +
  geom_jitter(
    aes(fill = fertility),
    shape = 21, width = .2
  )

update_theme(
  geom = element_geom( # ggplot v4
    pointsize = (13 / 11) * 1.5,
    pointshape = 16,
    borderwidth = 13 / 22
  ),
  palette.color.continuous = scico::scico(20, palette = "devon", end = .75, direction = -1), # ggplot v4
  palette.fill.continuous = scico::scico(20, palette = "devon", end = .75, direction = -1), # ggplot v4
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  plot.caption.position = "plot",
  panel.background = element_rect(
    fill = "#F8F8F8", color = NA
  )
)


## Exciting Chart Types ========================================================

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  geom_boxplot()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(priority = "descending")

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(side = -1)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(method = "hex", size = 1.5, cex = 2)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_quasirandom()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_quasirandom(method = "smiley")

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggforce::geom_sina(jitter_y = FALSE)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  geom_violin(trim = FALSE, scale = "count") +
  ggforce::geom_sina(scale = "count", maxwidth = .75, jitter_y = FALSE)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_eye()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye() ## default: `.width = c(.66, .95)`

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = .5)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = c(0, 1))

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = c(0, 1), adjust = .5, shape = 23, point_size = 5)

ggplot(
  subset(gm_compare, year %in% c(1980, 2000, 2020)),
  aes(x = factor(year), y = life_exp, fill = continent)
) +
  ggdist::stat_halfeye(.width = 0, adjust = .5, slab_alpha = .5, shape = 21) +
  scale_fill_manual(values = c("#DB4706", "#069ADB"), name = NULL)

ggplot(
  subset(gapminder, year %in% c(1980, 2000, 2020)),
  aes(x = factor(year), y = life_exp)
) +
  ggbeeswarm::geom_beeswarm(side = -1, color = "grey60", cex = 1.1) +
  ggdist::stat_halfeye(.width = 0, adjust = .4, slab_alpha = .5, shape = 23, scale = .5, position = position_nudge(x = .02))

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25, linewidth = 10) +
  scale_color_viridis_d(option = "rocket", direction = -1, end = .9)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25) +
  ggdist::stat_dots(position = position_nudge(x = .05), scale = .8) +
  scale_color_viridis_d(option = "rocket", direction = -1, end = .9)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25) +
  ggdist::stat_halfeye(.width = 0, color = "white", position = position_nudge(x = .025)) +
  scale_color_viridis_d(option = "rocket", direction = -1, end = .9)

ggplot(gm_2023, aes(x = life_exp, y = continent)) +
  ggridges::geom_density_ridges()

ggplot(
  gm_compare,
  aes(x = fertility, y = factor(year), fill = continent)
) +
  ggridges::geom_density_ridges(
    alpha = .5
  ) +
  scale_y_discrete(limits = rev)

ggplot(
  data = gm_compare,
  aes(x = fertility, y = factor(year), fill = continent)
) +
  ggridges::geom_density_ridges(
    alpha = .5,
    color = "transparent",
    scale = 1.5
  ) +
  scale_y_discrete(limits = rev) +
  scale_fill_manual(
    values = c("#DB4706", "#069ADB"),
    name = NULL
  )

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_point(size = 3, alpha = .5)

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_point(size = 3, alpha = .05)

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  ggpointdensity::geom_pointdensity(size = 2)

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  ggpointdensity::geom_pointdensity(size = 2, adjust = .5) +
  scale_color_gradient(low = "#FFCE52", high = "#663399")

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_point(alpha = .02, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines()

ggplot(gm_compare, aes(x = life_exp, y = fertility, color = continent)) +
  geom_point(alpha = .1, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines() +
  scale_color_manual(values = c("#DB4706", "#069ADB"), name = NULL)

ggplot(gm_compare, aes(x = life_exp, y = fertility, color = factor(continent))) +
  geom_point(alpha = .1, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines(method = "mvnorm", probs = c(.95, .75, .5, .25, .1)) +
  scale_color_manual(values = c("#DB4706", "#069ADB"), name = NULL)

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_density_2d_filled() +
  coord_cartesian(expand = FALSE) +
  ggtitle("geom_density_2d_filled()") +
  theme(plot.title = element_text(face = "bold"), legend.position = "top")

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  ggdensity::geom_hdr(probs = seq(.999, .2, length.out = 5)) +
  coord_cartesian(expand = FALSE) +
  ggtitle("ggdensity::geom_hdr()") +
  theme(plot.title = element_text(face = "bold"), legend.position = "top")


## Working with Text ===========================================================

## Text Rendering

g2 <-
  g2 +
  scale_color_discrete(
    type = c(Africa = "#0E93A1", Americas = "#30A300", Asia = "#C30044", Europe = "#AC9C08", Oceania = "#981AA7"),
    guide = "none"
  ) +
  theme(legend.justification = "top")

library(ggtext)

g2 +
  labs(
    x = "**Per-capita GDP** *(log scale)*",
    y = "**Life expectancy** *in years*",
    subtitle = "Comparing key country-level metrics across continents: <b style='color:#0E93A1'>Africa</b> &#x2055; <b style='color:#30A300'>Americas</b> &#x2055; <b style='color:#C30044'>Asia</b> &#x2055; <b style='color:#AC9C08'>Europe</b> &#x2055; <b style='color:#981AA7'>Oceania</b>",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.subtitle = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )

g2 +
  labs(
    x = "**Per-capita GDP** *(log scale)*",
    y = "**Life expectancy** *in years*",
    subtitle = "Comparing key country-level metrics across continents: <b style='color:#0E93A1'>Africa</b> &#x2055; <b style='color:#30A300'>Americas</b> &#x2055; <b style='color:#C30044'>Asia</b> &#x2055; <b style='color:#AC9C08'>Europe</b> &#x2055; <b style='color:#981AA7'>Oceania</b>",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.subtitle = element_textbox_simple(
      fill = "white",
      box.colour = "#292929",
      linetype = "solid",
      padding = margin(8, 12, 6, 12),
      margin = margin(b = 12),
    ),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )

g2 +
  geom_richtext(
    aes(
      label = "My <b style='color:#28a87d;'>fancy</b><br>annotation",
      x = 2000, y = 83
    ),
    family = "Georgia"
  )

g2 +
  marquee::geom_marquee(
    data = subset(gm_2023, country %in% c("China", "India")),
    aes(label = paste0("{.firebrick **", country, ",  \n*", pop / 10^9, " Billion***}")),
    color = "black", size = 3.5, vjust = c(-.9, 2.1), hjust = c(-.1, .1)
  )

md_title <- "## Gapminder {.red 2023}"

g2 +
  labs(title = md_title) +
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc"), size = rel(.9)
    )
  )

md_title <- "## Gapminder {.red 2023}"

md_caption <- "#### Data source: Gapminder Project

---

The visualization shows

1. _life expectancy_ on the `y-axis`

2. _GDP per-capita_ on the `x-axis` with a **log scale**, and

3. _population size_ encoded by `area` of the points.
"

g2 +
  labs(title = md_title, caption = md_caption) +
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc"), size = rel(.9)
    ),
    plot.caption = marquee::element_marquee(
      width = unit(1, "npc"), size = rel(.7), margin = margin(t = 20)
    )
  )


## Clever Annotations

g2 +
  ggrepel::geom_label_repel(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    )
  )

g2 +
  ggrepel::geom_label_repel(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE
  )

g2 +
  ggrepel::geom_label_repel(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Verdana",
    ylim = 86,
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))

g2 +
  geom_point(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Verdana",
    ylim = c(86, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))

g2 +
  geom_point(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = subset(gm_2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Verdana",
    ylim = c(86, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))

g2 +
  ggforce::geom_mark_ellipse(
    aes(
      label = continent,
      color = continent
    )
  ) +
  theme(legend.position = "none")

g2 +
  ggforce::geom_mark_ellipse(
    aes(
      label = continent,
      color = continent
    )
  ) +
  scale_y_continuous(
    expand = expansion(mult = 1.3)
  ) +
  theme(legend.position = "none")

g2 +
  ggforce::geom_mark_rect(
    aes(
      label = continent,
      color = continent
    )
  ) +
  scale_y_continuous(
    expand = expansion(mult = 1.3)
  ) +
  theme(legend.position = "none")

g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      color = continent,
      filter = country == "India"
    )
  )

g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      filter = country == "India"
    ),
    alpha = .5,
    linewidth = 1,
    expand = unit(24, "pt"),
    description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    label.family = c("Verdana", "Georgia"),
    con.cap = unit(1, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )

g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      group = country,
      filter = country %in% c("India", "China")
    ),
    alpha = .5,
    size = 1,
    expand = unit(24, "pt"),
    label.family = "Verdana",
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )

g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      group = country,
      filter = country %in% c("India", "China")
    ),
    alpha = .5,
    size = 1,
    expand = unit(24, "pt"),
    label.family = "Verdana",
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )

gm_trends <- subset(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geom_line(
    linewidth = 1
  )

gm_trends <- subset(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geom_line(
    linewidth = 1
  ) +
  geom_text(
    data = subset(gm_trends, year == 2023),
    aes(label = country),
    family = "Verdana",
    fontface = "bold",
    vjust = -.5,
    hjust = 1
  ) +
  theme(legend.position = "none")

gm_trends <- subset(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Verdana",
    fontface = "bold"
  ) +
  theme(legend.position = "none")

gm_trends <- subset(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Verdana",
    fontface = "bold",
    hjust = 0,
    vjust = -.1,
    halign = "left"
  ) +
  theme(legend.position = "none")


## Working with Images =========================================================

logo <- "![](img/AOK-2021.png)"

g2 +
  labs(caption = logo) +
  theme(
    plot.caption = marquee::element_marquee(
      width = unit(.3, "npc")
    )
  )

library(marquee)

logo <- "![](img/AOK-2021.png) Baden-Württemberg"

g2 +
  labs(caption = logo) +
  theme(
    plot.caption = marquee::element_marquee(
      size = 12, margin = margin(20, 0, 0, 0)
    )
  )

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  annotate(
    geom = GeomMarquee,
    label = "![](img/AOK-2021.png)",
    x = 5,
    y = 83,
    width = .3
  ) +
  geom_point()

mid <- function(x) (min(x, na.rm = TRUE) + max(x, na.rm = TRUE)) / 2

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  annotate(
    geom = GeomMarquee,
    label = "![](img/AOK-2021.png)",
    x = mid(gm_2023$fertility),
    y = mid(gm_2023$life_exp),
    width = .9
  ) +
  geom_point()

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  annotate(
    geom = GeomMarquee,
    label = "![](img/AOK-2021.png)",
    x = min(gm_2023$fertility, na.rm = TRUE),
    y = min(gm_2023$life_exp, na.rm = TRUE),
    size.unit = "pt",
    width = .9,
    hjust = "left",
    vjust = "bottom"
  ) +
  geom_point()


## Working with Multi-Plot Composition =========================================

g1 <-
  ggplot(
    data = gm_2023,
    aes(x = continent, y = life_exp)
  ) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = continent),
    width = .2, alpha = .5
  ) +
  scale_color_manual(values = pal_dark, guide = "none") +
  labs(x = NULL, y = "Life expectancy\nin years")

g3 <-
  ggplot(
    data = gm_2023,
    aes(x = continent, y = gdp_pcap)
  ) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = continent),
    width = .2, alpha = .5
  ) +
  scale_color_manual(values = pal_dark, guide = "none") +
  labs(x = NULL, y = "GDP per capita\nin int$")

library(patchwork)
g2 / (g1 + g3)

(g2 / (g1 + g3)) +
  plot_layout(heights = c(.25, .1))

g2 + plot_spacer() + g1 + g3 +
  plot_layout(widths = c(1.5, .5, 1, 1))

picasso <- "
#AAAAAAAA#
#AAAAAAAA#
BBBBB##CCC"
g2 + g1 + g3 + plot_layout(design = picasso)

g2 + g1 + g3 + plot_layout(design = picasso) +
  plot_annotation(tag_levels = "1", tag_prefix = "P", title = "An overarching title for all 3 plots, placed on the very top — the other chart title sits below the tag.")

(g2 + labs(caption = NULL)) + g1 + g3 + plot_layout(design = picasso) +
  plot_annotation(tag_levels = "a", tag_prefix = "(", tag_suffix = ")", caption = "Source: Gapminder project", title = "An overarching title for all 3 plots, placed on the very top — the other chart title sits below the tag.")

g2 + inset_element(g1, l = .6, b = .05, r = .97, t = .4)

g2 + inset_element(g1, l = .6, b = 0, r = 1, t = .5, align_to = "full")


## Working with Interactivity ==================================================

library(ggiraph)

g_int <-
  g_raw +
  geom_point_interactive(
    aes(
      size = pop, color = continent,
      data_id = iso_a3, tooltip = country
    ),
    alpha = .75
  )

g_int

g_int <-
  g_raw +
  geom_point_interactive(
    aes(
      size = pop, color = continent,
      data_id = iso_a3, tooltip = country
    ),
    alpha = .75
  )

girafe(
  ggobj = g_int,
  width_svg = 5.5,
  height_svg = 6.6
)

girafe(
  ggobj = g_int,
  width_svg = 5.5,
  height_svg = 6.6,
  options = list(
    opts_tooltip(css = "color: black; font-size: 16pt;"),
    opts_hover(css = "opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.3;"),
    opts_toolbar(position = "bottomright", pngname = "gapminder-2023")
  )
)

girafe(
  ggobj = g_int, width_svg = 9, height_svg = 5.5,
  options = list(
    opts_tooltip(
      use_fill = TRUE,
      css = "font-family: Rubik; font-size: 18pt; font-weight: 600; color: white;
             padding: 12px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.3);"
    ),
    opts_hover(css = "stroke: black; stroke-width: 1px; opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.3;"),
    opts_toolbar(position = "bottomright"),
    opts_zoom(min = 1, max = 4)
  )
)

g_tooltip <-
  gm_2023 |>
  mutate(tooltip = paste0(
    "<b style='font-size:24pt;'>", country_name, "</b><br>",
    "<span style='font-size:15pt;'><b>", continent, "</b> (", region, ")</span><hr>",
    "Per-capita GDP: ", format(gdp_pcap, big.mark = ","), " int$<br>",
    "Life expectancy: ", life_exp, " years<br>",
    "Population: ", scales::number(pop / 10^6, big.mark = ",", accuracy = .1), " million"
  )) |>
  ggplot(aes(x = gdp_pcap, y = life_exp)) +
  geom_point_interactive(
    aes(
      size = pop, color = continent,
      data_id = iso_a3, tooltip = tooltip
    ),
    alpha = .75
  ) +
  scale_x_log10(
    labels = scales::label_dollar(),
    breaks = 1000 * 4^(0:4)
  ) +
  scale_size_area(
    max_size = 20,
    breaks = 1 * 10^(6:9),
    labels = c("1 million", "10 million", "100 million", "1 billion")
  ) +
  scale_color_manual(
    values = pal_dark
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  )

girafe(
  ggobj = g_tooltip, width_svg = 9, height_svg = 5.5,
  options = list(
    opts_tooltip(use_fill = TRUE, css = "font-family: Rubik; font-size: 18pt; color: white; padding: 12px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.3);"),
    opts_hover(css = "stroke: black; stroke-width: 1px; opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.3;"),
    opts_toolbar(position = "bottomright"),
    opts_zoom(min = 1, max = 4)
  )
)


## Programming with ggplot2 ====================================================

smooth <- TRUE

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  {
    if (smooth) geom_smooth(color = "red")
  } +
  geom_point(alpha = .5)

smooth <- FALSE

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  {
    if (smooth) geom_smooth(color = "red")
  } +
  geom_point(alpha = .5) +
  scale_x_log10()

draw_scatter <- function(smooth = TRUE) {
  ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
    {
      if (smooth) geom_smooth(color = "red")
    } +
    geom_point(alpha = .5)
}

draw_scatter()

draw_scatter(smooth = FALSE)

geom_scatterfit <- function(
    pointcolor = "black", pointsize = 2, pointalpha = 1,
    linecolor = "red", linewidth = 1,
    se = TRUE, method = "lm", ...) {
  list(
    geom_smooth(method = method, se = se, color = linecolor, linewidth = linewidth, ...),
    geom_point(color = pointcolor, size = pointsize, alpha = pointalpha, ...)
  )
}

ggplot(
  data = gm_2023,
  aes(x = fertility, y = life_exp)
) +
  geom_scatterfit()

ggplot(
  data = gm_2023,
  aes(x = fertility, y = life_exp)
) +
  geom_scatterfit(
    method = "loess"
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit(
    se = FALSE,
    linecolor = "royalblue",
    linewidth = 3,
    pointsize = 4,
    pointalpha = .3,
    shape = 18
  ) +
  scale_x_log10() +
  scale_y_log10()

scales_log <- function(sides = "xy") {
  list(
    if (stringr::str_detect(sides, "x")) {
      scale_x_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    },
    if (stringr::str_detect(sides, "y")) {
      scale_y_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    }
  )
}

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit(
    se = FALSE,
    linecolor = "royalblue",
    linewidth = 3,
    pointsize = 4,
    pointalpha = .3,
    shape = 18
  ) +
  scales_log(sides = "xy")

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit(
    se = FALSE,
    linecolor = "royalblue",
    linewidth = 3,
    pointsize = 4,
    pointalpha = .3,
    shape = 18
  ) +
  scales_log(sides = "x") +
  scale_y_log10()

trends_by_year <- function(year = "2023") {
  gapminder |>
    dplyr::filter(year == as.numeric(.env$year)) |>
    ggplot(aes(x = gdp_pcap, y = life_exp)) +
    geom_smooth(method = "lm", color = "#004830") +
    geom_point(shape = 21, size = 2, fill = "#91F54B") +
    scale_x_log10(
      breaks = 1000 * 2^(0:3 * 2),
      labels = scales::label_dollar(accuracy = 1)
    ) +
    labs(
      title = paste("Gapminder World", year),
      x = "GDP per capita ($ adjusted for price differences)",
      y = "Life expectancy (years)"
    )
}

trends_by_year()

trends_by_year("1950")

trends_by_year_fixed <- function(year = "2023") {
  gapminder |>
    dplyr::filter(year == as.numeric(.env$year)) |>
    ggplot(aes(x = gdp_pcap, y = life_exp)) +
    geom_smooth(method = "lm", color = "#004830") +
    geom_point(shape = 21, size = 2, fill = "#91F54B") +
    # keep axis ranges consistent
    scale_x_log10(
      breaks = 1000 * 2^(0:3 * 2),
      labels = scales::label_dollar(accuracy = 1),
      limits = range(gapminder$gdp_pcap, na.rm = TRUE)
    ) +
    scale_y_continuous(limits = range(gapminder$life_exp, na.rm = TRUE)) +
    labs(
      title = paste("Gapminder World", year),
      x = "GDP per capita ($ adjusted for price differences)",
      y = "Life expectancy (years)"
    )
}

trends_by_year_fixed("1950")



plots <- purrr::map(seq(1965, 2020, by = 5), trends_by_year_fixed) # or: ~ trends_by_year_fixed(.x)
plots[[9]]

plots <- purrr::map(seq(1965, 2020, by = 5), trends_by_year_fixed) # or: ~ trends_by_year_fixed(.x)
patchwork::wrap_plots(plots)

plot_density <- function(data, var, grp = NULL) {
  ggplot(data, aes(x = !!sym(var))) +
    {
      if (is.null(grp)) geom_density(fill = "grey80", color = "grey30")
    } +
    {
      if (!is.null(grp)) {
        geom_density(
          aes(fill = !!sym(grp)),
          position = "identity",
          color = "grey30", alpha = .3
        )
      }
    } +
    scale_fill_brewer(palette = "Dark2", name = NULL) +
    scale_x_continuous(expand = c(0, 0)) +
    scale_y_continuous(
      labels = scales::label_number(),
      expand = expansion(mult = c(0, 0.05))
    ) +
    theme(legend.position = "top")
}

plot_density(
  mpg, "displ"
)

plot_density(
  mpg, "displ",
  grp = "drv"
)

plots <- purrr::map(
  c("displ", "cyl", "cty", "hwy"),
  ~ plot_density(data = mpg, var = .x, grp = "drv")
)
patchwork::wrap_plots(plots, nrow = 1)

plots <- purrr::map(
  c("life_exp", "fertility"),
  ~ plot_density(data = gm_2023, var = .x, grp = "continent")
)
patchwork::wrap_plots(plots)

plots <- purrr::map(
  names(select(midwest, where(is.numeric))),
  ~ plot_density(data = midwest, var = .x)
)
patchwork::wrap_plots(plots)



## APPENDIX ####################################################################

# ggsave(g, filename = "my_plot.png")
# ggsave("my_plot.png")
# ggsave("my_plot.png", width = 8, height = 5, dpi = 600)
# ggsave("my_plot.pdf", width = 20, height = 12, unit = "cm", device = cairo_pdf)

gm <-
  ggplot(
    data = gm_2023,
    aes(x = gdp_pcap, y = life_exp)
  ) +
  geom_point(
    aes(color = continent),
    alpha = .75
  ) +
  scale_x_log10() +
  theme_light() +
  theme(legend.position = "none")

gm +
  facet_wrap(
    vars(continent)
  )

gm +
  facet_wrap(
    ~continent
  )

gm + facet_wrap(~continent, nrow = 1)

gm + facet_wrap(~continent, scales = "free_x", space = "free_x")

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  # only works with ggplot v4
  geom_point(
    color = "grey85",
    size = .7,
    layout = "fixed"
  ) +
  geom_point(size = 1) +
  scale_x_log10() +
  facet_wrap(
    ~continent
  ) +
  theme_light()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  # works with older versions as well
  geom_point(
    data = select(gm_2023, -continent),
    color = "grey85",
    size = .7
  ) +
  geom_point(size = 1) +
  scale_x_log10() +
  facet_wrap(
    ~continent
  ) +
  theme_light()

gm +
  facet_grid(
    region ~ continent,
    labeller = labeller(
      region = label_wrap_gen(10)
    )
  )

theme_grey

theme_minimal

theme_gapminder <- function(
    base_family = "Verdana", base_size = 11,
    ink = "#292929", paper = "#FDFDFD", accent = "firebrick", ...) {
  theme_minimal(
    base_family = base_family, base_size = base_size,
    ink = ink, paper = paper, accent = accent, ...
  ) %+replace%
    theme(
      plot.title = element_text(
        size = rel(1.3), face = "bold",
        margin = margin(b = base_size / 2), hjust = 0
      ),
      plot.subtitle = element_text(
        size = rel(1.1), hjust = 0,
        margin = margin(t = 0, b = base_size)
      ),
      plot.title.position = "plot",
      plot.caption = element_text(
        color = "grey50", margin = margin(t = base_size / 2),
        size = rel(0.8), hjust = 0, vjust = 1
      ),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, vjust = 0, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, vjust = 0, angle = 90, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      panel.grid.minor = element_blank(),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      plot.margin = margin_auto(base_size),
      complete = TRUE
    )
}

g2 + theme_gapminder()

g2 + geom_smooth(method = "lm") + theme_gapminder()

g2 +
  theme_gapminder(
    base_size = 10,
    base_family = "Georgia"
  )

g2 +
  theme_gapminder(
    base_size = 10,
    base_family = "Georgia"
  ) +
  theme(
    panel.grid.major = element_line(
      color = "grey70", linewidth = .3
    ),
    legend.box.background = element_rect(
      color = "#292929", fill = "#FDFDFD"
    )
  )

theme_gapminder_title <- function(
    base_size = 13, base_family = "Asap Condensed", title_family = "Bitter",
    ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  theme_minimal(
    base_size = base_size, base_family = base_family,
    ink = ink, paper = paper, accent = accent, ...
  ) +
    theme(
      plot.title = element_text(
        family = title_family, size = rel(1.3), face = "bold",
        margin = margin(b = base_size / 2), hjust = 0
      ),
      plot.subtitle = element_text(
        size = rel(1.1), hjust = 0,
        margin = margin(t = 0, b = base_size)
      ),
      plot.title.position = "plot",
      plot.caption = element_text(
        color = "grey50", margin = margin(t = base_size / 2),
        size = rel(0.8), hjust = 0, vjust = 1
      ),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, vjust = 0, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, vjust = 0, angle = 90, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      panel.grid.minor = element_blank(),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      plot.margin = margin_auto(base_size),
      complete = TRUE
    )
}

g2 +
  theme_gapminder_title()

g2 +
  theme_gapminder_title(
    base_family = "Times",
    title_family = "Mono"
  )

theme_gapminder_title <- function(
    base_family = "Asap Condensed", title_family = "Bitter", ...) {
  unavailable <- vector("character")

  if (sum(grepl("Bitter", systemfonts::system_fonts()$family)) == 0) {
    title_family <- ""
    unavailable <- c(unavailable, "Bitter")
  }

  if (sum(grepl("Asap Condensed", systemfonts::system_fonts()$family)) == 0) {
    base_family <- ""
    unavailable <- c(unavailable, "Asap Condensed")
  }

  if (length(unavailable) > 0) {
    unavailable <- data.frame(
      name = unavailable,
      url = paste0("https://fonts.google.com/specimen/", sub(" ", "+", unavailable))
    )
    message(paste(
      "Using system default typefaces.",
      "For proper use, please install the following typeface(s):",
      paste0("  - ", unavailable$name, ": ", unavailable$url, collapse = "\n"),
      "Then restart your R session.",
      sep = "\n"
    ))
  }

  theme_gapminder(...) +
    theme(
      plot.title = element_text(size = rel(1.3), hjust = 0, family = title_family)
    )
}

g2 + theme_gapminder_title()

theme_gapminder_grid <- function(
    base_size = 13, base_family = "Asap Condensed", grid = "xy",
    base_line_size = base_size / 22, base_rect_size = base_size / 22,
    ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  out <-
    theme_minimal(
      base_size = base_size, base_family = base_family,
      base_line_size = base_line_size, base_rect_size = base_rect_size,
      ink = ink, paper = paper, accent = accent, ...
    ) +
    theme(
      plot.title = element_text(
        size = rel(1.3), margin = margin(b = base_size / 2),
        family = "Asap Condensed Extrabold", hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(color = "grey30", margin = margin(t = base_size)),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      plot.background = element_rect(fill = "#F8F8F8", color = NA),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank(),
      axis.ticks = element_line(color = "grey20"),
      axis.ticks.length = unit(base_size / 2, "pt")
    )

  if (grepl(grid, "x|X")) {
    out <- out + theme(
      panel.grid.major.x = element_line(color = "grey87"),
      axis.ticks.x = element_blank(),
      axis.ticks.length.x = unit(base_line_size, "pt")
    )
  }
  if (grepl(grid, "y|Y")) {
    out <- out + theme(
      panel.grid.major.y = element_line(color = "grey87"),
      axis.ticks.y = element_blank(),
      axis.ticks.length.y = unit(base_line_size, "pt")
    )
  }

  return(out)
}

g2 + theme_gapminder_grid(grid = "y")

g2 + theme_gapminder_grid(grid = "none")

g2 + theme_gapminder_grid(grid = "y")

g2 + theme_gapminder_grid(grid = "all")

theme_gapminder_grid <- function(
    base_size = 13, base_family = "Verdana", grid = "xy",
    base_line_size = base_size / 22, base_rect_size = base_size / 22,
    ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  if (!grepl(grid, "none|x|X|y|Y")) stop('grid must be a character: "none" or any combination of "X", "Y", "x" and "y".')

  out <-
    theme_minimal(
      base_size = base_size, base_family = base_family,
      base_line_size = base_line_size, base_rect_size = base_rect_size,
      ink = ink, paper = paper, accent = accent, ...
    ) +
    theme(
      plot.title = element_text(
        size = rel(1.3), margin = margin(b = base_size / 2),
        family = "Asap Condensed Extrabold", hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(color = "grey30", margin = margin(t = base_size)),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      plot.background = element_rect(fill = "#F8F8F8", color = NA),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank(),
      axis.ticks = element_line(color = "grey20"),
      axis.ticks.length = unit(base_size / 2, "pt")
    )

  if (grepl(grid, "x|X")) {
    out <- out + theme(
      panel.grid.major.x = element_line(color = "grey87"),
      axis.ticks.x = element_blank(),
      axis.ticks.length.x = unit(base_line_size, "pt")
    )
  }
  if (grepl(grid, "y|Y")) {
    out <- out + theme(
      panel.grid.major.y = element_line(color = "grey87"),
      axis.ticks.y = element_blank(),
      axis.ticks.length.y = unit(base_line_size, "pt")
    )
  }

  return(out)
}

g2 +
  theme_gapminder_grid(
    grid = "all"
  )
