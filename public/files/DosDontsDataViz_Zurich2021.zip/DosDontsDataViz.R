#------------------------------------------------------------------------------#
#       “Dos and Don'ts of Data Visualization, Illustrated with ggplot2”       #
#                     Cédric Scherer | December 9, 2021                        #
#                                                                              #
#                    UZH Peer Mentoring Projekt R Group                        #
#------------------------------------------------------------------------------#


## basic tidyverse packages we need for data wrangling + plotting
## ggplot2 is part of the tidyverse package collections
## you can also load all tidyverse packages via `library(tidyverse)`

library(ggplot2)
library(dplyr)
library(tibble)
library(tidyr)
library(forcats)
library(stringr)

## all the following libraries will be loaded when needed or 
## used via the namespace: `package::function()`

# library(patchwork)
# library(scales)
# library(RColorBrewer)
# library(scico)
# library(viridis)
# library(colorspace)
# library(rcartocolor)
# library(colorBlindness)
# library(ggforce)
# library(ggbeeswarm)
# library(ggiraph)


## Beware of Pie Charts --------------------------------------------------------

plot_pie <- function(data, vec){
  
  n <- nrow(data)
  
  ggplot(data, aes(x = "name", y = value, fill = name)) +
    geom_col(width = 1) +
    geom_text(
      aes(y = vec, label = rev(name)), 
      color = c(rep("black", floor(n / 2)), rep("white", ceiling(n / 2))), 
      size = 8, fontface = "bold"
     ) +
    coord_polar("y", start = 0, direction = -1) +
    scale_fill_viridis_d(option = "magma", end = .9) + 
    theme_void() +
    theme(legend.position = "none",
          plot.margin = margin(rep(12, 4)))
}

data1 <- data.frame(name = LETTERS[1:5], value = c(38, 39, 40, 41, 43))
data2 <- data.frame(name = LETTERS[1:5], value = c(41, 40, 39, 40, 41))
data3 <- data.frame(name = LETTERS[1:5], value = c(43, 41, 40, 39, 38))

data1

pie1 <- plot_pie(data1, c(22, 63, 103, 144, 184))
pie2 <- plot_pie(data2, c(20, 60, 100, 140, 180))
pie3 <- plot_pie(data3, c(21, 61, 100, 141, 181))

library(patchwork)

pie_panel <- pie1 + pie2 + pie3

pie_panel

plot_bar <- function(data){
  ggplot(data, aes(x = name, y = value, fill = name)) +
    geom_col() +
    scale_fill_viridis_d(option = "magma", end = .9) + 
    theme_void() +
    theme(legend.position = "none",
          axis.text.x = element_text(size = 20, face = "bold"),
          plot.margin = margin(rep(12, 4)))
}

bar_panel <- plot_bar(data1) + plot_bar(data2) + plot_bar(data3)

pie1 + pie2 + pie3 + plot_bar(data1) + plot_bar(data2) + plot_bar(data3) + plot_layout(heights = c(.4, .6), ncol = 3)



## Always Start at Zero --------------------------------------------------------

ggplot(data1, aes(x = name, y = value)) +
  geom_col() +
  coord_cartesian(ylim = c(35, NA))

theme_set(theme_minimal(
  base_size = 16,
  base_family = "Roboto Condensed"
))

ggplot(data1, aes(x = name, y = value)) +
  geom_col() +
  coord_cartesian(ylim = c(35, NA))

ggplot(data1, aes(x = name, y = value)) + 
  geom_col() +
  scale_y_continuous(limits = c(35, NA))

ggplot(iris, aes(x = Species, y = Sepal.Length)) + 
  geom_boxplot() +
  coord_cartesian(ylim = c(NA, 6))

ggplot(iris, aes(x = Species, y = Sepal.Length)) + 
  geom_boxplot() +
  scale_y_continuous(limits = c(NA, 6))

ggplot(data1, aes(x = name, y = value)) + 
  geom_col() +
  coord_cartesian(expand = FALSE)

ggplot(data1, aes(x = name, y = value)) + 
  geom_col() +
  coord_cartesian(expand = FALSE, ylim = c(35, NA))

p <-
  ggplot(data1, aes(x = name, y = value)) +
  geom_col(fill = "grey75") +
  geom_segment(
    aes(x = name, xend = name, y = 0, yend = value - .1),
    color = "firebrick", size = 1.3, arrow = arrow(length = unit(0.5, "cm"), type = "closed")
  ) +
  geom_hline(yintercept = 35) +
  scale_y_continuous(expand = c(0, 0)) +
  coord_cartesian(ylim = c(35, 43.5)) +
  theme_minimal(base_size = 20) +
  theme(panel.grid.minor = element_blank(), panel.grid.major.x = element_blank())

p

p + coord_cartesian(ylim = c(35, 43.5), clip = "off")

# ggplot(data1, aes(x = name, y = value)) + 
#   geom_col(fill = "grey75") +
#   geom_segment(
#     aes(x = name, xend = name, y = 0, yend = value - .1),
#     color = "firebrick", size = 1.3, arrow = arrow(length = unit(0.5, "cm"), type = "closed")
#   ) +
#   geom_hline(yintercept = 35) +
#   scale_y_continuous(expand = c(.003, .003)) +
#   coord_cartesian(ylim = c(35, 43.5), clip = "off") + 
#   theme_minimal(base_size = 20) +
#   theme(plot.margin = margin(b = 320),
#         panel.grid.minor = element_blank(), panel.grid.major.x = element_blank())



## Always (?) Start at Zero ----------------------------------------------------

data_pop <- world_bank_pop %>% 
  filter(
    indicator == "SP.POP.TOTL",
    country %in% c("DEU", "FRA", "GBR")
  ) %>% 
  pivot_longer(
    cols = -c(country, indicator),
    names_to = "year",
    values_to = "population"
  ) %>% 
  mutate(year = as.numeric(year))

data_pop

data_pop <- world_bank_pop %>% 
  filter(
    indicator == "SP.POP.TOTL",
    country %in% c("DEU", "FRA", "GBR")
  ) %>% 
  pivot_longer(
    cols = -c(country, indicator),
    names_to = "year",
    values_to = "population"
  ) %>% 
  mutate(year = as.numeric(year))

data_pop_fra_gbr <-
  filter(data_pop, country != "DEU", year == 2017)

data_pop

data_pop_fra_gbr

ggplot(data_pop_fra_gbr,
       aes(x = country, y = population)) + 
  geom_col()

ggplot(data_pop_fra_gbr,
       aes(x = country, y = population)) + 
  geom_point(size = 5)

ggplot(data_pop_fra_gbr,
       aes(x = country, y = population)) + 
  geom_col()

ggplot(data_pop_fra_gbr,
       aes(x = country, y = population, group = 1)) + 
    geom_point(size = 5) +
    geom_line(size = 1)

ggplot(data_pop,
       aes(x = year,
           y = population)) +
  geom_line(aes(color = country)) +
  coord_cartesian(ylim = c(0, NA))

ggplot(data_pop,
       aes(x = year,
           y = population)) +
  geom_line(aes(color = country))

ggplot(data_pop,
       aes(x = year,
           y = population)) +
  geom_line(aes(color = country)) +
  scale_y_continuous(
    labels = scales::comma_format()
  )

min <- min(data_pop$population)
max <- max(data_pop$population)
golden <- min - (max - min) / 3

golden

ggplot(data_pop,
       aes(x = year,
           y = population)) +
  geom_line(aes(color = country)) +
  scale_y_continuous(
    labels = scales::comma_format(),
    limits = c(golden, NA)
  )



## Order Your Data -------------------------------------------------------------

ggplot(mpg, aes(x = class)) + 
  geom_bar()

ggplot(mpg, aes(x = fct_infreq(class))) + 
  geom_bar()

ggplot(mpg, aes(x = fct_rev(fct_infreq(class)))) + 
  geom_bar()



## Don't Rotate Your Text Labels -----------------------------------------------

ggplot(mpg, aes(x = fct_infreq(manufacturer))) + 
  geom_bar() +
  theme(axis.text.x = element_text(
    angle = 45, vjust = 1, hjust = 1
  ))

ggplot(mpg, aes(x = fct_infreq(manufacturer))) + 
  geom_bar() +
  scale_x_discrete(
    guide = guide_axis(n.dodge = 2)
  )

ggplot(mpg, aes(x = fct_infreq(fct_lump_n(manufacturer, n = 8)))) + 
  geom_bar()

ggplot(mpg, aes(x = fct_relevel(fct_infreq(fct_lump_n(manufacturer, n = 8)), "Other", after = Inf))) + 
  geom_bar()

ggplot(mpg, aes(x = fct_infreq(manufacturer))) +
  geom_bar() +
  coord_flip(expand = FALSE)

ggplot(mpg, aes(x = fct_rev(fct_infreq(manufacturer)))) +
  geom_bar() +
  coord_flip(expand = FALSE)

(g <- ggplot(mpg, aes(x = fct_rev(fct_infreq(manufacturer)))) +
  geom_bar() +
  coord_flip(expand = FALSE) +
  xlab(NULL) +
  ggtitle("Number of cars by manufacturer"))

g

g + theme(plot.title.position = "plot")

ggplot(mpg, aes(x = fct_infreq(manufacturer))) + 
  geom_bar() +
  coord_flip(expand = FALSE)



## Guide Your Reader -----------------------------------------------------------

data_growth <- world_bank_pop %>% 
  filter(
    indicator == "SP.POP.GROW",
    country %in% c("DEU", "AUT", "CHE", "ITA", "ESP")
  ) %>% 
  pivot_longer(
    cols = -c(country, indicator),
    names_to = "year",
    values_to = "growth"
  ) %>% 
  mutate(year = as.numeric(year))

data_growth

ggplot(data_growth,
       aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  )

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ungroup() %>%
  mutate(
    country = fct_reorder(country, -last)
  ) %>%
  ggplot(aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  )

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ungroup() %>%
  mutate(
    country = fct_reorder(country, -last)
  ) %>%
  ggplot(aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  ) +
  scale_color_discrete(name = NULL)

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ungroup() %>%
  mutate(
    country = fct_reorder(country, -last)
  ) %>%
  ggplot(aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  ) +
  scale_color_discrete(name = NULL) +
  theme(legend.position = "top")

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ungroup() %>%
  mutate(
    country = fct_reorder(country, -last)
  ) %>%
  ggplot(aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  ) +
  scale_color_discrete(name = NULL) +
  guides(color = guide_legend(
    label.position = "bottom", label.hjust = .5,
    keywidth = unit(5, "lines"),
    keyheight = unit(.5, "lines")
  )) + 
  theme(legend.position = "top")

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ggplot(aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  ) +
  geom_text(
    aes(x = 2017, y = last, label = country)
  ) +
  scale_color_discrete(guide = "none")

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ggplot(aes(x = year, y = growth)) +
  geom_line(
    aes(color = country),
    size = 1.4
  ) +
  geom_text(
    aes(x = 2017, y = last, label = country),
    fontface = "bold", size = 5,
    stat = "unique", hjust = 0, nudge_x = .2
  ) +
  scale_x_continuous(
    expand = c(0, 0), limits = c(NA, 2019)
  ) +
  scale_color_discrete(guide = "none")

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ggplot(aes(x = year, y = growth,
             color = country)) +
  geom_line(
    size = 1.4
  ) +
  geom_text(
    aes(x = 2017, y = last, label = country),
    fontface = "bold", size = 5,
    stat = "unique", hjust = 0, nudge_x = .2
  ) +
  scale_x_continuous(
    expand = c(0, 0), limits = c(NA, 2019)
  ) +
  scale_color_discrete(guide = "none")

data_growth %>%
  group_by(country) %>%
  mutate(
    last = growth[which(year == 2017)],
  ) %>%
  ggplot(aes(x = year, y = growth,
             color = country)) +
  geom_hline(yintercept = 0) +
  geom_line(
    size = 1.4
  ) +
  geom_text(
    aes(x = 2017, y = last, label = country),
    fontface = "bold", size = 5,
    stat = "unique", hjust = 0, nudge_x = .2
  ) +
  scale_x_continuous(
    expand = c(0, 0), limits = c(NA, 2019)
  ) +
  scale_color_discrete(guide = "none")



## Avoid Color Pitfalls --------------------------------------------------------

plot_bars <- function(data, x_value,
                      y_value, col) {

  ggplot(
    data,
    aes_string(x = x_value, y = y_value, fill = col)
  ) +
  geom_col() +
  theme_void(base_size = 20) +
  theme(legend.title = element_blank(),
        axis.text.x = element_text(face = "bold"))
}

plot_bars(data1, "name", "value", col = "name")

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_viridis_d(
    option = "magma", end = .9
  )

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_viridis_d(
    option = "turbo"
  )

data1$year <- factor(2016:2020)

plot_bars(data1, "year", "value", col = "value")

plot_bars(data1, "year", "value", col = "value") +
  scale_fill_viridis_c(
    option = "mako", end = .85
  )

plot_bars(data1, "year", "value", col = "value") +
  scale_fill_viridis_c(
    option = "mako", end = .85,
    direction = -1
  )

data1$diff <- data1$value - mean(data1$value)

plot_bars(data1, "year", "diff", col = "diff") +
  geom_hline(yintercept = 0)

plot_bars(data1, "year", "diff", col = "diff") +
  geom_hline(yintercept = 0) +
  scale_fill_distiller(
    palette = "Spectral"
  )

extr <- max(abs((range(data1$diff))))

plot_bars(data1, "year", "diff", col = "diff") +
  geom_hline(yintercept = 0) +
  scale_fill_distiller(
    palette = "Spectral",
    limits = c(-extr, extr)
  )

plot_bars(data1, "year", "diff", col = "diff") +
  geom_hline(yintercept = 0) +
  scale_fill_distiller(
    palette = "Spectral",
    limits = c(-extr, extr),
    direction = 1
  )

plot_bars(data1, "year", "diff", col = "diff") +
  geom_hline(yintercept = 0) +
  scico::scale_fill_scico(
    palette = "vikO",
    direction = -1,
    limits = c(-extr, extr)
  )

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_viridis_d(
    option = "viridis", end = .95
  )

set.seed(12345)
pal <- sample(viridis::viridis(5, end = .97))

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_manual(values = pal)

pal_light <- colorspace::lighten(pal, .2)

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_manual(values = pal_light)

pal_desat <- colorspace::desaturate(pal, .3)

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_manual(values = pal_desat)

RColorBrewer::display.brewer.all()

plot_bars(data1, "name", "value", col = "name") + 
  scale_fill_brewer(
    palette = "Set2"
  )

plot_bars(data1, "name", "value", col = "name") + 
  rcartocolor::scale_fill_carto_d(
    palette = "Antique"
  )

plot_bars(data1, "name", "value", col = "name") +
  scale_fill_manual(
    values = c(
      "firebrick", rep("grey67", 4)
    ),
    guide = "none"
  )

g <-
  plot_bars(data1, "name", "value", col = "name") +
  scale_fill_manual(
    values = c(
      "firebrick", rep("grey67", 4)
    ),
    guide = "none"
  )

colorBlindness::cvdPlot(g)

colorBlindness::cvdPlot(
  plot_bars(data1, "name", "value", col = "value") +
  scale_fill_viridis_c()
)

colorBlindness::cvdPlot(
  plot_bars(data1, "name", "value", col = "name") +
  scale_fill_brewer(palette = "Dark2")
)

data1$carto <- sample(rcartocolor::carto_pal(n = 5, name = "Bold"))

plot_bars(data1, "name", "value", col = "carto") + 
  scale_fill_identity(guide = "none")

ggplot(data1, aes(x = value, y = diff)) +
  geom_point(aes(color = carto), 
             shape = 18, size = 8) +
  scale_color_identity(guide = "none")

corp_col <-
  tibble(
    name = LETTERS[1:5],
    hex = c("#e84855", "#403f4c", "#f9dc5c", "#3185fc", "#efbcd5")
  )

corp_col

data_corp <- left_join(data1, corp_col)

data_corp

ggplot(data_corp, 
       aes(x = name, y = diff, fill = hex)) +
  geom_col() +
  scale_fill_identity(guide = "none")

ggplot(data_corp[1:3,], 
       aes(x = name, y = diff, fill = hex)) +
  geom_col() +
  scale_fill_discrete(guide = "none")

ggplot(data_corp[c(2,4,5),], 
       aes(x = name, y = diff, fill = hex)) +
  geom_col() +
  scale_fill_discrete(guide = "none")

ggplot(data_corp[1:3,],
       aes(x = name, y = diff, fill = hex)) +
  geom_col() +
  scale_fill_identity(guide = "none")

ggplot(data_corp[c(2,4,5),], 
       aes(x = name, y = diff, fill = hex)) +
  geom_col() +
  scale_fill_identity(guide = "none")



## Declutter Your Plot ---------------------------------------------------------

mpg$manufacturer <- fct_rev(fct_infreq(
  str_to_title(mpg$manufacturer)
))

ggplot(mpg, aes(x = manufacturer)) +
  geom_bar() +
  coord_flip(expand = FALSE, ylim = c(0, 40)) +
  theme_grey(base_size = 22)

theme_set(
  theme_minimal(base_size = 22)
)

ggplot(mpg, aes(x = manufacturer)) +
  geom_bar() +
  coord_flip(expand = FALSE, ylim = c(0, 40))

ggplot(mpg, aes(x = displ)) +
  geom_histogram(bins = 25)

ggplot(mpg, aes(x = factor(cyl))) +
  geom_bar(width = .7)

theme_update(plot.title.position = "plot")

(g <- ggplot(mpg, aes(x = manufacturer)) +
  geom_bar(width = .75, fill = "grey55") +
  coord_flip(expand = FALSE, ylim = c(0, 40))+
  labs(x = NULL, y = NULL,
       title = "Number of cars by manufacturer")
)

theme_update(panel.grid.minor = element_blank())

g

theme_update(panel.grid.major.y = element_blank())

g

g +
  scale_y_continuous(
    breaks = 0:8*5
  )

g +
  scale_y_continuous(
    breaks = 1:7*5
  )

g +
  scale_y_continuous(
    breaks = 1:7*5
  ) +
  theme(panel.ontop = TRUE)

g +
  scale_y_continuous(
    breaks = 1:7*5
  ) +
  theme(
    panel.ontop = TRUE,
    panel.grid.major.x = element_line(
      linetype = "13"
    )
  )

g +
  scale_y_continuous(
    breaks = 1:7*5,
    position = "right"
  ) +
  theme(
    panel.ontop = TRUE,
    panel.grid.major.x = element_line(
      color = "white"
    )
  )

g +
  scale_y_continuous(
    breaks = 1:7*5,
    position = "right"
  ) +
  theme(
    panel.ontop = TRUE,
    panel.grid.major.x = element_line(
      color = "#FFFFFF80" #<
    )
  )

g +
  scale_y_continuous(
    breaks = 1:7*5,
    position = "right"
  )

g +
  scale_y_continuous(
    breaks = 1:7*5,
    sec.axis = dup_axis(name = NULL)
  )

g +
  stat_count(
    geom = "text",
    aes(y = ..count..,
        label = ..count..)
  ) + 
  scale_y_continuous(
    breaks = 1:7*5,
    position = "right"
  )

g +
  stat_count(
    geom = "text",
    aes(y = ..count.. + 1,
        label = ..count..),
    hjust = 0, fontface = "bold"
  ) +
  scale_y_continuous(
    breaks = 1:7*5,
    position = "right"
  )

g +
  stat_count(
    geom = "text",
    aes(y = ..count.. - .5,
        label = ..count..),
    color = "white", size = 6,
    fontface = "bold", hjust = 1
  ) +
  scale_y_continuous(
    breaks = 1:7*5,
    position = "right"
  )

theme_update(axis.text.x = element_blank())

g +
  stat_count(
    geom = "text",
    aes(y = ..count.. + .5,
        label = ..count..),
    hjust = 0, fontface = "bold", size = 6
  )

theme_update(plot.title = element_text(face = "bold", margin= margin(b = 20)))

g +
  stat_count(
    geom = "text",
    aes(y = ..count.. + .5,
        label = ..count..),
    hjust = 0, fontface = "bold", size = 6
  )

cols <- c("grey55", "dodgerblue3")

ggplot(mpg, aes(x = manufacturer,
                fill = manufacturer == "Dodge",
                color = manufacturer == "Dodge")) +
  geom_bar(width = .75)  +
  stat_count(
    geom = "text",
    aes(y = ..count.. + .5,
        label = ..count..),
    hjust = 0, fontface = "bold", size = 6
  ) +
  scale_color_manual(values = cols, guide = "none") +
  scale_fill_manual(values = cols, guide = "none") +
  coord_flip(expand = FALSE, ylim = c(0, 40))+
  labs(x = NULL, y = NULL,
       title = "Number of cars by manufacturer")

cols_rep <-  c(
  rep(cols[1], n_distinct(mpg$manufacturer) - 1),
  cols[2]
)

ggplot(mpg, aes(x = manufacturer,
                fill = manufacturer == "Dodge",
                color = manufacturer == "Dodge")) +
  geom_bar(width = .75)  +
  stat_count(
    geom = "text",
    aes(y = ..count.. + .5,
        label = ..count..),
    hjust = 0, fontface = "bold", size = 6
  ) +
  scale_color_manual(values = cols, guide = "none") +
  scale_fill_manual(values = cols, guide = "none") +
  coord_flip(expand = FALSE, ylim = c(0, 40))+
  labs(x = NULL, y = NULL,
       title = "Number of cars by manufacturer") +
  theme(axis.text.y = element_text(
    color = cols_rep
  ))



## Show the Raw Data -----------------------------------------------------------

## reset theme
theme_set(theme_minimal(base_size = 19, base_family = "Roboto Condensed"))
theme_update(
  panel.grid.minor = element_blank(),
  axis.title.x = element_blank()
)

data <- filter(mpg, str_detect(manufacturer, "e"))

ggplot(data, aes(x = manufacturer, y = cty)) + 
  geom_boxplot()

ggplot(data, aes(x = manufacturer, y = cty)) + 
  geom_point(size = 3, alpha = .5)

ggplot(data, aes(x = manufacturer, y = cty)) + 
  geom_jitter(size = 3, alpha = .5, width = .2)

ggplot(data, aes(x = manufacturer, y = cty)) + 
  ggforce::geom_sina(size = 3, alpha = .5)

ggplot(data, aes(x = manufacturer, y = cty)) + 
  ggbeeswarm::geom_quasirandom(size = 3, alpha = .5)

ggplot(data, aes(x = manufacturer, y = cty)) + 
  geom_boxplot(size = 1) + 
  ggbeeswarm::geom_beeswarm(size = 3, alpha = .33)



## Wrap Up ---------------------------------------------------------------------

chic <- read_csv(
  "https://raw.githubusercontent.com/z3tt/ggplot-courses/master/data/chicago-nmmaps-custom.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

ggplot(chic, aes(yday, temp)) +
  geom_smooth(se = FALSE, color = "black") +
  geom_point(
    aes(fill = season), size = 3, shape = 21, color = "white", stroke = .4, alpha = .7
  ) +
  geom_point(
    size = 3, shape = 21, fill = "transparent", color = "white", stroke = .4
  ) +
  facet_wrap(vars(year)) +
  scale_x_continuous(breaks = c(1, 1:6*50, 365)) +
  scale_y_continuous(labels = function(x) paste0(x, "°F")) +
  scale_fill_brewer(palette = "Dark2", name = NULL) +
  labs(
    x = "Day of the Year",
    y = "Temperature",
    caption = "Data: National Morbidity and Mortality Air Pollution Study (NMMAPS)"
  ) +
  theme_light(base_size = 18, base_family = "Aileron") +
  theme(
    legend.position = "top",
    panel.grid.minor = element_blank(),
    plot.caption = element_text(color = "grey40", margin = margin(t = 15)),
    strip.text = element_text(size = 20, face = "bold"),
    legend.text = element_text(size = 18)
  )



## Interactive Plots -----------------------------------------------------------

library(ggiraph)

data <- mtcars
data$carname <- row.names(data)

g <- ggplot(data, aes(wt, mpg)) +
  geom_smooth(method = "lm", color = "black") +
  geom_point_interactive( 
    aes(color = disp, size = qsec,
        tooltip = carname, data_id = carname), alpha = .8
  ) +  
  rcartocolor::scale_color_carto_c(palette = "ag_GrnYl", direction = -1) +
  scale_size(rang = c(1, 10)) +
  theme_minimal(base_size = 15)

girafe(ggobj = g, 
       height_svg = 6, width_svg = 12,
       options = list(
         opts_tooltip(offx = 20, offy = 20)
      ))

girafe(ggobj = g, 
       height_svg = 6, width_svg = 12,
       options = list(
         opts_tooltip(offx = -80, offy = -50),
         opts_hover_inv(css = "opacity:0.1;"),
         opts_hover(css = "fill:black;")
       ))
