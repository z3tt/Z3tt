#------------------------------------------------------------------------------#
#                                                                              #
#     Data Visualization in R: How to create beautiful charts with ggplot2     #
#                      Cédric Scherer | November 16 2021                       #
#                                                                              #
#------------------------------------------------------------------------------#


## The Package #################################################################

#install.packages("ggplot2")
library(ggplot2)

#install.packages("tidyverse")
library(tidyverse)


## The Data ####################################################################

chic <- read_csv(
  "https://raw.githubusercontent.com/z3tt/ggplot-courses/master/data/chicago-nmmaps-custom.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

tibble::glimpse(chic)


## Data: ggplot(data) ##########################################################

ggplot

?ggplot

ggplot(data = chic) 

# We need to specify data and the two variables we want to plot as aestethics 
# of the ggplot() call:

ggplot(data = chic, mapping = aes(x = date, y = temp)) 

ggplot(chic, aes(date, temp)) 


## Layers: geom_*() and stat_*() ###############################################

# By adding layers we can tell ggplot2 how to represent the data.


## Geometric Layers: geom_*() ##################################################

ggplot(chic, aes(date, temp)) +
  geom_point() 

ggplot(chic, aes(date, temp)) +
  geom_area() 


## Themes!

# There are several built-in themes in ggplot2 
# (and many many more in extension packages):

ggplot(chic, aes(date, temp)) +
  geom_point() +
  theme_classic()

ggplot(chic, aes(date, temp)) +
  geom_point() +
  theme_minimal() 

ggplot(chic, aes(date, temp)) +
  geom_point() +
  theme_dark()

ggplot(chic, aes(date, temp)) +
  geom_point() +
  theme_linedraw()

theme_set(theme_light())

ggplot(chic, aes(date, temp)) +
  geom_point()


## Your Turn! ------------------------------------------------------------------

# Turn our scatter plot into a line chart and into a bar chart!

# What’s the difference between geom_path() and geom_line()?

# Create a box plot of temperature per date.

# What is the problem? How could you find out why this is happening?

# Try to create box plots as you would expect them.

# Bonus: Choose the built-in theme you like the most!

#------------------------------------------------------------------------------#

# Other layers can be added to an existing plot —
# a line and a rug representation for example:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  geom_line() + 
  geom_rug(sides = "r") 


## Add Labels ##################################################################

# You can change the axes titles by adding xlab() and ylab() to your ggplot:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  xlab("Day of the Year") + 
  ylab("Temperature (°F)") 

#... and a title by adding ggtitle():

ggplot(chic, aes(date, temp)) +
  geom_point() +
  xlab("Day of the Year") + 
  ylab("Temperature (°F)") +
  ggtitle("Seasonal Change of Temperatures in Chicago") 

# Using labs() you can also change all and more in one go:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  labs( 
    x = "Day of the Year",  
    y = "Temperature (°F)", 
    title = "Seasonal Change of Temperatures in Chicago", 
    subtitle = "Daily temperatures (°F) in the city of Chicago, IL,\nmeasured between 1997 and 2001", 
    caption = "Data: National Morbidity and Mortality Air Pollution Study (NMMAPS)", 
    tag = "Fig. 1" 
  ) 


## Saving ggplots ##############################################################

# You can assign ggplot to an object name:

g <- ggplot(chic, aes(date, temp)) +
  geom_point()

g

# ... and add layers afterwards:

g <- ggplot(chic, aes(date, temp)) +
  geom_point()

g +
  geom_line() +
  geom_rug(sides = "r")


# You can export your plot via the ggsave() function:

ggsave(filename = "my_ggplot.pdf", 
       width = 10, height = 7, 
       device = cairo_pdf)

ggsave(filename = "my_ggplot.png", 
       width = 10, height = 7, 
       dpi = 700)


## Statistical Layers: stat_*()

# A handful of layers with attention to the statistical transformation rather than the visual appearance.

## You can go both ways — stat_x(geom = "y") == geom_y(stat = "x"):

ggplot(chic, aes(date, temp)) +
  stat_identity(geom = "point") 

ggplot(chic, aes(date, temp)) +
  geom_point(stat = "identity") 

# Without pre-calculations one can easily summaries of the data:

ggplot(chic, aes(season, temp)) +
  stat_summary() 

ggplot(chic, aes(season, temp)) +
  stat_summary(
    fun.data = mean_se, ## the default 
    geom = "pointrange" ## the default 
  ) 

ggplot(chic, aes(season, temp)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "errorbar" 
  ) 

ggplot(chic, aes(season, temp)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "errorbar", 
    width = .3 
  ) 

ggplot(chic, aes(season, temp)) +
  stat_summary(
    fun = mean, 
    size = 1, 
    color = "#28a87d" 
  )

ggplot(chic, aes(season, temp)) +
  geom_boxplot() + 
  stat_summary(
    fun = mean, 
    size = 1,
    color = "#28a87d" 
  )

ggplot(chic, aes(season, temp)) +
  geom_boxplot() + 
  geom_jitter( 
    width = .1, 
    alpha = .1 
  ) + 
  stat_summary(
    fun = mean, 
    size = 1,
    color = "#28a87d" 
  )

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean) + 
  stat_summary( 
    geom = "errorbar", 
    width = .3 
  ) 

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean) + 
  stat_summary(
    fun = mean, 
    fun.min = function(x) mean(x) - sd(x),  
    fun.max = function(x) mean(x) + sd(x),  
    geom = "errorbar", 
    width = .3 
  )

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean) + 
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x), 
    fun.max = function(x) mean(x) + sd(x), 
    geom = "errorbar", 
    width = .3 
  ) +
  stat_summary( 
    geom = "text", 
    aes(label = ..y..) 
  ) 

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean) + 
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x), 
    fun.max = function(x) mean(x) + sd(x), 
    geom = "errorbar", 
    width = .3 
  ) +
  stat_summary( 
    geom = "text", 
    aes(label = round(..y.., 2)) 
  ) 

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean) + 
  stat_summary(
    fun.min = function(x) mean(x) - sd(x), 
    fun.max = function(x) mean(x) + sd(x), 
    geom = "errorbar", 
    width = .3 
  ) +
  stat_summary(
    geom = "text", 
    aes(label = round(..y.., 2)),
    size = 5, 
    hjust = -.4 
  ) 


# stat_count is the default when drawing bar charts with geom_bar():

ggplot(chic, aes(floor(temp))) +
  stat_count(fill = "grey67")

ggplot(chic, aes(floor(temp))) +
  geom_bar(fill = "grey67")


# stat_function() makes it easy to add a function to a plot, either continuous or discrete:

ggplot(tibble(x = c(-8, 8)), aes(x)) +
  stat_function(fun = dnorm) + 
  stat_function( 
    fun = dcauchy, 
    color = "red", 
    n = 75 
  )  


# You can also plot the empirical cumulative distribution function (ECDF) of a 
# variable with stat_ecdf():

ggplot(chic, aes(temp)) +
  stat_ecdf()  


# You can directly add smoothed conditional means with stat_smooth():

ggplot(chic, aes(date, temp)) +
  geom_point() +
  stat_smooth()  

# By default this adds a LOESS (locally weighted scatter plot smoothing, 
# method = "loess") or a GAM (generalized additive model, method = "gam") 
# depending on the number of data points (GAM in case of ≥ 1000 observations).

# You can specify the fitting method and the formula:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  stat_smooth( 
    method = "lm", 
    formula = y ~ x + I(x^2) +  
      I(x^3) + I(x^4), 
    se = FALSE 
  ) 

# Other methods such as method = "lm" (without an explicit formula) for simple 
# linear regressions and <code>method = "glm" for generalized linear models are 
# available as well.


## Your Turn! ------------------------------------------------------------------

# A famous example data set is mtcars which is pre-loaded in R.

# Have a look at the data set and create the following two visualizations:
# -> see file `Exercise-1.png`

# Box Plots with Raw Data 

# Scatter Plot with Linear Fitting

#------------------------------------------------------------------------------#


## Aesthetics: aes() ###########################################################

# Aesthetics of the geometric and statistical objects, such as 
#   * position via x, y, xmin, xmax, ymin, ymax, ...
#   * color via color and fill
#   * transparency via alpha
#   * size via size and width
#   * shape via shape and linetype

# In general, everything which maps to the data needs to be wrapped in aes()
# while static arguments are placed outside the aes().

# e.g.
# geom_point(color = "red") to color all points in the same color
# geom_point(aes(color = season)) to color points based on the variable season

ggplot(chic, aes(date, temp)) +
  geom_point(
    size = 4, 
    alpha = .2 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season, 
        shape = year), 
    size = 4,
    alpha = .2
  )

# Alternatively, all aesthetics can be grouped together (and are applied 
# to all geom_*() and stats_*()):

ggplot(chic, aes(date, temp,
                 color = season, 
                 shape = year)) +
  geom_point(
    size = 4,
    alpha = .2
  ) 

ggplot(chic, aes(date, temp,
                 color = season, 
                 shape = year)) +
  geom_line() + 
  geom_point(
    size = 4,
    alpha = .2
  ) 

# You can create subsets of the data by specifying a grouping variable via group:

ggplot(chic, aes(temp)) +
  stat_ecdf(aes(group = year))  

# However, for most applications you can simply specify the grouping using 
# visual aesthetics (color, fill, size, alpha, shape, linetype).


## Your Turn! ------------------------------------------------------------------

#  * Run the same code without the grouping. Guess first what's going to happen.

#  * Replace the stat_ecdf(aes(grouop = year)) by 
#    geom_boxplot(aes(group = year)) and run the code.
#    How does this plot differ from previous ones?

#  * Replace the group argument by color, linetype, shape and alpha. 
#    What happens?

#------------------------------------------------------------------------------#

# However, for most applications you can simply specify the grouping using 
# visual aesthetics (color, fill, size, alpha, shape, linetype).

ggplot(chic, aes(temp)) +
  stat_ecdf(aes(color = year))  

ggplot(chic, aes(temp)) +
  stat_ecdf(aes(linetype = year))  

ggplot(chic, aes(temp)) +
  stat_ecdf(aes(shape = year))  

ggplot(chic, aes(temp)) +
  stat_ecdf(aes(alpha = year))  


## Your Turn! ------------------------------------------------------------------

# Another training data set focussing on cars comes with ggplot2 and is called 
# mpg. Create the following visualization:
# -> see file `Exercise-2.png`

#------------------------------------------------------------------------------#


## More geom's

# You can display your data via geom_point() as scatter plot...

ggplot(chic, aes(temp, o3)) + 
  geom_point() 

# ... but there are also other built-in options:

ggplot(chic, aes(temp, o3)) + 
  geom_density2d() 

ggplot(chic, aes(temp, o3)) + 
  geom_density2d(
    aes(color = season) 
  )

ggplot(chic, aes(temp, o3)) + 
  geom_hex() 

ggplot(chic, aes(temp, o3)) +
  geom_hex(
    aes(fill = ..density..) 
  ) 

ggplot(chic, aes(temp, o3)) +
  geom_hex(
    aes(fill = ..density..),
    color = "white" 
  ) 

ggplot(chic, aes(temp, o3)) +
  geom_hex(
    aes(fill = ..density..,
        color = ..density..)
  ) 

ggplot(chic, aes(temp, o3)) + 
  geom_bin2d() 

# Until now, we have mostly focussed on geoms showing the relation between two 
# variables — but some only need one:

ggplot(chic, aes(temp)) + 
  geom_histogram() 

ggplot(chic, aes(temp)) + 
  geom_histogram(bins = 60)

ggplot(chic, aes(temp)) +
  geom_histogram(binwidth = 1)

ggplot(chic, aes(temp)) +
  geom_density() 

# ... and some which make only sense with three variables:

chic_sum <-
  chic %>% 
  group_by(season, year) %>% 
  summarize(avg_temp = mean(temp))

ggplot(chic_sum, aes(year, season)) +
  geom_tile()

ggplot(chic_sum, aes(year, season)) +
  geom_tile(
    aes(color = avg_temp), 
    size = 2
  )

ggplot(chic_sum, aes(year, season)) +
  geom_tile(
    aes(fill = avg_temp) 
  )

ggplot(v, aes(year, season)) +
  geom_tile(
    aes(fill = avg_temp), 
    color = "white", 
    size = 2 
  )

# Some need even more inputs:

points <- tibble(
  x1 = 2, 
  x2 = 23, 
  y1 = 21, 
  y2 = 15
)

ggplot(points, aes(x1, y1)) + 
  geom_point() +
  geom_segment( 
    aes( 
      xend = x2,  
      yend = y2 
    )
  ) 

ggplot(points, aes(x1, y1)) + 
  geom_point() +
  geom_curve( 
    aes( 
      xend = x2,
      yend = y2
    ),
    curvature = .4, 
    arrow = arrow( 
      length = unit(1, "lines") 
    ) 
  ) 

ggplot(points, aes(x1, y1)) + 
  geom_point() +
  geom_abline( 
    slope = .5, 
    intercept = 20 
  ) 

ggplot(points, aes(x1, y1)) + 
  geom_point() +
  geom_hline( 
    yintercept = 20, 
    color = "blue"
  ) + 
  geom_vline( 
    xintercept = 3, 
    color = "red"
  ) 

ggplot(points, aes(x1, y1)) + 
  geom_point() +
  geom_rect( 
    aes(  
      xmin = x1, 
      xmax = x2, 
      ymin = y1, 
      ymax = y2 
    ), 
    color = "black" 
  )  


## Scales: scale_*()

# One can use scale_*() to change properties of all the aesthetic dimensions 
# mapped to the data.

# Consequently, there are scale_*() functions for all aesthetics such as:
#   * positions via scale_x_*() and scale_y_*()
#   * colors via scale_color_*() and scale_fill_*()
#   * sizes via scale_size_*() and scale_radius_*()
#   * shapes via scale_shape_*()  and scale_linetype_*()
#   * transparency via scale_alpha_*()

# The extensions (*) can be filled by e.g.:
#   * continuous(), discrete(), reverse(), log10(), sqrt(), date() for positions
#   * continuous(), discrete(), manual(), gradient(), gradient2(), brewer() for colors
#   * continuous(), discrete(), manual(), ordinal(), area(), date() for sizes
#   * continuous(), discrete(), manual(), ordinal() for shapes
#   * continuous(), discrete(), manual(), ordinal(), date() for transparency

# Scales are directly connected to aesthetics:

ggplot(chic, aes(date, temp,
                 color = season)) + 
  geom_point() +
  scale_x_date() +  
  scale_y_continuous() +  
  scale_color_discrete() 

# All scales come with some general and specific arguments to change the appearance:

ggplot(chic, aes(date, temp,
                 color = season)) + 
  scale_x_date(
    expand = c(0, 0), ## general 
    date_breaks = "6 months", ## date-only  
    date_labels = "%m/%y", ## date only 
    name = NULL ## general  
  ) +
  scale_y_continuous() +  
  scale_color_discrete() 

ggplot(chic, aes(date, temp,
                 color = season)) + 
  geom_point() +
  scale_x_date(
    expand = c(0, 0), ## general
    date_breaks = "6 months", ## date-only  
    date_labels = "%m/%y", ## date only
    name = NULL ## general 
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1), ## general  
    sec.axis = dup_axis(name = NULL), ## axis only 
    name = "Tree Cover" ## general  
  ) + 
  scale_color_discrete()

ggplot(chic, aes(date, temp,
                 color = season)) + 
  geom_point() +
  scale_x_date(
    expand = c(0, 0), ## general 
    date_breaks = "6 months", ## date-only 
    date_labels = "%m/%y", ## date only 
    name = NULL ## general 
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1), ## general  
    sec.axis = dup_axis(name = NULL), ## axis only 
    name = "Tree Cover" ## general 
  ) + 
  scale_color_discrete(
    type = c("#91A3E1", "#83B692", "#F9ADA0", "#CD6FD5"),  ## color only 
    name = "Season:" ## general  
  )


## Positional Scales: scale_x|y_*() ############################################

# scale_x|y_continuous()

(g <- 
   ggplot(chic, aes(year, temp, 
                    color = season)) +
   geom_jitter(
     size = 3,
     alpha = .3,
     position = position_jitter(
       width = .35, 
       seed = 2020
     )
   )
)

g +
  scale_y_continuous(
    limits = c(0, 50) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA),
    expand = c(0, 0) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA),
    expand = c(1, 1) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA),
    expand = c(.02, .02) 
  )

g +
  scale_y_continuous(
    name = "Temperature in Chicago (°F)", 
    limits = c(0, NA),
    expand = c(.02, .02)
  )

g +
  scale_y_continuous(
    name = "Temperature in Chicago (°F)",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 80, by = 10) 
  )

g +
  scale_y_continuous(
    name = "Temperature in Chicago", 
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 80, by = 10),
    labels = glue::glue(
      "{seq(0, 80, by = 10)}°F" 
    )
  )

g +
  scale_y_continuous(
    name = "Temperature in Chicago",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 80, by = 10),
    labels = glue::glue(
      "{seq(0, 80, by = 10)}°F" 
    ),
    position = "right" 
  )

g +
  scale_y_continuous(
    name = "Temperature in Chicago",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 80, by = 10),
    labels = glue::glue(
      "{seq(0, 80, by = 10)}°F" 
    ),
    sec.axis = dup_axis(name = "") 
  )

g +
  scale_y_continuous(
    name = "Temperature in Chicago",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 80, by = 10),
    labels = glue::glue(
      "{seq(0, 80, by = 10)}°F" 
    ),
    sec.axis = sec_axis(~ . + 10) 
  )

# scale_x|y_discrete()

g +
  scale_x_discrete(
    name = "Year", 
    expand = c(.1, .1) 
  )

g + 
  scale_x_discrete(
    name = "Year",
    expand = c(.1, .1),
    breaks = c(1997, 2000), 
    labels = c("MCMXCVII", "MMI") 
  )

# scale_x|y_reverse()

g + 
  #scale_x_reverse() + 
  ## doen't work with factors
  scale_y_reverse() 

# scale_x|y_log10()

g + 
  #scale_x_log10() +
  ## doen't work with factors
  scale_y_log10() 

# scale_x|y_sqrt()

g + 
  #scale_x_sqrt() + 
  ## doen't work with factors
  scale_y_sqrt() 

# scale_x|y_date()

chic %>% 
  filter(year %in% 1997:1998) %>% 
  ggplot(aes(temp, date)) +
  geom_point(aes(color = season)) +
  scale_y_date( 
    date_breaks = "1 month", 
    date_labels = "%Y-%m-%d", 
    expand = c(.01, .01) 
  ) 


## Color Scales: scale_color|fill_*() ##########################################

# All colors and fills that are mapped to categorical variables can be  manipu-
# lated with either scale_color|fill_discrete() or scale_color|fill_manual().

ggplot(chic, aes(date, temp,
                 color = season)) + 
  geom_point() +
  scale_color_discrete( 
    type = c("#91A3E1", "#83B692", 
             "#F9ADA0", "#CD6FD5") 
  ) 

ggplot(chic, aes(date, temp,
                 color = season)) + 
  geom_point() +
  scale_color_manual( 
    values = c("#91A3E1", "#83B692", 
               "#F9ADA0", "#CD6FD5") 
  )

# scale_color|fill_viridis_d()

# ggplot2 comes with all viridis palettes:

ggplot(chic, aes(date, temp, 
                 color = season)) +
  geom_point() +
  scale_color_viridis_d( 
    option = "mako" 
  ) 

ggplot(chic, aes(date, temp, 
                 color = season)) + 
  geom_point() +
  scale_color_viridis_d( 
    option = "turbo" 
  ) 

ggplot(chic, aes(date, temp, 
                 color = season)) +
  geom_point() +
  scale_color_viridis_d(
    option = "mako", end = .9 
  )

ggplot(chic, aes(date, temp, 
                 color = season)) + 
  geom_point() +
  scale_color_viridis_d( 
    option = "turbo", direction = -1 
  ) 

# scale_color|fill_brewer

# ... and also with the Brewer palettes:

ggplot(chic, aes(date, temp, 
                 color = season)) +
  geom_point() +
  scale_color_brewer( 
    palette = "Set1" 
  ) 

ggplot(chic, aes(date, temp, 
                 color = season)) +
  geom_point() +
  scale_color_brewer( 
    palette = "Set2" 
  ) 

RColorBrewer::display.brewer.all() # to inspect all available palettes

# All colors and fills that are mapped to continuous variables can be 
# manipulated for example with scale_color|fill_continuous() or 
# scale_color|fill_gradient().

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_continuous( 
    type = "viridis" 
  ) 

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_gradient( 
    low = "#e8d8c3", high = "#1e4511" 
  ) 

# All scales come with some general and specific arguments to change the appearance:

# scale_color|fill_gradient2()

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_gradient2( 
    low = "#306e1b", 
    high = "#882e01", 
    mid = "grey85" 
  )

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_gradient2(
    low = "#306e1b", 
    high = "#882e01",
    mid = "grey85",
    midpoint = 30 
  )

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_gradient2(
    low = "#306e1b", 
    high = "#882e01",
    mid = "grey85",
    midpoint = mean(chic$o3) 
  )

# scale_color|fill_gradientn()

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_gradientn( 
    colors = c("grey90", "tan", 
               "orange", "firebrick") 
  ) 

ggplot(chic, aes(date, temp,
                 color = o3)) + 
  geom_point() +
  scale_color_gradientn(
    colors = 
      scico::scico(n = 100, palette = "lajolla") 
  )

# scale_color|fill_viridis_c()

# Continuous data can be colored in viridis palettes as well:

ggplot(chic, aes(date, temp, 
                 color = o3)) +
  geom_point() +
  scale_color_viridis_c(
    option = "mako", direction = -1 
  )

ggplot(chic, aes(date, temp, 
                 color = o3)) + 
  geom_point() +
  scale_color_viridis_c( 
    option = "inferno", end = .9 
  ) 

# scale_color|fill_distiller()

# ... and also with the Brewer palettes:

ggplot(chic, aes(date, temp, 
                 color = o3)) +
  geom_point() +
  scale_color_distiller( 
    palette = "PuRd" 
  ) 

ggplot(chic, aes(date, temp, 
                 color = o3)) +
  geom_point() +
  scale_color_distiller( 
    palette = "Spectral" 
  ) 


## Other Scales: scale_shape|linetype|size|alpha_*()

# The same logic applies to the other aesthetics:

ggplot(chic, aes(date, temp,
                 shape = year)) + 
  geom_point(fill = "red") +
  scale_shape_manual( 
    values = 21:24 
  ) 

ggplot(chic, aes(date, temp,
                 linetype = year)) + 
  geom_line() +
  scale_linetype_manual( 
    values = 3:6 
  )

ggplot(chic, aes(date, temp,
                 size = o3)) + 
  geom_point(alpha = .5) +
  scale_size( 
    range = c(.5, 3.5) 
  ) 

ggplot(chic, aes(date, temp,
                 alpha = o3)) + 
  geom_point() +
  scale_alpha( 
    range = c(.2, .8) 
  )


## Coordinate System: coord_*()

# Coordinate systems produce a 2d position based on the relative geometric 
# arrangement of the two position aesthetics (usually x and y).

# The meaning of the position aesthetics depends on the coordinate system used: 

#  * Linear coordinate systems that preserve the shape of geoms:
#       + coord_cartesian():the default with two fixed perpendicular oriented axes
#       + coord_flip():a Cartesian coordinate system with flipped axes
#       + coord_fixed():a Cartesian coordinate system with a fixed aspect ratio

#  * Non-linear coordinate systems that likely change the shapes:
#       + coord_map() and coord_sf():map projections
#       + coord_polar():a polar coordinate system
#       + coord_trans():arbitrary transformations to x and y positions

# coord_cartesian(

# coord_*() functions allow you to zoom in a plot:

ggplot(chic, aes(date, temp)) +
  geom_line() +
  coord_cartesian(ylim = c(50, 70)) 

# Note that data points outside the plot area are not removed!

# In case you want to remove those data points, use 
# scale_y_continuous(limits = c(min, max)).

ggplot(chic, aes(date, temp)) +
  geom_line() +
  scale_y_continuous(limits = c(50, 70)) 

ggplot(chic, aes(season, temp)) +
  geom_boxplot()  +
  coord_cartesian(ylim = c(50, 70)) 

ggplot(chic, aes(season, temp)) +
  geom_boxplot()  +
  scale_y_continuous(limits = c(50, 70)) 

# coord_*() is also used to *prevent clipping* of points and correct alignment 
# of axis ticks:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  coord_cartesian(
    ylim = c(0, 75),
    clip = "off" 
  )

ggplot(chic, aes(date, temp)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0) 
  ) + 
  coord_cartesian(ylim = c(0, 75))

ggplot(chic, aes(date, temp)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0)
  ) + 
  coord_cartesian(
    ylim = c(0, 75), 
    clip = "off"
  )

# coord_fixed()

# coord_fixed() forces a specified ratio as physical representation of units 
# on the axes:

ggplot(chic, aes(temp, o3)) +
  geom_point() +
  coord_fixed() 

ggplot(chic, aes(temp, o3)) +
  geom_point() +
  coord_fixed() +
  scale_x_continuous( 
    breaks = seq(0, 100, by = 20) 
  ) 

ggplot(chic, aes(temp, o3)) +
  geom_point() +
  coord_fixed(
    ratio = 3 
  ) +
  scale_x_continuous(
    breaks = seq(0, 100, by = 20)
  )

# coord_flip()

# coord_flip() allows you to flip a Cartesian coordinate system:

ggplot(chic, aes(season, temp)) +
  geom_boxplot() +
  coord_cartesian() 

ggplot(chic, aes(season, temp)) +
  geom_boxplot() +
  coord_flip() 

ggplot(chic, aes(temp, season)) + 
  geom_boxplot() +
  coord_cartesian()

ggplot(chic, aes(season, temp)) +
  geom_boxplot() +
  coord_flip()

# coord_polar()

# You can easily transform a rectangular coordinate system into a polar one 
# with coord_polar():

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean,
               geom = "col") +
  coord_cartesian()

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean,
               geom = "col") +
  coord_polar() 

ggplot(chic, aes(season, temp)) +
  stat_summary(fun = mean,
               geom = "col") +
  coord_polar(theta = "y") 

ggplot(chic, aes(1, temp, fill = season)) +
  stat_summary(fun = mean,
               geom = "col",
               position = "stack") +
  coord_cartesian()

ggplot(chic, aes(1, temp, fill = season)) +
  stat_summary(fun = mean,
               geom = "col",
               position = "stack") +
  coord_polar(theta = "y") 


## Facets: facet_*() ###########################################################

# Create small multiples based on one or several variables.

# facet_wrap()

# facet_wrap() splits the data into small multiples based on one grouping variable:

ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(vars(season)) 

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(~ season) 

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(
    vars(year) 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(
    vars(year), 
    scales = "free" 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(
    vars(year), 
    scales = "free_x" 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(
    vars(year), 
    nrow = 4 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(
    vars(year), 
    ncol = 3 
  )


# facet_grid()

# facet_grid() spans a grid of each combination of two grouping variables:

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(vars(season), vars(year)) 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(season ~ year) 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(year ~ season) 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(
    year ~ season,
    scales = "free" 
  )

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(
    year ~ season,
    scales = "free",
    space = "free" 
  )


## Your Turn! ------------------------------------------------------------------

# Create the following visualization with the iris data set:
# see file `Exercise-3.png`

#------------------------------------------------------------------------------#


## Themes: theme_*() and theme()

# Themes control the display of all non-data elements of the plot:
#   * titles  
#   * labels
#   * fonts
#   * background + borders
#   * gridlines
#   * legends

# Themes can be modified for each plot by calling theme() and element_ functions

# Themes can be used to give plots a consistent customized look by defining a 
# custom theme usingtheme_update() or theme_set()


# theme_*()

# We have already seen several build-in theme examples in the beginning:

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_grey() +
  ggtitle("theme_grey()  or  theme_gray()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_classic() +
  ggtitle("theme_classic()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_bw() +
  ggtitle("theme_bw()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_light() +
  ggtitle("theme_light()")

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_minimal() +
  ggtitle("theme_minimal()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_dark() +
  ggtitle("theme_dark()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_linedraw() +
  ggtitle("theme_linedraw()")

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_void() +
  ggtitle("theme_void()") 

# You can set themes for each plot or globally for the current session with 
# theme_set():

theme_set(theme_light()) 

(g <- ggplot(chic, aes(temp, o3)) +
    geom_point(aes(color = season)))

ggplot(chic, aes(date, temp)) +
  geom_line(color = "grey60") +
  geom_point(aes(color = o3)) +
  scale_color_distiller(palette = 8)

# theme_*(base_size)

# Themes have a base_size argument which is a simple way to increase or decrease the font size:

theme_set(theme_light(base_size = 32))

g

theme_set(theme_light(base_size = 16))

g

g + theme_bw(base_size = 5) 

g + theme_dark(base_size = 50) 


# theme_*(base_family)

# You can also set the font of the theme via base_family:

theme_set(theme_light(
  base_size = 20,
  base_family = "Roboto Mono"
))

g

theme_set(theme_light(
  base_size = 20,
  base_family = "Bangers"
))

g

# reset theme
theme_set(theme_light(base_size = 16))


# theme() Arguments

# There are many elements you can customize. You can either group them by their 
# type or by their category:

# element types: 
#   - text -> all labels, axis text, legend title and text
#   - line -> axis lines, ticks, grid lines
#   - rect -> plot area, panel area, legend and legend keys, facets

# element category:
#   - axis.* -> titles, text, ticks, lines
#   - legend.* -> background, margin, spacing, keys, text, title, position, direction, box
#   - panel.* -> background, border, margin, spacing, grid (major and minor)
#   - plot.* -> background, title, subtitle, caption, tag, margin
#   - strip.* -> background, placement, text


# Text Elements via element_text()

# element_text(
#   family = "Roboto",
#   face = "bold", ## plain, italic, bolditalic
#   size = 18,
#   color = "red",
#   lineheight = .7,
#   angle = 180,
#   hjust = .5,
#   vjust = .0,
#   margin = margin(
#     10, ## t (top)
#     0,  ## r (right)
#     30, ## b (bottom)
#     0   ## l (left)
#   )
# )


# Line Elements via element_line()

# element_line(
#   color = "red",
#   size = 10,
#   linetype = "dashed",
#   lineend = "square", ## round, butt
#   arrow = arrow(
#     angle = 30, 
#     length = unit(0.25, "inches")
#   )
# )


# Rectangular Elements via element_rect()

# element_rect(
#   color = "orange",
#   fill = "black",
#   size = 2,
#   linetype = "dotted"
# )


# Adjust Theme Elements

# You can directly alter the appearance by adding `theme()` to a ggplot:

g +
  ggtitle("My Plot") + 
  theme( 
    plot.title = element_text(
      color = "blue", hjust = .5,
      size = 20, face = "bold.italic"
    ),
    axis.title = element_text(
      face = "bold"
    ),
    panel.grid.major.x = element_line(
      linetype = "dashed"
    )
  )

g +
  ggtitle("My Plot") + 
  theme(
    plot.title = element_text(
      color = "blue", hjust = .5,
      size = 20, face = "bold.italic"
    ),
    axis.title = element_text(
      face = "bold"
    ),
    panel.grid.major.x = element_line(
      linetype = "dashed"
    ),
    panel.grid.minor = element_blank(), 
    legend.title = element_blank() 
  )

# ... or update the theme gobally via theme_update():

theme_set(theme_bw(base_size = 15))

theme_update( 
  plot.title = element_text(
    color = "blue", hjust = .5,
    size = 20, face = "bold.italic"
  ),
  axis.title = element_text(
    face = "bold"
  ),
  panel.grid.major.x = element_line(
    linetype = "dashed"
  ),
  panel.grid.minor = element_blank(),
  legend.title = element_blank()
)

g + ggtitle("My Plot")


# Positions
# legend.position = "top" ## bottom, right, left
# legend.position = "none"
# legend.position = c(.2, .8) ## x, y
# 
# plot.title.position = "plot" ## panel
# plot.caption.position = "plot"

# You can quickly change the positions:

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = "top",
    plot.title.position = "plot"
  )

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = "none",
    plot.title.position = "panel"
  )


## Your Turn! ------------------------------------------------------------------

# * Have a closer look at the code of theme_grey and of the one you have chosen 
#   in lecture 3. What's the difference? 

# * Create a plot and change the theme to be as ugly as possible!

# * If you like, build your own theme by editing theme_grey or updating one of 
#   the others. You could also search for other themes provided by extension 
#   packages.

#------------------------------------------------------------------------------#


## Wrap-Up ---------------------------------------------------------------------

## compact syntax
ggplot(chic, aes(yday, temp)) +
  geom_smooth(se = FALSE, color = "black") +
  geom_point(aes(fill = season), size = 3, shape = 21, color = "white", stroke = .4, alpha = .7) +
  geom_point(size = 3, shape = 21, fill = "transparent", color = "white", stroke = .4) +
  facet_wrap(vars(year)) +
  scale_x_continuous(breaks = c(1, 1:6*50, 365)) +
  scale_y_continuous(labels = function(x) paste0(x, "°F")) +
  scale_fill_brewer(palette = "Dark2", name = NULL) +
  labs(x = "Day of the Year", y = "Temperature",
       caption = "Data: National Morbidity and Mortality Air Pollution Study (NMMAPS)") +
  theme_light(base_size = 18, base_family = "Aileron") +
  theme(legend.position = "top",
        panel.grid.minor = element_blank(),
        plot.caption = element_text(color = "grey40", margin = margin(t = 15)),
        strip.text = element_text(size = 20, face = "bold"),
        legend.text = element_text(size = 18))

# long syntax
ggplot(
  chic, 
  aes(
    x = yday, 
    y = temp
  )) +
  geom_smooth(
    se = FALSE,
    color = "black"
  ) +
  geom_point(
    aes(fill = season), 
    size = 3, 
    shape = 21, 
    color = "white", 
    stroke = .4, 
    alpha = .7
  ) +
  geom_point(
    size = 3, 
    shape = 21, 
    fill = "transparent", 
    color = "white", 
    stroke = .4
  ) +
  facet_wrap(
    vars(year)
  ) +
  scale_x_continuous(
    breaks = c(1, 1:6*50, 365)
  ) +
  scale_y_continuous(
    labels = function(x) paste0(x, "°F")
  ) +
  scale_fill_brewer(
    palette = "Dark2", name = NULL
  ) +
  labs(
    x = "Day of the Year", 
    y = "Temperature",
    caption = "Data: National Morbidity and Mortality Air Pollution Study (NMMAPS)"
  ) +
  theme_light(
    base_size = 18, 
    base_family = "Aileron"
  ) +
  theme(
    legend.position = "top",
    panel.grid.minor = element_blank(),
    plot.caption = element_text(color = "grey40", margin = margin(t = 15)),
    strip.text = element_text(size = 20, face = "bold"),
    legend.text = element_text(size = 18)
  )



## More Talks & Content --------------------------------------------------------

# https://github.com/z3tt/OutlierConf2021/
# https://z3tt.github.io/beyond-bar-and-box-plots/
# https://youtu.be/8ikFe82Mb1I


## Resources -------------------------------------------------------------------

# “ggplot2: Elegant Graphics for Data Analysis”, free–access book by Hadley Wickham et al.
# https://ggplot2-book.org/

# “R for Data Science”, free–access book by Hadley Wickham
# https://4ds.had.co.nz

# “Data Visualization: A Practical Introduction”, free–access book by Kieran Healy
# https://socviz.co

# “Fundamentals of Data Visualization”, free–access book by Claus Wilke
#https://clauswilke.com/dataviz/

# {ggplot2} reference
# https://ggplot2.tidyverse.org/reference/

# {ggplot2} cheatsheet
# https://github.com/rstudio/cheatsheets/raw/master/data-visualization-2.1.pdf

# Overview of layers contained in the {ggplot2} package
# https://ggplot2.tidyverse.org/reference/

# R Graph Gallery that provides hundreds of charts with their reproducible code
# https://www.r-graph-gallery.com/

# “A {ggplot2} Tutorial for Beautiful Plotting in R”, my extensive "how to"-tutorial
# https://www.cedricscherer.com/2019/08/05/a-ggplot2-tutorial-for-beautiful-plotting-in-r/

#------------------------------------------------------------------------------#
