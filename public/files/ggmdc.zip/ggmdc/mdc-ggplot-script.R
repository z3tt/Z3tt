################################################################################
#                                                                              #
#    Effective Workflows for Creating Publication-Ready Data Visualizations    #
#                 Exploring Advanced Techniques with ggplot2                   #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                               November 4, 2025                               #
#                                                                              #
################################################################################


## Setup =======================================================================

# install.packages("ggplot2") # run once after installing R
library(ggplot2) # run every time you open R

ggplot() # a function
diamonds # a data set

pkgs <- c(
  "readr", "dplyr", "stringr", "lubridate", "purrr", "scales", "colorspace",
  "systemfonts", "ggbeeswarm", "ggdist", "ggridges", "ggpointdensity",
  "ggdensity", "ggtext", "ggrepel", "ggforce", "concaveman", "patchwork", "remotes"
)
install.packages(setdiff(pkgs, rownames(installed.packages())))

remotes::install_github("AllanCameron/geomtextpath")

# to install the previous version of ggplot2:
# install.packages("remotes")
# remotes::install_version(
#   package = "ggplot2", version = "3.5.2", repos = "http://cran.us.r-project.org"
# )

gapminder <- readr::read_csv("./data/gapminder-1950-2023.csv")
# gapminder <- readr::read_csv(file.path("data", "gapminder-1950-2023.csv"))
# gapminder <- readr::read_csv(here::here("data", "gapminder-1950-2023.csv"))
# gapminder <- readr::read_csv("https://www.cedricscherer.com/data/gapminder-1950-2023")

library(dplyr)
glimpse(gapminder)


## A Basic ggplot ==============================================================

ggplot(data = gm_2023)

ggplot(data = gm_2023) +
  aes(x = gdp_pcap, y = life_exp)

ggplot(data = gm_2023) +
  aes(x = gdp_pcap, y = life_exp)

ggplot(data = gm_2023, mapping = aes(x = gdp_pcap, y = life_exp))

ggplot(gm_2023, aes(gdp_pcap, life_exp))

ggplot(data = gm_2023, aes(x = gdp_pcap, y = life_exp))

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_smooth()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_text(
    aes(label = country)
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      color = continent,
      size = pop
    )
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      color = continent == "Europe",
      size = pop
    ),
    alpha = .5
  )

ggplot(
  data = gm_2023,
  aes(
    x = gdp_pcap, y = life_exp,
    color = continent,
    size = pop
  )
) +
  geom_point(
    alpha = .5
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "GDP per capita (int$)",
    y = "Life expectancy at birth (years)",
    color = "Continent:",
    size = "Population:"
  )

ggplot(
  data = gm_2023,
  aes(
    x = gdp_pcap, y = life_exp,
    color = continent,
    size = pop
  )
) +
  geom_point(
    alpha = .5
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "GDP per capita (int$)",
    y = NULL,
    color = NULL,
    size = "Population:"
  )

ggplot(
  data = gm_2023,
  aes(
    x = gdp_pcap, y = life_exp,
    color = continent,
    size = pop
  )
) +
  geom_point(
    alpha = .5
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "GDP per capita (int$)",
    y = "",
    color = NULL,
    size = "Population:"
  )

g1 <-
  ggplot(
    data = gm_2023,
    aes(x = gdp_pcap, y = life_exp)
  ) +
  geom_point(
    aes(
      color = continent,
      size = pop
    ),
    alpha = .7
  ) +
  labs(
    title = "Gapminder World",
    subtitle = "Health & Income of Nations in 2023",
    caption = "Source: Gapminder project",
    x = "GDP per capita (int$)",
    y = "Life expectancy (years)",
    color = NULL,
    size = "Population:"
  )

g1 + geom_smooth()


## Scales ======================================================================

g1 +
  # default scales:
  # x ⇄ gdp_pcap
  scale_x_continuous() +
  # y ⇄ life_exp
  scale_y_continuous() +
  # color ⇄ continent
  scale_color_discrete() +
  # size ⇄ pop
  scale_size()

g1 +
  coord_cartesian() + # default
  scale_x_log10()

g1 +
  coord_trans(x = "log10") +
  scale_x_continuous() # default

g1 +
  geom_smooth(method = "lm") +
  scale_x_log10()

g1 +
  geom_smooth(method = "lm") +
  coord_trans(x = "log10")

ggplot(
  data = gm_2023,
  aes(x = continent, y = life_exp)
) +
  geom_boxplot() +
  scale_y_continuous(limits = c(70, NA))

ggplot(
  data = gm_2023,
  aes(x = continent, y = life_exp)
) +
  geom_boxplot() +
  coord_cartesian(ylim = c(70, NA))

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = c("#00D9EE", "#4CF101", "#FF4670", "#FFE702", "#CA4ADC")
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = c(Africa = "#00D9EE", Americas = "#4CF101", Asia = "#FF4670", Europe = "#FFE702", Oceania = "#CA4ADC")
  )

pal <- c(Africa = "#00D9EE", Americas = "#4CF101", Asia = "#FF4670", Europe = "#FFE702", Oceania = "#CA4ADC")
pal_dark <- colorspace::darken(pal, .2)
pal_dark

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = pal_dark
  )

g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = pal_dark
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(
      scale = 1 / 10^6,
      suffix = "M"
    )
  )

g2 <- g1 +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(),
    name = "GDP per capita (int$, log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = pal_dark
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(
      scale = 1 / 10^6,
      suffix = "M"
    )
  )


## Theming =====================================================================

g2 + theme_grey() # or theme_gray()

g2 + theme_classic()

g2 + theme_light()

g2 +
  theme_light(
    base_size = 10, # default is 11
    base_family = "Asap Condensed"
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Bitter"
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Bitter",
    header_family = "Asap Condensed"
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Bitter",
    header_family = "Asap Condensed",
    paper = "#F8F8F8", # ggplot v4
    ink = "turquoise4" # ggplot v4
  )

g2 +
  geom_smooth() +
  theme_light(
    base_size = 13,
    base_family = "Bitter",
    header_family = "Asap Condensed",
    paper = "#F8F8F8",
    ink = "turquoise4", # ggplot v4
    accent = "darkorange" # ggplot v4
  )

g2 +
  theme_light(
    base_size = 13,
    base_family = "Asap Condensed"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(
      face = "bold"
    ),
    plot.title.position = "plot",
    plot.caption.position = "plot",
    panel.background = element_rect(
      fill = "#F8F8F8", color = NA
    )
  )


## Working with Themes =========================================================

set_theme(theme_light())
# theme_set(theme_light()) in ggplot2 v3

g2

set_theme(theme_light(
  base_size = 13,
  base_family = "Asap Condensed"
))

g2

update_theme( # theme_update() in ggplot2 v3
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  plot.caption.position = "plot",
  panel.background = element_rect(
    fill = "#F8F8F8", color = NA
  )
)

g2

theme_grey

theme_minimal

theme_asap <- function(base_family = "Asap Condensed", base_size = 13,
                       base_line_size = base_size / 22, base_rect_size = base_size / 22,
                       ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  theme_minimal(
    base_family = base_family, base_size = base_size,
    base_line_size = base_line_size, base_rect_size = base_rect_size,
    ink = ink, paper = paper, accent = accent, ...
  ) %+replace%
    theme(
      plot.title = element_text(
        size = rel(1.3), face = "bold",
        margin = margin(b = base_size / 2), hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(
        color = "grey30", margin = margin(t = base_size),
        size = rel(0.8), hjust = 1, vjust = 1
      ),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, vjust = 0, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, vjust = 0, angle = 90, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      panel.grid.minor = element_blank(),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      complete = TRUE
    )
}

g2 +
  theme_asap()

theme_asap_plus <- function(base_family = "Asap Condensed", base_size = 13,
                            base_line_size = base_size / 22, base_rect_size = base_size / 22,
                            ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  theme_minimal(
    base_family = base_family, base_size = base_size,
    base_line_size = base_line_size, base_rect_size = base_rect_size,
    ink = ink, paper = paper, accent = accent, ...
  ) +
    theme(
      plot.title = element_text(
        size = rel(1.3), face = "bold",
        margin = margin(b = base_size / 2), hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(
        color = "grey30", margin = margin(t = base_size),
        size = rel(0.8), hjust = 1, vjust = 1
      ),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, vjust = 0, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, vjust = 0, angle = 90, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      panel.grid.minor = element_blank(),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0))
    )
}

g2 + theme_asap()

g2 + theme_asap_plus()

g2 +
  theme_asap() +
  theme(
    legend.background = element_rect(
      fill = "white", color = "grey20"
    )
  )

g2 +
  theme_asap(
    base_size = 10,
    base_family = "Bitter"
  )

g2 +
  theme_asap(
    base_size = 10,
    header_family = "Bitter"
  )

g2 +
  theme_asap(
    base_size = 10
  ) +
  theme(
    plot.title = element_text(
      family = "Bitter", face = "bold"
    )
  )

theme_asap_title <- function(base_size = 13, base_family = "Asap Condensed", title_family = "Bitter",
                             base_line_size = base_size / 22, base_rect_size = base_size / 22,
                             ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  theme_minimal(
    base_size = base_size, base_family = base_family,
    base_line_size = base_line_size, base_rect_size = base_rect_size,
    ink = ink, paper = paper, accent = accent, ...
  ) +
    theme(
      plot.title = element_text(family = title_family, size = rel(1.3), face = "bold", hjust = 0),
      plot.title.position = "plot",
      plot.caption = element_text(color = "grey30", margin = margin(t = base_size)),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, angle = 90, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      plot.background = element_rect(fill = "#F8F8F8", color = NA),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      panel.grid.minor = element_blank()
    )
}

g2 +
  theme_asap_title()

g2 +
  theme_asap_title(
    base_family = "Times",
    title_family = "Mono"
  )

theme_fonts <- function(base_family = "Asap Condensed", title_family = "Bitter", ...) {
  unavailable <- vector("character")

  if (sum(grepl("Bitter", systemfonts::system_fonts()$family)) == 0) {
    title_family <- ""
    unavailable <- c(unavailable, "Bitter")
  }

  if (sum(grepl("Asap Condensed", systemfonts::system_fonts()$family)) == 0) {
    base_family <- ""
    unavailable <- c(unavailable, "Asap Condensed")
  }

  if (length(unavailable) > 0) {
    unavailable <- data.frame(
      name = unavailable,
      url = paste0("https://fonts.google.com/specimen/", sub(" ", "+", unavailable))
    )
    message(paste(
      "Using system default typefaces.",
      "For proper use, please install the following typeface(s):",
      paste0("  - ", unavailable$name, ": ", unavailable$url, collapse = "\n"),
      "Then restart your R session.",
      sep = "\n"
    ))
  }

  theme_asap(...) +
    theme(
      plot.title = element_text(size = rel(1.3), hjust = 0, family = title_family)
    )
}

g2 + theme_fonts()

theme_asap_grid <- function(base_size = 13, base_family = "Asap Condensed", grid = "xy",
                            base_line_size = base_size / 22, base_rect_size = base_size / 22,
                            ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  out <-
    theme_minimal(
      base_size = base_size, base_family = base_family,
      base_line_size = base_line_size, base_rect_size = base_rect_size,
      ink = ink, paper = paper, accent = accent, ...
    ) +
    theme(
      plot.title = element_text(
        size = rel(1.3), margin = margin(b = base_size / 2),
        family = "Asap Condensed Extrabold", hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(color = "grey30", margin = margin(t = base_size)),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      plot.background = element_rect(fill = "#F8F8F8", color = NA),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank(),
      axis.ticks = element_line(color = "grey20"),
      axis.ticks.length = unit(base_size / 2, "pt")
    )

  if (grepl(grid, "x|X")) {
    out <- out + theme(
      panel.grid.major.x = element_line(color = "grey87"),
      axis.ticks.x = element_blank(),
      axis.ticks.length.x = unit(base_line_size, "pt")
    )
  }
  if (grepl(grid, "y|Y")) {
    out <- out + theme(
      panel.grid.major.y = element_line(color = "grey87"),
      axis.ticks.y = element_blank(),
      axis.ticks.length.y = unit(base_line_size, "pt")
    )
  }

  return(out)
}

g2 + theme_asap_grid(grid = "y")

g2 + theme_asap_grid(grid = "none")

g2 + theme_asap_grid(grid = "y")

g2 + theme_asap_grid(grid = "all")

theme_asap_grid <- function(base_size = 13, base_family = "Asap Condensed", grid = "xy",
                            base_line_size = base_size / 22, base_rect_size = base_size / 22,
                            ink = "#292929", paper = "#F8F8F8", accent = "#3366FF", ...) {
  if (!grepl(grid, "none|x|X|y|Y")) stop('grid must be a character: "none" or any combination of "X", "Y", "x" and "y".')

  out <-
    theme_minimal(
      base_size = base_size, base_family = base_family,
      base_line_size = base_line_size, base_rect_size = base_rect_size,
      ink = ink, paper = paper, accent = accent, ...
    ) +
    theme(
      plot.title = element_text(
        size = rel(1.3), margin = margin(b = base_size / 2),
        family = "Asap Condensed Extrabold", hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(color = "grey30", margin = margin(t = base_size)),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      plot.background = element_rect(fill = "#F8F8F8", color = NA),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank(),
      axis.ticks = element_line(color = "grey20"),
      axis.ticks.length = unit(base_size / 2, "pt")
    )

  if (grepl(grid, "x|X")) {
    out <- out + theme(
      panel.grid.major.x = element_line(color = "grey87"),
      axis.ticks.x = element_blank(),
      axis.ticks.length.x = unit(base_line_size, "pt")
    )
  }
  if (grepl(grid, "y|Y")) {
    out <- out + theme(
      panel.grid.major.y = element_line(color = "grey87"),
      axis.ticks.y = element_blank(),
      axis.ticks.length.y = unit(base_line_size, "pt")
    )
  }

  return(out)
}

g2 +
  theme_asap_grid(
    grid = "all"
  )

set_theme(theme_asap(base_size = 14))


## Programming with ggplot2 ====================================================

smooth <- TRUE

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  {
    if (smooth) geom_smooth(color = "red")
  } +
  geom_point(alpha = .5)

smooth <- FALSE

ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
  {
    if (smooth) geom_smooth(color = "red")
  } +
  geom_point(alpha = .5) +
  scale_x_log10()

draw_scatter <- function(smooth = TRUE) {
  ggplot(gm_2023, aes(x = fertility, y = life_exp)) +
    {
      if (smooth) geom_smooth(color = "red")
    } +
    geom_point(alpha = .5)
}

draw_scatter()

draw_scatter(smooth = FALSE)

geom_scatterfit <- function(pointsize = 1, pointalpha = 1,
                            method = "lm", linecolor = "red", ...) {
  list(
    geom_point(size = pointsize, alpha = pointalpha, ...),
    geom_smooth(method = method, color = linecolor, ...)
  )
}

ggplot(
  data = gm_2023,
  aes(x = fertility, y = life_exp)
) +
  geom_scatterfit()

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit() +
  coord_trans(x = "log10")

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit(
    color = "#28A87D",
    linewidth = 3
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit(
    pointsize = .5,
    pointalpha = .1,
    method = "loess",
    linecolor = "#EFAC00"
  ) +
  coord_trans(x = "log10")

scales_log <- function(sides = "xy") {
  list(
    if (grepl(sides, "x")) {
      scale_x_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    },
    if (grepl(sides, "y")) {
      scale_y_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    }
  )
}


ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = income_daily)
) +
  geom_scatterfit(
    pointsize = .5,
    pointalpha = .1,
    method = "loess",
    linecolor = "#EFAC00"
  ) +
  scales_log(sides = "x")

bikes <- readr::read_csv(
  "https://cedricscherer.com/data/london-bikes-custom.csv",
  col_types = "Dcfffilllddddc"
) |>
  mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE))

glimpse(bikes)

trends_monthly <- function(grp = "January") {
  bikes |>
    dplyr::filter(month %in% grp) |>
    ggplot(aes(x = temp, y = count, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    scale_color_manual(values = c("#FFA200", "#757bc7")) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}

trends_monthly("July")

trends_monthly <- function(grp = "January") {
  bikes |>
    dplyr::filter(month %in% grp) |>
    ggplot(aes(x = temp, y = count, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    # keep axis ranges consistent
    scale_x_continuous(limits = range(bikes$temp)) +
    scale_y_continuous(limits = range(bikes$count)) +
    scale_color_manual(values = c("#FFA200", "#757bc7")) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}

trends_monthly("July")



plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
plots[[9]]

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
patchwork::wrap_plots(plots)

plot_density <- function(data, var, grp = NULL) {
  ggplot(data, aes(x = !!sym(var))) +
    {
      if (is.null(grp)) geom_density(fill = "grey80", color = "grey30")
    } +
    {
      if (!is.null(grp)) {
        geom_density(
          aes(fill = !!sym(grp)),
          position = "identity",
          color = "grey30", alpha = .3
        )
      }
    } +
    scale_fill_brewer(palette = "Dark2", name = NULL) +
    scale_x_continuous(expand = c(0, 0)) +
    scale_y_continuous(
      labels = scales::label_number(),
      expand = expansion(mult = c(0, 0.05))
    ) +
    theme(legend.position = "top")
}

plot_density(
  bikes, "count"
)

plot_density(
  bikes, "count",
  grp = "day_night"
)

plots <- purrr::map(
  c("count", "temp", "humidity", "wind_speed"),
  ~ plot_density(data = bikes, var = .x, grp = "day_night")
)
patchwork::wrap_plots(plots, nrow = 1)

plots <- purrr::map(
  names(select(gm_2023, c("life_exp", "fertility"))),
  ~ plot_density(data = gm_2023, var = .x, grp = "continent")
)
patchwork::wrap_plots(plots)

plots <- purrr::map(
  names(select(midwest, where(is.numeric))),
  ~ plot_density(data = midwest, var = .x)
)
patchwork::wrap_plots(plots)


## More Chart Types! ===========================================================

## Visualizing Distributions

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  geom_boxplot()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  geom_violin()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  geom_violin() +
  geom_boxplot(width = .2)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(priority = "descending")

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(side = -1)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(method = "hex", size = 1.5, cex = 2)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_quasirandom()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_quasirandom(method = "smiley")

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_eye()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye() ## default: `.width = c(.66, .95)`

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = .5)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = c(0, 1))

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = c(0, 1), adjust = .5, shape = 23, point_size = 5)

ggplot(bikes, aes(x = season, y = humidity, fill = day_night)) +
  ggdist::stat_halfeye(.width = 0, adjust = .5, slab_alpha = .5, shape = 21) +
  scale_fill_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval()

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25, linewidth = 10) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25) +
  ggdist::stat_dots(position = position_nudge(x = .05), scale = .8) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(gm_2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25) +
  ggdist::stat_halfeye(.width = 0, color = "white", position = position_nudge(x = .025)) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(gm_2023, aes(x = life_exp, y = continent)) +
  ggridges::geom_density_ridges()

ggplot(bikes, aes(x = humidity, y = season, fill = day_night)) +
  ggridges::geom_density_ridges(alpha = .5)

ggplot(gm_compare, aes(x = life_exp, y = continent, fill = factor(year))) +
  ggridges::geom_density_ridges(alpha = .5, color = "white", scale = 1.5) +
  scale_fill_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)


## Visualizing x-y Relationships ===============================================

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  geom_point(size = 3, alpha = .5)

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  geom_point(size = 3, alpha = .1)

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  ggpointdensity::geom_pointdensity(size = 2)

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  ggpointdensity::geom_pointdensity(size = 2, adjust = .5) +
  scale_color_gradient(low = "#FFCE52", high = "#663399")

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  geom_point(alpha = .02, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines()

ggplot(gm_compare, aes(x = life_exp, y = fertility, color = factor(year))) +
  geom_point(alpha = .2, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines() +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(gm_compare, aes(x = life_exp, y = fertility, color = factor(year))) +
  geom_point(alpha = .2, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines(method = "mvnorm", probs = c(.95, .75, .5, .25, .1)) +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  ggdensity::geom_hdr_points(method = "histogram", probs = c(.95, .5, .1), size = 3, alpha = .7) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  geom_density_2d_filled() +
  coord_cartesian(expand = FALSE) +
  theme(legend.position = "top")

ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  ggdensity::geom_hdr(probs = seq(.999, .2, length.out = 5)) +
  coord_cartesian(expand = FALSE) +
  theme(legend.position = "top")


## Appendix ====================================================================

## Export Graphics =============================================================

# ggsave(g, filename = "my_plot.png")

# ggsave("my_plot.png")

# ggsave("my_plot.png", width = 8, height = 5, dpi = 600)

# ggsave("my_plot.pdf", width = 20, height = 12, unit = "cm", device = cairo_pdf)


## Facets ======================================================================

g2 +
  facet_wrap(
    vars(continent)
  )

g2 +
  facet_wrap(
    ~continent
  )

g2 +
  facet_wrap(
    ~continent,
    ncol = 1 # or nrow = 5
  )

g2 +
  facet_wrap(
    ~continent,
    scales = "free"
  )

g2 +
  facet_wrap(
    ~continent,
    scales = "free_y",
    space = "free_y"
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  # only works with ggplot v4
  geom_point(
    color = "grey75",
    size = .7,
    layout = "fixed"
  ) +
  geom_point(size = 1) +
  scale_x_log10() +
  facet_wrap(
    ~continent
  )

ggplot(
  data = gm_2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  # works with older versions as well
  geom_point(
    data = select(gm_2023, -continent),
    color = "grey75",
    size = .7
  ) +
  geom_point(size = 1) +
  scale_x_log10() +
  facet_wrap(
    ~continent
  )


## Working with Text ===========================================================

## Text Rendering ==============================================================

g2 +
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007",
    size = "&rarr; Population:"
  )

library(ggtext)

g2 +
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.title = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )

g2 +
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007 of nations around the world with bubbles colored by continent and sized by population",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.title = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )

g2 +
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007 of nations around the world with bubbles colored by continent and sized by population",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.title = element_textbox_simple(
      fill = "#F8F8F8",
      box.colour = "red",
      linetype = "solid",
      padding = margin(8, 12, 6, 12),
      margin = margin(b = 12),
    ),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )

g2 +
  geom_richtext(
    aes(
      label = "My <b style='color:#28a87d;'>fancy</b><br>annotation",
      x = 35000, y = 70,
      family = "Bitter"
    )
  )


## Clever Annotation ===========================================================

g2 +
  ggrepel::geom_label_repel(
    data = filter(gm_2023, pop > 190000000),
    aes(
      label = country,
      color = continent
    )
  )

g2 +
  ggrepel::geom_label_repel(
    data = filter(gm_2023, pop > 190000000),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE
  )

g2 +
  ggrepel::geom_label_repel(
    data = filter(gm_2023, pop > 190000000),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Asap Condensed",
    ylim = 83,
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))

g2 +
  geom_point(
    data = filter(gm_2023, pop > 190000000),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = filter(gm_2023, pop > 190000000),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Asap Condensed",
    ylim = c(83, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))

g2 +
  geom_point(
    data = filter(gm_2023, pop > 190000000),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = filter(gm_2023, pop > 190000000),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Asap Condensed",
    ylim = c(83, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))

ggplot(
  data = penguins,
  aes(
    x = flipper_len, y = body_mass,
    color = species
  )
) +
  geom_point()

ggplot(
  data = penguins,
  aes(
    x = flipper_len, y = body_mass,
    color = species
  )
) +
  geom_point() +
  ggforce::geom_mark_ellipse(
    aes(
      label = species,
      color = species
    )
  ) +
  theme(legend.position = "none")

ggplot(
  data = penguins,
  aes(
    x = flipper_len, y = body_mass,
    color = species
  )
) +
  geom_point() +
  ggforce::geom_mark_ellipse(
    aes(
      label = species,
      color = species
    )
  ) +
  scale_y_continuous(
    expand = expansion(mult = .3)
  ) +
  theme(legend.position = "none")

ggplot(
  data = penguins,
  aes(
    x = flipper_len, y = body_mass,
    color = species
  )
) +
  geom_point() +
  ggforce::geom_mark_ellipse(
    aes(
      label = species,
      color = species,
      filter = species == "Gentoo"
    )
  )

ggplot(
  data = penguins,
  aes(
    x = flipper_len, y = body_mass,
    color = species
  )
) +
  geom_point() +
  ggforce::geom_mark_hull(
    aes(
      label = species,
      color = species,
      filter = species == "Gentoo"
    ),
    alpha = .5,
    linewidth = 1,
    expand = .02,
    description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    label.family = c("Bitter", "Asap Condensed"),
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )

ggplot(
  data = penguins,
  aes(
    x = flipper_len, y = body_mass,
    color = species
  )
) +
  geom_point() +
  ggforce::geom_mark_hull(
    aes(
      label = species,
      color = species,
      filter = species == "Gentoo"
    ),
    alpha = .5,
    size = 1,
    expand = .02,
    description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    label.family = c("Bitter", "Asap Condensed"),
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )

gm_trends <- filter(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geom_line(
    linewidth = 1
  )

gm_trends <- filter(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geom_line(
    linewidth = 1
  ) +
  geom_text(
    data = filter(gm_trends, year == 1997),
    aes(label = country),
    family = "Asap Condensed",
    fontface = "bold",
    vjust = -.5
  ) +
  theme(legend.position = "none")

gm_trends <- filter(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Asap Condensed",
    fontface = "bold"
  ) +
  theme(legend.position = "none")

gm_trends <- filter(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Asap Condensed",
    fontface = "bold",
    hjust = .8,
    halign = "left",
    straight = TRUE
  ) +
  theme(legend.position = "none")
