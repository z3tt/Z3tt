################################################################################
#                                                                              #
#    Effective Workflows for Creating Publication-Ready Data Visualizations    #
#                 Exploring Advanced Techniques with ggplot2                   #
#                                                                              #
#                      Proposed Solutions to the Exercises                     #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                               November 4, 2025                               #
#                                                                              #
################################################################################


library(ggplot2)
library(dplyr)

gapminder <- readr::read_csv("./data/gapminder-1950-2023.csv")


## Exercise 1.1 ================================================================

gapminder_pop <-
  readr::read_csv("./data/gapminder-1950-2023.csv") |>
  filter(country %in% c("India", "China", "USA"))

gapminder_pop <- filter(
  gapminder, country %in% c("India", "China", "USA")
)

ggplot(
  data = gapminder_pop,
  aes(x = year, y = co2_pcap)
) +
  geom_line()

ggplot(
  data = gapminder_pop,
  aes(x = year, y = co2_pcap)
) +
  geom_line(
    aes(color = country)
  )

ggplot(
  data = gapminder_pop,
  aes(x = year, y = co2_pcap)
) +
  geom_line(
    aes(color = country)
  ) +
  geom_point()

ggplot(
  data = gapminder_pop,
  aes(x = year, y = co2_pcap)
) +
  geom_line(
    aes(color = country)
  ) +
  geom_point(
    aes(color = country)
  )

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point()

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    shape = "diamond",
    size = 2
  )

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    shape = 18,
    size = 2
  )

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    aes(shape = country),
    size = 2
  )


## Exercise 1.2 ================================================================

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    shape = 18,
    size = 2
  ) +
  labs(
    x = "Year",
    y = "Per-person CO₂ emission (tonnes)",
    color = NULL,
    title = "Americans Stand Out in CO₂ Emissions",
    subtitle = "Comparison of the world’s three most populous countries"
  )

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    aes(shape = country),
    size = 2
  ) +
  labs(
    x = NULL,
    y = "Per-person CO₂ emission (tonnes)",
    color = NULL,
    title = "Americans Stand Out in CO₂ Emissions",
    subtitle = "Comparison of the world’s three most populous countries"
  )

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    aes(shape = country),
    size = 2
  ) +
  labs(
    x = NULL,
    y = "Per-person CO₂ emission (tonnes)",
    color = NULL,
    shape = NULL,
    title = "Americans Stand Out in CO₂ Emissions",
    subtitle = "Comparison of the world’s three most populous countries"
  )

plot_emissions <- ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = country
  )
) +
  geom_line() +
  geom_point(
    shape = 18,
    size = 2
  ) +
  labs(
    x = NULL,
    y = "CO₂ emission per person",
    color = NULL,
    title = "Americans Stand Out in CO₂ Emissions",
    subtitle = "Comparison of the world’s three most populous countries"
  )

plot_emissions

plot_emissions +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  )

plot_emissions +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot",
    plot.caption.position = "plot"
  )

plot_emissions +
  scale_color_manual(
    values = c(`China` = "#a041d0", `India` = "#25a177", `USA` = "#d55e00")
  ) +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

plot_emissions +
  scale_color_manual(
    values = c(`China` = "#a041d0", `India` = "#25a177", `USA` = "#d55e00"),
    breaks = c("USA", "China", "India")
  ) +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

ggplot(
  data = gapminder_pop,
  aes(
    x = year, y = co2_pcap,
    color = forcats::fct_reorder(
      country, -co2_pcap,
      .fun = last
    )
  )
) +
  geom_line() +
  geom_point(
    shape = 18,
    size = 2
  ) +
  labs(
    x = NULL,
    y = "Per-person CO₂ emission (tonnes)",
    color = NULL,
    title = "Americans Stand Out in CO₂ Emissions",
    subtitle = "Comparison of the world’s three most populous countries"
  ) +
  scale_color_manual(
    values = c(`China` = "#a041d0", `India` = "#25a177", `USA` = "#d55e00")
  ) +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

plot_emissions +
  scale_x_continuous(
    breaks = seq(1950, 2020, by = 10)
  ) +
  scale_y_continuous(
    labels = scales::label_number(suffix = " t")
  ) +
  scale_color_manual(
    values = c(`China` = "#a041d0", `India` = "#25a177", `USA` = "#d55e00"),
    breaks = c("USA", "China", "India")
  ) +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

plot_emissions +
  scale_x_continuous(
    breaks = seq(1950, 2020, by = 10)
  ) +
  scale_y_continuous(
    labels = function(x) paste(x, "t")
  ) +
  scale_color_manual(
    values = c(`China` = "#a041d0", `India` = "#25a177", `USA` = "#d55e00"),
    breaks = c("USA", "China", "India")
  ) +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

plot_emissions +
  scale_x_continuous(
    breaks = seq(1950, 2020, by = 10)
  ) +
  scale_y_continuous(
    labels = scales::label_dollar()
  ) +
  scale_color_manual(
    values = c(`China` = "#a041d0", `India` = "#25a177", `USA` = "#d55e00"),
    breaks = c("USA", "China", "India")
  ) +
  theme_light(
    base_size = 12,
    base_family = "Bitter"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot",
    legend.position = "inside",
    legend.position.inside = c(.8, .6)
  )

ggsave("carbon-footprint.png", width = 8, height = 5, dpi = 600)

ggsave("carbon-footprint_landscape.png", width = 8, height = 5, dpi = 600)
ggsave("carbon-footprint_portrait.png", width = 5, height = 8, dpi = 600)


## Exercise 2.1 ================================================================

gapminder |>
  filter(year == 2023) |>
  ggplot(aes(x = gdp_pcap, y = life_exp)) +
  geom_point(
    aes(
      size = pop,
      color = continent != "Asia",
      alpha = continent != "Asia"
    ),
    shape = 16
  ) +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(accuracy = 1)
  ) +
  scale_color_manual(
    values = c("darkorange", "black"),
    guide = "none"
  ) +
  scale_alpha_manual(
    values = c(9, .1),
    guide = "none"
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
  ) +
  labs(
    title = "Health & Income 2023: Asia",
    x = "GDP per capita ($ adjusted for price differences)",
    y = "Life expectancy (years)",
    size = "Population"
  ) +
  theme_minimal(base_family = "Asap Condensed", base_size = 15) +
  theme(
    panel.grid.minor = element_blank(),
    legend.text = element_text(hjust = 1),
    legend.text.position = "left",
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

gapminder |>
  filter(year == 2023) |>
  ggplot(aes(x = gdp_pcap, y = life_exp)) +
  geom_point(
    aes(
      size = pop,
      color = continent != "Asia",
      alpha = continent != "Asia"
    ),
    shape = 16
  ) +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(accuracy = 1)
  ) +
  scale_color_manual(
    values = c("#9C55E3", "black"),
    guide = "none"
  ) +
  scale_alpha_manual(
    values = c(.8, .2),
    guide = "none"
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
  ) +
  labs(
    title = "Health & Income 2023: <b style='color: #9C55E3'>Asia</b>",
    x = "GDP per capita ($ adjusted for price differences)",
    y = "Life expectancy (years)",
    size = "Population"
  ) +
  theme_minimal(base_family = "Asap Condensed", base_size = 15) +
  theme(
    panel.grid.minor = element_blank(),
    legend.text = element_text(hjust = 1),
    legend.text.position = "left",
    plot.title = ggtext::element_markdown(face = "bold"),
    plot.title.position = "plot"
  )

draw_gp_continent <- function(group) {
  gapminder |>
    filter(year == 2023) |>
    ggplot(aes(x = gdp_pcap, y = life_exp)) +
    geom_point(
      aes(
        size = pop,
        color = continent != group,
        alpha = continent != group
      ),
      shape = 16
    ) +
    scale_x_log10(
      breaks = 1000 * 2^(0:3 * 2),
      labels = scales::label_dollar(accuracy = 1)
    ) +
    scale_color_manual(
      values = c("#9C55E3", "black"),
      guide = "none"
    ) +
    scale_alpha_manual(
      values = c(.8, .2),
      guide = "none"
    ) +
    scale_size_area(
      max_size = 12,
      breaks = 1 * 10^(6:9),
      labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
    ) +
    labs(
      title = paste0("Health & Income 2023: <b style='color: #9C55E3'>", group, "</b>"),
      x = "GDP per capita ($ adjusted for price differences)",
      y = "Life expectancy (years)",
      size = "Population"
    ) +
    theme_minimal(base_family = "Asap Condensed", base_size = 15) +
    theme(
      panel.grid.minor = element_blank(),
      legend.text = element_text(hjust = 1),
      legend.text.position = "left",
      plot.title = ggtext::element_markdown(face = "bold"),
      plot.title.position = "plot"
    )
}

draw_gp_continent("Asia")

draw_gp_continent("Africa")

draw_gp_continent("Europe")

draw_gp_continent_year <- function(Continent, Year = 2023) {
  gapminder |>
    filter(year == Year) |>
    ggplot(aes(x = gdp_pcap, y = life_exp)) +
    geom_point(
      aes(
        size = pop,
        color = continent != Continent,
        alpha = continent != Continent
      ),
      shape = 16
    ) +
    scale_x_log10(
      breaks = 1000 * 2^(0:3 * 2),
      labels = scales::label_dollar(accuracy = 1)
    ) +
    scale_color_manual(
      values = c("#9C55E3", "black"),
      guide = "none"
    ) +
    scale_alpha_manual(
      values = c(.8, .2),
      guide = "none"
    ) +
    scale_size_area(
      max_size = 12,
      breaks = 1 * 10^(6:9),
      labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
    ) +
    labs(
      title = paste0("Health & Income ", Year, ": <b style='color: #9C55E3'>", Continent, "</b>"),
      x = "GDP per capita ($ adjusted for price differences)",
      y = "Life expectancy (years)",
      size = "Population"
    ) +
    theme_minimal(base_family = "Asap Condensed", base_size = 15) +
    theme(
      panel.grid.minor = element_blank(),
      legend.text = element_text(hjust = 1),
      legend.text.position = "left",
      plot.title = ggtext::element_markdown(face = "bold"),
      plot.title.position = "plot"
    )
}

draw_gp_continent_year("Asia")

draw_gp_continent_year("Asia", 1950)

draw_gp_continent_year("Europe", 1990)


## Exercise 2.2 ================================================================

gapminder |>
  filter(year == 2023) |>
  ggplot(aes(x = gdp_pcap, y = life_exp)) +
  geom_point(
    aes(size = pop),
    alpha = .5, color = "grey60"
  ) +
  geom_point(
    data = filter(gapminder, year == 2023, country %in% c("USA", "Brazil")),
    aes(size = pop),
    color = "#9C55E3", show.legend = FALSE
  ) +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(accuracy = 1)
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
  ) +
  labs(
    x = "GDP per capita ($ adjusted for price differences)",
    y = "Life expectancy (years)",
    size = "Population"
  ) +
  theme_minimal(base_family = "Asap Condensed", base_size = 15) +
  theme(panel.grid.minor = element_blank())

gapminder |>
  filter(year == 2023) |>
  ggplot(aes(x = gdp_pcap, y = life_exp)) +
  geom_point(
    aes(size = pop),
    alpha = .5, color = "grey60"
  ) +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      filter = country %in% c("USA", "Brazil"),
      group = country
    ),
    expand = unit(16, "pt"), con.cap = unit(0, "mm"),
    label.family = "Asap Condensed", label.fontsize = 15
  ) +
  geom_point(
    data = filter(gapminder, year == 2023, country %in% c("USA", "Brazil")),
    aes(size = pop),
    color = "#9C55E3", show.legend = FALSE
  ) +
  scale_x_log10(
    breaks = 1000 * 2^(0:3 * 2),
    labels = scales::label_dollar(accuracy = 1)
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1 * 10^(6:9),
    labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
  ) +
  labs(
    x = "GDP per capita ($ adjusted for price differences)",
    y = "Life expectancy (years)",
    size = "Population"
  ) +
  theme_minimal(base_family = "Asap Condensed", base_size = 15) +
  theme(panel.grid.minor = element_blank())

draw_gp_country <- function(Country, Year) {
  gapminder |>
    filter(year == 2023) |>
    ggplot(aes(x = gdp_pcap, y = life_exp)) +
    geom_point(
      aes(size = pop),
      alpha = .5, color = "grey60"
    ) +
    ggforce::geom_mark_circle(
      aes(
        label = country,
        filter = country %in% Country,
        group = country
      ),
      expand = unit(16, "pt"), con.cap = unit(0, "mm"),
      label.family = "Asap Condensed", label.fontsize = 15
    ) +
    geom_point(
      data = filter(gapminder, year == 2023, country %in% Country),
      aes(size = pop),
      color = "#9C55E3", show.legend = FALSE
    ) +
    scale_x_log10(
      breaks = 1000 * 2^(0:3 * 2),
      labels = scales::label_dollar(accuracy = 1)
    ) +
    scale_size_area(
      max_size = 12,
      breaks = 1 * 10^(6:9),
      labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
    ) +
    labs(
      x = "GDP per capita ($ adjusted for price differences)",
      y = "Life expectancy (years)",
      size = "Population"
    ) +
    theme_minimal(base_family = "Asap Condensed", base_size = 15) +
    theme(
      panel.grid.minor = element_blank(),
      legend.text = element_text(hjust = 1),
      legend.text.position = "left"
    )
}

draw_gp_country(c("USA", "Brazil"))

draw_gp_country(c("South Korea", "North Korea"))

draw_gp_country("Germany")

draw_gp_country("India")
