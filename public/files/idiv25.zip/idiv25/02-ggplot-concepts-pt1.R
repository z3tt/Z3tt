#------------------------------------------------------------------------------#
#                                                                              #
#                          Crafting Publication-Ready                          #
#                       Data Visualizations with ggplot2                       #
#                                                                              #
#                        The Concepts of ggplot2, Pt. 1                        #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                           iDiv Workshop April 2025                           #
#                                                                              #
#------------------------------------------------------------------------------#


pkgs <- c("ggplot2", "readr", "dplyr", "here", "camcorder")

install.packages(setdiff(pkgs, rownames(installed.packages())))


library(ggplot2)

bikes <- readr::read_csv(
  # here::here("data", "london-bikes-custom.csv"),
  "https://cedricscherer.com/data/london-bikes-custom.csv",
  col_types = "Dcfffilllddddc"
)

?ggplot

ggplot(data = bikes)

ggplot(data = bikes) +
  aes(x = temp, y = count)

ggplot(data = bikes) +
  aes(x = temp, y = count)

ggplot(data = bikes, mapping = aes(x = temp, y = count))

ggplot(bikes, aes(temp, count))

ggplot(bikes, aes(x = temp, y = count))

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point()

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    color = "#28a87d",
    alpha = .5,
    shape = "X",
    stroke = 1,
    size = 4
  )

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    color = "#28a87d",
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    aes(color = temp > 20),
    alpha = .5
  )

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_histogram()

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_histogram(
    bins = 100 
    # binwidth = 1
  )

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_histogram(
    aes(fill = day_night)
  )

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_density(
    aes(color = day_night)
  )

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_density(
    aes(color = day_night,
        fill = day_night),
    alpha = .3
  )

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_density(
    aes(color = day_night,
        fill = day_night),
    alpha = .3,
    position = "stack"
  )

ggplot(
    bikes, 
    aes(x = humidity)
  ) +
  geom_density(
    aes(color = day_night,
        fill = day_night),
    alpha = .3,
    position = "fill"
  )

ggplot(
    bikes, 
    aes(x = temp, y = count)
  ) +
  geom_point()

ggplot(
    bikes, 
    aes(x = temp, y = count)
  ) +
  geom_bin2d()

ggplot(
    bikes, 
    aes(x = temp, y = count)
  ) +
  geom_hex()

ggplot(
    bikes, 
    aes(x = temp, y = count)
  ) +
  geom_density2d()

ggplot(
    bikes, 
    aes(x = temp, y = count)
  ) +
  geom_density2d(
    aes(color = day_night)
  )

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_density2d_filled()

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp, y = count,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp, y = count,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )

ggplot(bikes, aes(x = date, y = temp)) +
  geom_point(stat = "identity") # default

ggplot(bikes, aes(x = date, y = temp)) +
  stat_identity(geom = "point") # default

ggplot(bikes, aes(x = weather_type)) +
  geom_bar(stat = "count") # default

ggplot(bikes, aes(x = weather_type)) +
  stat_count(geom = "bar") # default

ggplot(bikes, aes(x = temp, y = count)) +
  geom_smooth(stat = "smooth") # default

ggplot(bikes, aes(x = temp, y = count)) +
  stat_smooth(geom = "smooth") # default

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary() 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = mean_se, # default
    geom = "pointrange"  # default
  ) 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  geom_boxplot() +
  stat_summary(
    fun = mean,
    geom = "point",
    shape = 23,
    stroke = .8,
    fill = "#79DFBD",
    size = 4
  ) 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun = mean, 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y) 
  ) 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun = mean, 
    fun.max = function(foo) mean(foo) + sd(foo), 
    fun.min = function(foo) mean(foo) - sd(foo)
  ) 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1)
  )

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = mean,
    size = 2
  ) 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = mean,
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = mean,
    aes(label = after_stat(y))
  ) 

ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = mean,
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = mean,
    aes(label = after_stat(
      sprintf("%2.1f", y)
    )),
    hjust = -.3
  ) 

## don't do this!
ggplot(
    bikes, 
    aes(x = season,  
        y = lubridate::wday(date, label = TRUE), 
        fill = count)
  ) +
  geom_tile() 

ggplot(
    bikes, 
    aes(x = season,  
        y = lubridate::wday(date, label = TRUE), 
        z = count)
  ) +
  stat_summary_2d() 

ggplot(
    bikes, 
    aes(x = season,  
        y = lubridate::wday(date, label = TRUE), 
        z = count)
  ) +
  stat_summary_2d(
    fun = "sum"
  ) 

ggplot(
    bikes, 
    aes(x = season,  
        y = lubridate::wday(date, label = TRUE), 
        z = count)
  ) +
  stat_summary_2d(
    fun = "sum", 
    color = "white", 
    linewidth = .7
  ) 

g <-
  ggplot(
    bikes,
    aes(x = temp, y = count,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )

class(g)

g$data

g$mapping

gbuilt <- ggplot_build(g)
names(gbuilt)

head(gbuilt$data[[1]])

head(gbuilt$data[[2]])

g +
  geom_rug(
    alpha = .2
  )

g +
  geom_rug(
    alpha = .2,
    show.legend = FALSE
  )

g +
  xlab("Temperature (°C)") +
  ylab("Reported bike shares") +
  ggtitle("TfL bike sharing trends")

g +
  labs(
    x = "Temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends"
  )

g <- g +
  labs(
    x = "Temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    color = "Season:"
  )

g

g +
  labs(
    x = "Temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    subtitle = "Reported bike rents versus temperature in London",
    caption = "Data: TfL",
    color = "Season:",
    tag = "Fig. 1"
  )

g +
  labs(
    x = "",
    caption = "Data: TfL"
  )

g +
  labs(
    x = NULL,
    caption = "Data: TfL"
  )

g + theme_light()

g + theme_minimal()

g + theme_light(
  base_size = 14,
  base_family = "Asap SemiCondensed"
)

theme_set(theme_light())

g

theme_set(theme_light(
  base_size = 14,
  base_family = "Asap SemiCondensed"
))

g

g +
  theme(
    panel.grid.minor = element_blank()
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold")
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "top"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "none"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "top",
    plot.title.position = "plot"
  )

theme_update(
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  legend.position = "top",
  plot.title.position = "plot"
)

g

## ggsave(filename = "my_plot.png", plot = g)

## ggsave("my_plot.png")

## ggsave("my_plot.png", width = 6, height = 5, dpi = 600)

## ggsave("my_plot.png", width = 6*2.54, height = 5*2.54, unit = "cm", dpi = 600)

## ggsave("my_plot.png", device = agg_png)

## ggsave("my_plot.pdf", device = cairo_pdf)

## ggsave("my_plot.svg")

## camcorder::gg_record(
##   dir = here::here("temp"),  # path for plot files
##   device = "png",            # device to use
##   width = 10,                # figure width
##   height = 5,                # figure height
##   dpi = 600                  # plot resolution
## )

## g <- ggplot(bikes, aes(x = temp, y = count, color = day_night)) +
##   geom_point(alpha = .3, size = 2) +
##   scale_color_manual(values = c(day = "#FFA200", night = "#757BC7")) +
##   theme_minimal(base_size = 14, base_family = "Asap SemiCondensed") +
##   theme(panel.grid.minor = element_blank())

## g

## camcorder::gg_resize_film(width = 20) # update figure width

## g
