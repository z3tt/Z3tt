################################################################################
#                                                                              #
#                          Crafting Publication-Ready                          #
#                       Data Visualizations with ggplot2                       #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                                September 2025                                #
#                                                                              #
################################################################################


## -----------------------------------------------------------------------------

install.packages("ggplot2") # run once after installing R
library(ggplot2)            # run every time you open R


## -----------------------------------------------------------------------------

ggplot() # a function
diamonds # a data set


## -----------------------------------------------------------------------------

pkgs <- c(
  "ggplot2", "readr", "dplyr", "patchwork", "scales", "ggrepel",
  "ggtext", "ggforce", "concaveman", "geomtextpath", "gapminder"
)


## -----------------------------------------------------------------------------

install.packages(setdiff(pkgs, rownames(installed.packages())))


## -----------------------------------------------------------------------------

library(gapminder)
gapminder


## -----------------------------------------------------------------------------

gapminder <- readr::read_csv("./data/gapminder.csv") |> 
  mutate(
    gapminder, income_lvl = case_when(
      gdpPercap < 1045 ~ "1",
      gdpPercap >= 1045 & gdpPercap < 4095 ~ "2",
      gdpPercap >= 4095 & gdpPercap < 12695 ~ "3",
      TRUE ~ "4"
    )
  )

gapminder


## -----------------------------------------------------------------------------

library(dplyr)
gm2007 <- filter(gapminder, year == 2007)
gm2007


## -----------------------------------------------------------------------------

gm_europe <- filter(gapminder, continent == "Europe")
gm_europe


## -----------------------------------------------------------------------------

?ggplot


## -----------------------------------------------------------------------------

ggplot(data = gm2007)


## -----------------------------------------------------------------------------

ggplot(data = gm2007) +
  aes(x = gdpPercap, y = lifeExp)


## -----------------------------------------------------------------------------

ggplot(data = gm2007) + aes(x = gdpPercap, y = lifeExp)

ggplot(data = gm2007, mapping = aes(x = gdpPercap, y = lifeExp))

ggplot(gm2007, aes(gdpPercap, lifeExp))

ggplot(data = gm2007, aes(x = gdpPercap, y = lifeExp))


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = log10(gdpPercap), y = lifeExp)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_text(
    aes(label = country)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_smooth()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point() +
  geom_smooth(linewidth = 2)


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_smooth(linewidth = 2) +
  geom_point()

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    color = "#28a87d",
    alpha = .5,
    shape = 8,
    stroke = 1.2,
    size = 2
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    color = "#28a87d"
  )

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    color = "#28a87d",
    size = 3
  )

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent,
        size = pop)
  )


## -----------------------------------------------------------------------------

# wrong encoding
ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = "#28A87D"),
    alpha = .5
  )


## -----------------------------------------------------------------------------

# returns error
ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    color = continent,
    alpha = .7
  )


## -----------------------------------------------------------------------------

pop <- 12345678

# wrong encoding
ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    color = pop,
    alpha = .5
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = lifeExp),
    alpha = .5
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = lifeExp >= 75),
    alpha = .5
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent == "Europe"),
    alpha = .5
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent == "Europe",
        size = continent == "Europe"),
    alpha = .5
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent),
    alpha = .7
  )

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent)
  ) +
  geom_point(
    alpha = .7
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent),
    alpha = .7
  ) +
  geom_smooth()

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent)
  ) +
  geom_point(
    alpha = .7
  ) +
  geom_smooth()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent)
  ) +
  geom_point(
    alpha = .7
  ) +
  geom_smooth(color = "black")


## -----------------------------------------------------------------------------

ggplot(
    data = gm_europe,
    aes(x = year, y = lifeExp)
  ) +
  geom_line()


## -----------------------------------------------------------------------------

ggplot(
    data = gm_europe,
    aes(x = year, y = lifeExp,
        group = country)
  ) +
  geom_line()


## -----------------------------------------------------------------------------

ggplot(
    data = gm_europe,
    aes(x = year, y = lifeExp,
        group = country)
  ) +
  geom_line(
    alpha = .25
  ) +
  geom_line(
    data = filter(gm_europe, country == "Germany"),
    color = "red",
    size = 1
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm_europe,
    aes(x = year, y = lifeExp,
        group = country)
  ) +
  geom_line(
    alpha = .25
  ) +
  geom_line(
    data = filter(gm_europe, country %in% c("Germany", "Turkey")),
    aes(color = country),
    size = 1
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = continent)
  ) +
  geom_bar()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = continent)
  ) +
  geom_bar()

ggplot(
    data = count(gm2007, continent), 
    aes(x = continent, y = n)
  ) +
  geom_col()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap)
  ) +
  geom_histogram()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap)
  ) +
  geom_histogram(
    bins = 50 
    # binwidth = 1000
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap)
  ) +
  geom_histogram(
    aes(fill = continent)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(color = continent)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(color = continent,
        fill = continent),
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(color = continent,
        fill = continent),
    alpha = .3,
    position = "fill"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_bin2d()

ggplot(
    data = gm2007, 
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_hex()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007, 
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_density2d()

ggplot(
    data = gm2007, 
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_density2d_filled()


## -----------------------------------------------------------------------------

# don't do this! 
ggplot(
  data = gm2007, 
  aes(x = continent,  
      y = income_lvl,
      fill = lifeExp)
) +
  geom_tile()


## -----------------------------------------------------------------------------

# do this:
ggplot(
  data = gm2007, 
  aes(x = continent,  
      y = income_lvl,
      z = lifeExp)
) +
  geom_tile( 
    stat = "summary_2d", 
    binwidth = 1
  ) 


## -----------------------------------------------------------------------------

# or this:
ggplot(
  data = gm2007, 
  aes(x = continent,  
      y = income_lvl,
      z = lifeExp)
) +
  geom_tile( 
    stat = "summary_2d",
    fun = median,
    binwidth = 1
  ) 


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------
## EXERCISE
## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------

ggsave(g, filename = "my_plot.png")

ggsave("my_plot.png")

ggsave("my_plot.png", width = 8, height = 5, dpi = 600)

ggsave("my_plot.pdf", width = 20, height = 12, unit = "cm", device = cairo_pdf)


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point(
    alpha = .5
  ) 


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "GDP per capita (US$, inflation-adjusted)",
    y = "Life expectancy at birth (years)"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "GDP per capita (US$, inflation-adjusted)",
    y = "Life expectancy at birth (years)",
    color = "Continent:",
    size = "Population:"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "GDP per capita (US$, inflation-adjusted)",
    y = NULL,
    color = NULL,
    size = "Population:"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "GDP per capita (US$, inflation-adjusted)",
    y = "",
    color = NULL,
    size = "Population:"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "GDP per capita (US$, inflation-adjusted)",
    y = "Life expectancy at birth (years)",
    color = "Continent:",
    size = "Population:",
    title = "Health & Income of Nations in 2007",
    caption = "Source: Gapminder project"
  )


## -----------------------------------------------------------------------------

g <-
  ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point(
    aes(color = continent, 
        size = pop),
    alpha = .7
  ) +
  labs(
    x = "GDP per capita",
    y = "Life expectancy",
    color = NULL,
    size = "Population:",
    title = "Health & Income of Nations in 2007"
  )


## -----------------------------------------------------------------------------

g


## -----------------------------------------------------------------------------

g + geom_smooth()


## -----------------------------------------------------------------------------

g + theme_grey() # or theme_gray()


## -----------------------------------------------------------------------------

g + theme_classic()


## -----------------------------------------------------------------------------

g + theme_minimal()


## -----------------------------------------------------------------------------

g + theme_bw()


## -----------------------------------------------------------------------------

g + 
  theme_bw(
    base_size = 15,
    base_family = "Asap Condensed"
  )


## -----------------------------------------------------------------------------

g + 
  theme_bw(
    base_size = 10,
    base_family = "Bitter"
  )


## -----------------------------------------------------------------------------

# only works with ggplot v4
g + 
  theme_bw(
    base_size = 10,
    base_family = "Bitter",
    paper = "#F8F8F8", 
    ink = "navy"
  )


## -----------------------------------------------------------------------------

# only works with ggplot v4
g +
  geom_smooth() + 
  theme_bw(
    base_size = 10,
    base_family = "Bitter",
    paper = "#F8F8F8", 
    ink = "navy", 
    accent = "red" 
  )


## -----------------------------------------------------------------------------

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot",
    panel.background = element_rect(
      fill = "#F8F8F8", color = NA
    )
  )


## -----------------------------------------------------------------------------

theme_set(theme_bw()) 
# set_theme(theme_bw()) in ggplot2 v4

g


## -----------------------------------------------------------------------------

theme_set(theme_bw(
  base_size = 15,
  base_family = "Asap Condensed"
))

g


## -----------------------------------------------------------------------------

theme_update( # update_theme() in ggplot2 v4
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  panel.background = element_rect(
    fill = "#F8F8F8", color = NA
  )
)


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, 
        y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point() +
  # default scales
  scale_x_continuous() + 
  scale_y_continuous() +
  scale_color_discrete() +
  scale_size()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, 
        y = lifeExp,
        color = continent,
        size = pop)
  ) +
  geom_point() +
  scale_x_continuous() + 
  # overwrite y scale
  scale_y_binned() +
  scale_color_discrete() +
  scale_size()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, 
        y = lifeExp,
        color = gdpPercap)
  ) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(width = .2) +
  # default scales
  scale_x_discrete() +
  scale_y_continuous() +
  scale_color_continuous()


## -----------------------------------------------------------------------------

g +
  scale_x_log10()


## -----------------------------------------------------------------------------

g +
  scale_x_log10( 
    labels = scales::label_comma()
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    limits = c(NA, 90)
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    limits = c(60, 75)
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    limits = c(NA, 90),
    breaks = seq(30, 90, by = 5)
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    limits = c(NA, 90),
    breaks = seq(30, 90, by = 5),
    expand = expansion(mult = 0, add = 0)
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_viridis_d()


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_discrete(
    type = c("royalblue", "orange", "magenta3", "forestgreen", "red")
  )


## -----------------------------------------------------------------------------

gapminder::continent_colors


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_manual(
    values = gapminder::continent_colors
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_brewer(
    palette = "Dark2"
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  scale_size(
    range = c(2, 10)
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  scale_size_area(
    max_size = 12
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1:4*250000000
  )


## -----------------------------------------------------------------------------

g +
  scale_x_log10(
    labels = scales::label_comma(),
    name = "GDP per capita (log scale)"
  ) +
  scale_y_continuous(
    breaks = seq(30, 90, by = 5)
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  scale_size_area(
    max_size = 12,
    breaks = 1:4*250000000, 
    labels = scales::label_comma(
      scale = 1 / 10^6,
      suffix = "M"
    )
  )


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------
## EXERCISE
## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = lifeExp)
  ) +
  geom_boxplot() +
  # default coordinate system
  coord_cartesian()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = lifeExp)
  ) +
  geom_boxplot() +
  coord_cartesian(
    ylim = c(60, NA)
  )

ggplot(
    data = gm2007,
    aes(x = continent, y = lifeExp)
  ) +
  geom_boxplot() +
  scale_y_continuous(
    limits = c(60, NA)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point() +
  coord_fixed()

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point() +
  coord_fixed(ratio = 1000)


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent)
  ) +
  geom_bar() +
  coord_cartesian()

ggplot(
    data = gm2007,
    aes(x = continent)
  ) +
  geom_bar() +
  coord_flip()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(y = continent)
  ) +
  geom_bar() +
  coord_cartesian()


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  geom_point() +
  geom_smooth(method = "lm") +
  coord_trans(x = "log10")


## -----------------------------------------------------------------------------

ggplot(
    data = filter(gm2007, continent != "Oceania"),
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(fill = continent)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = filter(gm2007, continent != "Oceania"),
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(fill = continent)
  ) +
  facet_wrap(
    vars(continent)
  )


## -----------------------------------------------------------------------------

ggplot(
    data = filter(gm2007, continent != "Oceania"),
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(fill = continent)
  ) +
  facet_wrap(
    ~ continent
  )


## -----------------------------------------------------------------------------

ggplot(
    data = filter(gm2007, continent != "Oceania"),
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(fill = continent), 
    alpha = .7
  ) +
  facet_wrap(
    ~ continent,
    ncol = 1 # or nrow = 4
  )


## -----------------------------------------------------------------------------

ggplot(
    data = filter(gm2007, continent != "Oceania"),
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(fill = continent), 
    alpha = .7
  ) +
  facet_wrap(
    ~ continent,
    scales = "free"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = filter(gm2007, continent != "Oceania"), 
    aes(x = gdpPercap)
  ) +
  geom_density(
    aes(fill = continent), 
    alpha = .7
  ) +
  facet_wrap(
    ~ continent,
    scales = "free_y"
  )


## -----------------------------------------------------------------------------

ggplot(
    penguins,  
    aes(x = flipper_len, y = body_mass)
  ) + 
  geom_point(
    alpha = .5
  ) +
  facet_grid(
    island ~ species
  )


## -----------------------------------------------------------------------------

ggplot(
    penguins,  
    aes(x = flipper_len, y = body_mass)
  ) + 
  # only works with ggplot v4
  geom_point(
    color = "grey85",
    layout = "fixed"
  ) +
  geom_point(
    alpha = .5
  ) +
  facet_grid(
    island ~ species
  )


## -----------------------------------------------------------------------------

ga <- 
  ggplot(gm2007, aes(x = gdpPercap, y = lifeExp)) +
  geom_point(aes(color = continent), size = 2, alpha = .5) +
  scale_x_log10() +
  scale_color_manual(values = continent_colors, name = "Continent:") +
  labs(x = "GDP per capita (log scale)", y = "Life expectancy")

gb <- 
  ggplot(gm2007, aes(x = continent, y = lifeExp)) +
  geom_boxplot(outlier.shape = NULL) +
  geom_jitter(aes(color = continent), width = .2, alpha = .5) +
  scale_color_manual(values = continent_colors, name = "Continent:") +
  labs(x = NULL, y = "Life expectancy")


## -----------------------------------------------------------------------------

library(patchwork)
ga + gb


## -----------------------------------------------------------------------------

ga / gb


## -----------------------------------------------------------------------------

ga + plot_spacer() + gb


## -----------------------------------------------------------------------------

ga + plot_spacer() + gb + 
  plot_layout(widths = c(1, .1, 1))


## -----------------------------------------------------------------------------

ga + plot_spacer() + gb + 
  plot_layout(widths = c(1, .1, 1), guides = "collect")


## -----------------------------------------------------------------------------

ga + theme(legend.position = "none") + plot_spacer() + gb +
  plot_layout(widths = c(1, .1, 1))


## -----------------------------------------------------------------------------

ga + theme(legend.position = "none") + plot_spacer() + gb +
  plot_layout(widths = c(1, .1, 1)) + 
  plot_annotation(tag_levels = "A", tag_suffix = ")")


## -----------------------------------------------------------------------------

library(ggtext)

g + 
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007",
    size = "&rarr; Population:"
  )


## -----------------------------------------------------------------------------

g +  
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.title = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )

## -----------------------------------------------------------------------------

g +  
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007 of nations around the world with bubbles colored by continent and sized by population",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.title = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )


## -----------------------------------------------------------------------------

g + 
  labs(
    x = "**GDP** *per capita*",
    y = "__Life expectancy__",
    title = "<i style='font-family:times;color:red'>Gapminder</i> — Health & Income in 2007 of nations around the world with bubbles colored by continent and sized by population",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.title = element_textbox_simple(
      fill = "#F8F8F8", 
      box.colour = "red",
      linetype = "solid",
      padding = margin(8, 12, 6, 12),
      margin = margin(b = 12),
    ),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )


## -----------------------------------------------------------------------------

g + 
  geom_richtext(
    aes(
      label = "My <b style='color:#28a87d;'>fancy</b><br>annotation",
      x = 35000, y = 70, 
      family = "Bitter"
    )
  )


## -----------------------------------------------------------------------------

g + 
  ggrepel::geom_label_repel(
    data = filter(gm2007, pop > 190000000),
    aes(label = country,
        color = continent)
  )


## -----------------------------------------------------------------------------

g + 
  ggrepel::geom_label_repel(
    data = filter(gm2007, pop > 190000000),
    aes(label = country,
        color = continent),
    show.legend = FALSE
  )


## -----------------------------------------------------------------------------

g + 
  ggrepel::geom_label_repel(
    data = filter(gm2007, pop > 190000000),
    aes(label = country,
        color = continent),
    show.legend = FALSE,
    family = "Asap Condensed",
    ylim  = 83,
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))


## -----------------------------------------------------------------------------

g + 
  geom_point(
    data = filter(gm2007, pop > 190000000),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = filter(gm2007, pop > 190000000),
    aes(label = country,
        color = continent),
    show.legend = FALSE,
    family = "Asap Condensed",
    ylim  = c(83, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))


## -----------------------------------------------------------------------------

g + 
  geom_point(
    data = filter(gm2007, pop > 190000000),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = filter(gm2007, pop > 190000000),
    aes(label = country,
        color = continent),
    show.legend = FALSE,
    family = "Asap Condensed",
    ylim  = c(83, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))


## -----------------------------------------------------------------------------

ggplot(
    data = penguins, 
    aes(x = flipper_len, y = body_mass,
        color = species)
  ) + 
  geom_point()


## -----------------------------------------------------------------------------

ggplot(
    data = penguins, 
    aes(x = flipper_len, y = body_mass,
        color = species)
  ) + 
  geom_point() + 
  ggforce::geom_mark_ellipse(
    aes(label = species, 
        color = species)
  ) +
  theme(legend.position = "none")


## -----------------------------------------------------------------------------

ggplot(
    data = penguins, 
    aes(x = flipper_len, y = body_mass,
        color = species)
  ) + 
  geom_point() + 
  ggforce::geom_mark_ellipse(
    aes(label = species, 
        color = species)
  ) +
  scale_y_continuous(
    expand = expansion(mult = .3)
  ) +
  theme(legend.position = "none")


## -----------------------------------------------------------------------------

ggplot(
    data = penguins, 
    aes(x = flipper_len, y = body_mass,
        color = species)
  ) + 
  geom_point() + 
  ggforce::geom_mark_ellipse(
    aes(label = species, 
        color = species,
        filter = species == "Gentoo")
  )


## -----------------------------------------------------------------------------

ggplot(
    data = penguins, 
    aes(x = flipper_len, y = body_mass,
        color = species)
  ) + 
  geom_point() + 
  ggforce::geom_mark_hull(
    aes(label = species, 
        color = species,
        filter = species == "Gentoo"),
    alpha = .5,
    linewidth = 1,
    expand = .02,
    description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    label.family = c("Bitter", "Asap Condensed"),
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )


## -----------------------------------------------------------------------------

ggplot(
    data = penguins, 
    aes(x = flipper_len, y = body_mass,
        color = species)
  ) + 
  geom_point() + 
  ggforce::geom_mark_hull(
    aes(label = species, 
        color = species,
        filter = species == "Gentoo"),
    alpha = .5,
    size = 1,
    expand = .02,
    description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    label.family = c("Bitter", "Asap Condensed"),
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )


## -----------------------------------------------------------------------------

gm_trends <- filter(gapminder, country %in% c("Germany", "China", "Turkey", "Zambia", "India"))

ggplot(
    data = gm_trends,
    aes(x = year, y = lifeExp,
        color = country)
  ) +
  geom_line(
    linewidth = 1
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm_trends,
    aes(x = year, y = lifeExp,
        color = country)
  ) +
  geom_line(
    linewidth = 1
  ) +
  geom_text(
    data = filter(gm_trends, year == 1997),
    aes(label = country),
    family = "Asap Condensed",
    fontface = "bold",
    vjust = -.5
  ) +
  theme(legend.position = "none")


## -----------------------------------------------------------------------------

ggplot(
    data = gm_trends,
    aes(x = year, y = lifeExp,
        color = country)
  ) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Asap Condensed",
    fontface = "bold"
  ) +
  theme(legend.position = "none")


## -----------------------------------------------------------------------------

ggplot(
    data = gm_trends,
    aes(x = year, y = lifeExp,
        color = country)
  ) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Asap Condensed",
    fontface = "bold", 
    hjust = .8,
    halign = "left",
    straight = TRUE
  ) +
  theme(legend.position = "none")


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  layer(
    geom = "point", 
    stat = "identity", ## do nothing
    position = "identity" ## do nothing
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  layer(
    geom = "line", 
    stat = "identity", ## do nothing
    position = "identity" ## do nothing
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = gdpPercap, y = lifeExp)
  ) +
  layer(
    geom = "smooth", 
    stat = "smooth", 
    position = "identity" ## do nothing
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_point(
    alpha = .3
  )

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_point(
    position = "identity", # default
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_point(
    position = "jitter",
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_point(
    position = position_jitter(
      width = .2
    ),
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_jitter(
    width = .2,
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_boxplot() +
  geom_jitter(
    width = .2,
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm2007,
    aes(x = continent, y = gdpPercap)
  ) +
  geom_boxplot(
    outlier.shape = NA
  ) +
  geom_jitter(
    width = .2,
    alpha = .3
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm_bars,
    aes(x = factor(year), y = gdpPercap)
  ) +
  geom_col(
    aes(fill = country),
    position = "stack" # default
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm_bars,
    aes(x = factor(year), y = gdpPercap)
  ) +
  geom_col(
    aes(fill = country),
    position = "dodge"
  )


## -----------------------------------------------------------------------------

ggplot(
    data = gm_bars,
    aes(x = factor(year), y = gdpPercap)
  ) +
  geom_col(
    aes(fill = country),
    position = position_dodge(
      width = .7
    ),
    width = .6
  )


## -----------------------------------------------------------------------------

bikes <-
  readr::read_csv(
    "https://cedricscherer.com/data/london-bikes-custom.csv",
    col_types = "Dcfffilllddddc"
  )


## -----------------------------------------------------------------------------

trends_monthly <- function(grp = "January") {
  bikes |> 
    mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = temp, y = count, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}


## -----------------------------------------------------------------------------

trends_monthly("July")


## -----------------------------------------------------------------------------

trends_monthly <- function(grp = "January") {
  bikes |> 
    mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = temp, y = count, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    # keep axis ranges consistent
    scale_x_continuous(limits = range(bikes$temp)) +
    scale_y_continuous(limits = range(bikes$count)) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}


## -----------------------------------------------------------------------------

trends_monthly("July")


## -----------------------------------------------------------------------------

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)

plots[[9]]


## -----------------------------------------------------------------------------

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)

patchwork::wrap_plots(plots)


## -----------------------------------------------------------------------------

plot_density <- function(data, var, grp = "") {
  ggplot(data, aes(x = !!sym(var))) +
    geom_density(aes(fill = !!sym(grp)), position = "identity",
                 color = "grey30", alpha = .3) +
    coord_cartesian(expand = FALSE, clip = "off") +
    scale_y_continuous(labels = scales::label_number()) +
    scale_fill_brewer(palette = "Dark2", name = NULL) +
    theme(legend.position = "top")
}


## -----------------------------------------------------------------------------

plot_density(
  bikes, "count"
)


## -----------------------------------------------------------------------------

plots <- purrr::map(
  c("count", "temp", "humidity", "wind_speed"), 
  ~ plot_density(data = bikes, var = .x, grp = "day_night")
)

patchwork::wrap_plots(plots, nrow = 1)


## -----------------------------------------------------------------------------

plots <- purrr::map(
  c("gdpPercap", "lifeExp"), 
  ~ plot_density(data = filter(gm2007, continent != "Oceania"), var = .x, grp = "continent")
)

patchwork::wrap_plots(plots, nrow = 1)


## -----------------------------------------------------------------------------

plots <- purrr::map(
  names(select(midwest, where(is.numeric))),
  ~plot_density(data = midwest, var = .x)
)

patchwork::wrap_plots(plots)


## -----------------------------------------------------------------------------
## THE END
## -----------------------------------------------------------------------------
