################################################################################
#                                                                              #
#                          LS Uppsala DataViz Course                           #
#        "Reproducible Data Visualizations Pt. 2" — Agentic Exercises          #
#                      Dr Cédric Scherer | November 2026                       #
#                                                                              #
################################################################################

# No setup beyond R + Positron (and the Vibe extension/CLI) — everything below
# runs on the data sets you already know from session 1
# (penguins ships with base R >= 4.5; mpg & diamonds with {ggplot2}):
#   mpg:      234 cars (displ, hwy, cty, class, drv, year, ...)
#   penguins: 344 penguins (species, island, bill_*, flipper_len, body_mass, ...)
#   diamonds: 53,940 diamonds (carat, cut, color, clarity, depth, table, price, ...)

# Workflow for every exercise:
#   1. Write the five-part prompt FIRST (context, task, constraints,
#      definition of done, verification ask) — before you open the agent.
#   2. Let the agent draft the code.
#   3. Review the diff before accepting (see the checklist below).
#
# Review checklist — what to check in a diff:
#   - one job per function
#   - snake_case object & argument names, data-first arguments
#   - no library() calls inside functions
#   - clarity over cleverness — code you can read wins


# ==============================================================================
# EXERCISE 1 — PROMPT BEFORE YOU PEEK (~10 min)
# ==============================================================================

# Task: a horizontal barplot of the car classes in `mpg`, ordered,
# each bar labeled with the exact count.
#
# TODO 1: Write the five-part prompt as a comment block below.
#
#   # 1. Context:    ...
#   # 2. Task:       ...
#   # 3. Constraints: ...
#   # 4. Done when:  ...
#   # 5. Verify:     ...
#
# TODO 2: Run the prompt in the agent (Vibe extension panel or CLI) and let it
#         write the code into this file or into `02-exercise-1.qmd`.
# TODO 3: Review the diff against the checklist above before you accept.


# ==============================================================================
# EXERCISE 2 — REVIEW THE AGENT'S DRAFT (~10 min)
# ==============================================================================

# The code below is "agent output" with planted issues — exactly the kind of
# draft you will receive. Review it WITHOUT running it first: what to check
# in a diff (see checklist at the top)?

agent_draft <- function(Data, Column) {
  library(dplyr)
  library(ggplot2)
  d <- Data %>%
    filter(!is.na(Column)) %>%
    count(Column) %>%
    arrange(desc(n))
  xp <- ggplot(d, aes(x = n, y = reorder(Column, n))) +
    geom_col(fill = "purple") +
    labs(title = "Counts", x = NULL, y = NULL)
  print(xp)
  ggsave("plot.png")
  return(invisible(xp))
}
# agent_draft(data = mpg, Column = class)   # <-- don't run: that's the point

# TODO 1: List every issue (there are at least 5 — count them against the
#         checklist, plus any you spot on your own).
# TODO 2: Write the follow-up prompt that asks the agent to fix them.
# TODO 3: Run that prompt and compare the agent's fix against your list.


# ==============================================================================
# EXERCISE 3 — FROM PROMPT TO POLISHED LINE CHART (~15 min)
# ==============================================================================

# Start from `diamonds` (ships with {ggplot2}) and end with a render-ready
# figure block for a report.
#
# Task: line chart of the average price per carat (carat rounded to 0.1) —
# where does the price per carat jump?
#
# TODO 1: Prompt the agent for a first draft. Constraints to state:
#         {ggplot2} only, 300 dpi PNG export, title that tells the insight,
#         three-part alt text (chart type → data → key insight).
# TODO 2: Review the draft — is the insight in the title? Is `carat` aggregated
#         (rounded/binned) before plotting, instead of a raw line over 53,940 rows?
# TODO 3: Ask the agent to run the verification pass on its own output:
#         colorblind-simulate (deuteranopia/protanopia/tritanopia),
#         grayscale recoverability, contrast: APCA Lc >= 75 for body text
#         (Lc 60 for large text; WCAG 2.x AA 4.5:1 remains the legal floor).
# TODO 4: Squint test: describe the final chart in one sentence — did the
#         agent's title match what you see?

# Starter scaffold (fill via the agent, or type along):
# Hint: aggregate first, e.g. round carat to 0.1, then mean price per carat
#       via aggregate(price ~ carat, data = diamonds, FUN = mean)
# ggplot(<agg>, aes(x = carat, y = price)) +
#   geom_line()


# ==============================================================================
# REFERENCE SOLUTION — EXERCISE 1 (example of a five-part prompt)
# ==============================================================================

#   1. Context: You are working in the R project `02-exercises.R` with the
#      built-in {ggplot2} dataset `mpg` (234 cars; column `class` is the car
#      type). Output goes into a PNG via ggsave().
#   2. Task: Create a horizontal barplot of the car classes in `mpg`,
#      ordered by frequency.
#   3. Constraints: {ggplot2} only; order bars most-to-least frequent (largest
#      on top); label each bar with the exact count; theme_minimal() base;
#      no rainbow palette.
#   4. Done when: the plot file `ex-1-classes.png` exists at 300 dpi and the
#      top bar is the most frequent class.
#   5. Verify: run the code, confirm the counts match `count(mpg, class)`,
#      check bar labels are not clipped, name anything you could not verify.

# =============================================================================
# REFERENCE SOLUTION — EXERCISE 2 (issues planted in agent_draft())
# =============================================================================

#  1. `library()` calls inside the function — load at the top of the script.
#  2. Data argument is NOT data-first (Data, Column) and names are CamelCase —
#     snake_case, data-first: `function(data, column)`.
#  3. Hard-coded fill = "purple" — no palette, no accessibility thought.
#  4. `ggsave("plot.png")` with no width/height/units/dpi — and it saves the
#     LAST printed plot, not necessarily `xp`.
#  5. Vague labels — title "Counts" tells the reader nothing.
#  6. `reorder(Column, n)` + prior `arrange(desc(n))` — redundant; one job per
#     function would separate computation from plotting.
#  7. No fig-alt / no insight — nothing a report could cite.

# A cleaned-up version (what the agent should converge toward):

plot_top_classes <- function(data, column, n_top = 10) {
  counts <- sort(table(data[[column]]), decreasing = TRUE)
  top <- head(counts, n_top)
  df <- data.frame(class = names(top), n = as.integer(top))
  ggplot(df, aes(x = n, y = reorder(class, n))) +
    geom_col(fill = "#00978A") +
    labs(
      title = "SUVs dominate the {mpg} sample",
      x = "Number of car models (count)", y = NULL
    ) +
    theme_minimal(base_size = 14)
}

plot_top_classes(data = mpg, column = "class")
ggsave("ex-1-classes.png", width = 6, height = 4.5,
       units = "in", dpi = 300, bg = "white")
