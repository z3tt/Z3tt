# AGENTS.md — demo project "GDP report" (Uppsala LS workshop, session 2)
# Mirrors the deck's "A Fuller Example: AGENTS.md" slide — slide and demo stay consistent.

```
layout:
  - data/ for inputs (data/raw immutable) · R/ for functions only · output/ for reports
  - single entry point: output/report.qmd — render with `quarto render output/report.qmd`
  - pin the R environment with renv (renv.lock committed)

style:
  - {ggplot2} + tidyverse only, native pipe |> over magrittr
  - snake_case objects, data-first function arguments
  - theme_minimal(base_size = 14), bold left-aligned title
  - one insight per chart — direct labels over legends
  - ggsave(): PNG, 300 dpi, bg = "white"
  - every figure: three-part fig-alt (chart type, data, insight) + caption with "Source: ..."
  - never rainbow palettes, never red-green pairs, never base-R plots
  - no hex codes in .qmd files
```
