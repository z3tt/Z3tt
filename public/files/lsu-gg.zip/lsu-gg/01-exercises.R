################################################################################
#                                                                              #
#                          LS Uppsala DataViz Course                           #
#     "ggplot2 in 100 Minutes" (remote) — Predict, Tweak & Fix Exercises       #
#                      Dr Cédric Scherer | November 2026                       #
#                                                                              #
################################################################################


install.packages(c("ggplot2", "dplyr", "scales")) # run once after installing R

library(ggplot2)
library(dplyr)   # glimpse(), filter(), mutate() & friends
library(scales)  # label_comma() & friends


# ==============================================================================
# SETUP: built-in data sets — no download needed!
# (penguins needs R >= 4.5 — any recent R, Positron, or Posit Cloud install)
#   mpg:      234 cars (displ, hwy, cty, class, drv, year, ...)
#   penguins: 344 penguins (species, island, bill_*, flipper_len, body_mass, ...)
# ==============================================================================

glimpse(mpg)
glimpse(penguins)


# ==============================================================================
# EXERCISE 1 — FIX THE THREE BUGS (~5 min)
# ==============================================================================

# The two plots below contain 3 classic mistake. List them and suggest fixes.

# --- Plot 1: scatter ---------------------------------------------------------
ggplot(mpg, aes(x = displ, y = hwy, color = class)) +
  geom_point(aes(shape = "diamond")) +
  geom_smooth(se = FALSE)

# --- Plot 2: bars ------------------------------------------------------------
ggplot(mpg, aes(y = manufacturer)) +
  geom_bar(aes(color = class))




# ==============================================================================
# EXERCISE 2 — READ, DON'T RUN: ZOOM vs. FILTER (~3 min)
# ==============================================================================

# Read the two twin codes below that both produce scatterplots with a linear
# regression line. Then answer:
#   1. What is the difference between the two?
#   2. Why are both of them problematic on their own?
#   3. Which of the two will **report a warning** when you run it — and which

# A: scale_x_continuous(limits = c(3, 6))
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  scale_x_continuous(limits = c(3, 6))


# B: coord_cartesian(xlim = c(3, 6))
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  coord_cartesian(xlim = c(3, 6))



# ==============================================================================
# EXERCISE 3 — THE POLISH PASS (~5 min)
# ==============================================================================

# Start from this raw penguin boxplot and plan the full polish pass:
#   1. Color: Which `scale_[aesthetic]_[behavior]()` call recolors the boxes?
#      Which argument handles the color for penguins without a recorded sex?
#   2. Numbers: Name the function that reformats the axis labels. How would you
#      show kilograms instead of grams?
#   3. Labels: Which one call writes title, subtitle, caption, axis titles, and
#      legend title?
#   4. Theming: Pick your favorite non-grey base theme and list two surgical
#      tweaks you'd like to make.

ggplot(penguins, aes(x = factor(year), y = body_mass, fill = sex)) +
  geom_boxplot()
