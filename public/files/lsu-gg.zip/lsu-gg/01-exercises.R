################################################################################
#                                                                              #
#                          LS Uppsala DataViz Course                           #
#     "ggplot2 in 100 Minutes" (remote) — Predict, Tweak & Fix Exercises       #
#                      Dr Cédric Scherer | November 2026                       #
#                                                                              #
################################################################################


install.packages(c("ggplot2", "dplyr", "scales")) # run once after installing R

library(ggplot2)
library(dplyr)   # glimpse(), filter(), mutate() & friends
library(scales)  # label_comma() & friends


# ==============================================================================
# SETUP: built-in data sets — no download needed!
# (penguins needs R >= 4.5 — any recent R, Positron, or Posit Cloud install)
#   mpg:      234 cars (displ, hwy, cty, class, drv, year, ...)
#   penguins: 344 penguins (species, island, bill_*, flipper_len, body_mass, ...)
# ==============================================================================

glimpse(mpg)
glimpse(penguins)


# ==============================================================================
# EXERCISE 1 — FIX THE THREE BUGS (~5 min)
# ==============================================================================

# The two plots below contain 3 classic mistake. List them and suggest fixes.

# --- Plot 1: scatter ---------------------------------------------------------
ggplot(mpg, aes(x = displ, y = hwy, color = class)) +
  geom_point(aes(shape = "diamond")) +
  geom_smooth(se = FALSE)

# --- Plot 2: bars ------------------------------------------------------------
ggplot(mpg, aes(y = manufacturer)) +
  geom_bar(aes(color = class))




# ==============================================================================
# EXERCISE 2 — READ, DON'T RUN: ZOOM vs. FILTER (~3 min) [Block 4: scales/coords]
# source: ggplot2 [un]charted M1-L7-coord-set-xlim
# ==============================================================================

# Read the two twin scatterplots below — no need to run them.
# A and B "show the same range" — but only one of them is problematic!

# A: scale_x_continuous(limits = c(3, 6))
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  scale_x_continuous(limits = c(3, 6))


# B: coord_cartesian(xlim = c(3, 6))
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  coord_cartesian(xlim = c(3, 6))


# QUESTIONS (answer without running — then check against the slides):
# 1. Which of the two is problematic — and what would the console report
#    when A is run? (It names a number.)
# 2. What could a reader get wrong from plot A alone — one claim about the
#    cars that A's trend line suggests and the full data doesn't support?
# 3. Bonus read (legend removal/styling): revisit the deck's "Mapping
#    Properties" scatter — mpg with color = drv, shape = year — and add a
#    smooth: how do you (a) drop one legend,
#    (b) drop one layer from the legend, (c) drop all legends?
# Answers: revealed on the "The Answer" slide.
# (A FILTERS: rows beyond the limits are dropped — the console reports
#  "Removed 105 rows containing non-finite outside the scale range" — and the
#  trend line is refit on the remaining 129 cars only. B ZOOMS: same line,
#  tighter view — the smooth is fit on all 234 cars.
#  Example of a wrong claim from plot A: "the mileage penalty per extra liter
#  is small" — every fuel-sipping sub-3-liter car was filtered away before the
#  fit, so A's slope flattens from -3.5 to -2.9 mpg per liter of displacement.
#  (a) scale_shape_discrete(guide = "none") removes a single legend,
#  (b) geom_smooth(show.legend = FALSE) drops one layer from the legend,
#  (c) theme(legend.position = "none") removes all legends.)



# ==============================================================================
# EXERCISE 3 — THE POLISH PASS (~5 min)                [Block 5: color/text/theme]
# source: ggplot2 [un]charted M2-L4-palettes-discrete, -viridis-options,
#         M2-L1-theme-basesize, M2L2-remove-legend
# ==============================================================================

# Start from this raw penguin boxplot and apply the full polish pass:
ggplot(penguins, aes(x = factor(year), y = body_mass, fill = sex)) +
  geom_boxplot()

# TODO 1: palette — a colorblind-safe MANUAL vector via
#         scale_fill_manual(values = c(...)). Viridis/turbo & co. are SEQUENTIAL
#         palettes: never map them to a categorical var (ordinal at best).
#         Mind the block-2 gotcha: boxes take FILL, not color (color = outline!).
#         Bonus: the 11 penguins without a recorded sex draw as gray NA boxes —
#         give them a deliberate color (na.value = ...) or handle them another way.
# TODO 2: labs() — title states the TAKEAWAY, subtitle the context,
#         caption = "Source: palmerpenguins / ggplot2 [un]charted", axes with units.
# TODO 3: theme_minimal(base_size = 14) + two surgical tweaks — the legend is
#         load-bearing now (it tells female from male). Place it where it reads best.
# Fix (one valid version):
# ggplot(penguins, aes(x = factor(year), y = body_mass, fill = sex)) +
#   geom_boxplot() +
#   scale_y_continuous(labels = scales::label_number(scale = 1/1000)) + # kg instead of g
#   scale_fill_manual(
#     values = c(female = "#d39001", male = "#0072b2"),
#     na.value = "grey92"
#   ) +
#   labs(
#     title = "Male penguins outweigh females, in every reported year",
#     subtitle = "Body mass of 344 Palmer Archipelago penguins by sex and capture year",
#     caption = "Source: Gorman KB, Williams TD, Fraser WR (2014)",
#     x = "Capture year", y = "Body mass (kg)", fill = NULL
#   ) +
#   theme_minimal(base_size = 15, base_family = "Aptos") +
#   theme(
#     panel.grid.major.x = element_blank(), panel.grid.minor = element_blank(),
#     plot.title = element_text(face = "bold"), plot.title.position = "plot",
#     legend.position = "top", legend.justification = "left",
#     plot.margin = margin_auto(20)
#   )



# ==============================================================================
# EXERCISE 4 — CAPSTONE: THE REVIEW GAME (~5 min)      [Block 6: read & fix]
# three classic broken plots — run, read, fix (fixes in comments)
# ==============================================================================

# --- Bug A: the unwanted legend titled "blue" ---------------------------------
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(color = "blue"), size = 2)
# Fix: constant OUTSIDE aes() -> geom_point(color = "blue", size = 2)

# --- Bug B: geom_bar() on PRE-COMPUTED counts explodes into stacked bars ------
counts <- mpg %>% count(class, name = "n")
ggplot(counts, aes(x = class, y = n)) +
  geom_bar(stat = "identity")   # works, but old-style; geom_bar() counts AGAIN
# Actually run this instead (the classic mistake):
ggplot(counts, aes(x = class)) +
  geom_bar(aes(y = n))          # BUG: y is ignored/recomputed; bars stack into a monstrosity
# Fix: use the pre-computed y as-is -> geom_col():
# ggplot(counts, aes(x = class, y = n)) + geom_col()

# --- Bug C: a facet panel shows up EMPTY --------------------------------------
df <- data.frame(
  x = 1:6, y = c(2, 5, 3, 6, 4, 8),
  g = factor(rep(c("A", "B", "C"), each = 2), levels = c("A", "B", "C"))
)
df_small <- df[df$g != "C", ]   # "C" filtered away, but the factor LEVEL remains
ggplot(df_small, aes(x, y)) +
  geom_point() +
  facet_wrap(~g, drop = FALSE)  # empty "C" panel!
# DIAGNOSE, don't fix live: the "C" level survived filtering with zero rows.
# The real fix is data prep (droplevels() / refactor the factor) — out of scope
# today (brief §8). Honest options to NAME: fix the data, or keep the empty
# panel and say why in the caption. Never silently ship it.

cat("All exercises done — you can now read a ggplot2 call top to bottom!\n")
