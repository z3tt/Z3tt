# ==============================================================================
# Code handout - "ggplot2 in 100 Minutes" (Uppsala LS, November 2026)
# Dr Cedric Scherer | extracted from 01-grammar-of-graphics.qmd
# ==============================================================================

# ---- install (once) ----------------------------------------------------------
pkgs <- c("ggplot2", "dplyr", "scales", "patchwork", "ggrepel",
          "ggtext", "geomtextpath")
install.packages(setdiff(pkgs, rownames(installed.packages())))

# ---- load (every session) ----------------------------------------------------
library(ggplot2)
library(dplyr)   # glimpse(), count()
library(scales)  # label_comma(), label_number()
library(patchwork)

# ==============================================================================
# Meet Today's Data
# ==============================================================================

glimpse(mpg) # library(dplyr) to use glimpse()

mpg$year <- factor(mpg$year) # turn year into a factor (ordinal)

glimpse(penguins) # library(dplyr) to use glimpse()

# ==============================================================================
# The grammar in three lines
# ==============================================================================

ggplot(data = mpg) +       # 1. the data
  aes(x = cty, y = hwy) +  # 2. the mapping
  geom_point()             # 3. the geometry

ggplot(mpg, aes(x = cty, y = displ)) +
  geom_point()

ggplot(mpg, aes(x = cty, y = hwy)) +
  geom_smooth()

# ==============================================================================
# Aesthetics
# ==============================================================================

ggplot(mpg, aes(x = displ, y = hwy,
       color = drv, shape = year)) +
  geom_point()

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(color = "#629cff", shape = 15)

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(aes(color = drv, shape = year))

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(aes(color = "class"))

ggplot(mpg, aes(y = class, color = drv)) +
  geom_bar()

ggplot(mpg, aes(y = class, fill = drv)) +
  geom_bar()

ggplot(mpg, aes(y = class, color = drv)) +
  geom_bar(fill = "grey80", linewidth = 1)

ggplot(mpg, aes(y = class, fill = drv)) +
  geom_bar(color = "black", linewidth = 1)

ggplot(mpg, aes(x = displ, y = hwy, color = drv)) +
  geom_smooth(se = FALSE) +
  geom_point()

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_smooth(se = FALSE) +
  geom_point(aes(color = drv))

ggplot(mpg, aes(x = displ, y = hwy, color = drv)) +
  geom_smooth(se = FALSE, color = "grey40") +
  geom_point()

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(aes(color = hwy >= 30))

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(aes(color = hwy >= 30)) +
  scale_color_discrete(
    name = "Efficiency",
    labels = c(`FALSE` = "low (hwy < 30)", `TRUE` = "high (hwy ≥ 30)")
  )

# ==============================================================================
# YOUR TURN, PART 1 — starter script: 01-exercises.R
# ==============================================================================

# ==============================================================================
# Geoms, stats & positions
# ==============================================================================

ggplot(penguins, aes(x = species)) +
  geom_bar() # default stat = "count"

ggplot(penguins, aes(x = species, y = flipper_len)) +
  geom_col() # default stat = "identity"

ggplot(mpg, aes(y = manufacturer)) +
  geom_bar(aes(fill = year)) # default position = "stack"

ggplot(mpg, aes(y = manufacturer)) +
  geom_bar(aes(fill = year), position = "dodge")

set.seed(5482903)

ggplot(penguins, aes(x = species, y = body_mass)) +
  geom_jitter(width = 0.1, alpha = 0.4, color = "firebrick") +
  geom_boxplot()

ggplot(penguins, aes(x = species, y = body_mass)) +
  geom_boxplot() +
  geom_jitter(width = 0.1, alpha = 0.4, color = "firebrick")

ggplot(diamonds, aes(x = depth, y = table)) +
  geom_point(size = 2)

ggplot(diamonds, aes(x = depth, y = table)) +
  geom_point(alpha = 0.2, size = 2)

ggplot(diamonds, aes(x = depth, y = table)) +
  geom_bin2d()

ggplot(diamonds, aes(x = depth, y = table)) +
  geom_hex()

# ==============================================================================
# Scales & coordinates
# ==============================================================================

ggplot(penguins, aes(x = species, y = body_mass,
       fill = factor(year))) +
  geom_boxplot()

ggplot(penguins, aes(x = species, y = body_mass,
       fill = factor(year))) +
  geom_boxplot() +
  scale_x_discrete() +
  scale_y_continuous() +
  scale_fill_discrete()

ggplot(penguins, aes(x = species, y = body_mass,
       fill = factor(year))) +
  geom_boxplot() +
  # scale_x_discrete() +
  scale_y_continuous(
    labels = scales::label_comma(),
    breaks = seq(3000, 6500, by = 500),
    name = "Body mass (g)"
  ) +
  scale_fill_brewer(
    palette = "YlOrRd",
    name = NULL
  )

# (showcase-only in the deck: the qualitative/sequential/diverging triptych,
#  assembled with patchwork — its three palette classes are shown one call at
#  a time right below; patchwork itself is introduced later)

ggplot(penguins, aes(x = bill_len, y = bill_dep,
       color = species)) +
  geom_point(size = 2, alpha = 0.8) +
  scale_color_brewer(palette = "Dark2")

ggplot(penguins, aes(x = bill_len, y = bill_dep,
       color = species)) +
  geom_point(size = 2, alpha = 0.8) +
  scale_color_manual(values = c("red", "grey30", "grey55"))

ggplot(penguins, aes(x = bill_len, y = bill_dep,
       fill = body_mass)) +
  geom_point(shape = 21, size = 2, alpha = 0.8) +
  scale_fill_viridis_c(direction = -1)

ggplot(penguins, aes(x = bill_len, y = bill_dep,
       fill = body_mass)) +
  geom_point(shape = 21, size = 2, alpha = 0.8) +
  scale_fill_distiller(palette = "PuOr")

ggplot(penguins, aes(x = bill_len, y = bill_dep, color = sex)) +
  geom_point(size = 2, alpha = 0.8) +
  scale_color_manual(
    values = c(female = "#8951a9", male = "#33adbb"),
    na.value = "#ff7a0e"
  ) +
  labs(color = NULL)

ggplot(penguins, aes(x = species, y = body_mass,
       fill = factor(year))) +
  geom_boxplot() +
  coord_cartesian() # the default

ggplot(penguins, aes(x = species, y = body_mass,
       fill = factor(year))) +
  geom_boxplot() +
  coord_radial()

ggplot(penguins, aes(x = species, y = body_mass,
       fill = factor(year))) +
  geom_boxplot() +
  coord_flip()

ggplot(mpg, aes(x = drv, y = hwy)) +
  geom_boxplot() +
  coord_cartesian(ylim = c(15, 30))

ggplot(mpg, aes(x = drv, y = hwy)) +
  geom_boxplot() +
  scale_y_continuous(limits = c(15, 30))

# ==============================================================================
# YOUR TURN, PART 2 — starter script: 01-exercises.R (zoom vs. filter twins;
# verdict revealed on the deck's "The Answer" slide)
# ==============================================================================

# ==============================================================================
# The polish pass
# ==============================================================================

ggplot(penguins, aes(x = bill_len, y = bill_dep, color = species)) +
  geom_point(size = 2, alpha = 0.8) +
  labs(
    title = "Gentoo penguins have long yet shallower bills",      # state the takeaway
    subtitle = "Measurements of 344 Palmer Archipelago penguins", # add context
    caption = "Source: Gorman KB, Williams TD, Fraser WR (2014)", # cite the source
    x = "Bill length (mm)", y = "Bill depth (mm)",                # overwrite bare variable names
    color = NULL,                                                 # drop the legend title
    tag = "Fig. 1"                                                # a chart identifier
  )

 p <- ggplot(penguins, aes(x = bill_len, y = bill_dep, color = species)) + geom_point(size = 2)

p + theme_grey() # default

p + theme_minimal()

p + theme_bw(base_size = 14)

ggplot(penguins, aes(x = bill_len, y = bill_dep, color = species)) +
  geom_point(size = 2, alpha = 0.8) +
  labs(x = "Bill length (mm)", y = "Bill depth (mm)", color = NULL,
       title = "Gentoo penguins have longer, shallower bills") +
  theme_light(base_size = 14) +
  theme(
    plot.title.position = "plot",              # align the title with the panel's left edge
    plot.title = element_text(face = "bold"),  # turn title into bold text
    panel.grid.minor = element_blank(),        # element_blank() removes parts
    plot.margin = margin(10, 12, 10, 12)       # top, right, bottom, left
  )

theme_set(theme_light(base_size = 14))
theme_update(
  plot.title.position = "plot",              # align the title with the panel's left edge
  plot.title = element_text(face = "bold"),  # turn title into bold text
  panel.grid.minor = element_blank(),        # element_blank() removes parts
  plot.margin = margin(10, 12, 10, 12)       # top, right, bottom, left
)

ggplot(penguins, aes(x = bill_len, y = bill_dep, color = species)) +
  geom_point(size = 2, alpha = 0.8) +
  labs(x = "Bill length (mm)", y = "Bill depth (mm)", color = NULL,
       title = "Gentoo penguins have long, yet shallower bills") +
  theme(
    legend.position = "inside",
    legend.position.inside = c(.1, .1)
  )

# ==============================================================================
# YOUR TURN, PART 3 — starter script: 01-exercises.R
# ==============================================================================

# ---- Ex. 3: one valid polish pass (suggested solution) ------------------------
ggplot(penguins, aes(x = factor(year), y = body_mass, fill = sex)) +
  geom_boxplot() +
  scale_y_continuous(labels = scales::label_number(scale = 1/1000)) + # kg instead of g
  scale_fill_manual(
    values = c(female = "#d39001", male = "#0072b2"),
    na.value = "grey92"
  ) +
  labs(
    title = "Male penguins outweigh females, in every reported year",
    subtitle = "Body mass of 344 Palmer Archipelago penguins by sex and capture year",
    caption = "Source: Gorman KB, Williams TD, Fraser WR (2014)",
    x = "Capture year", y = "Body mass (kg)", fill = NULL
  ) +
  theme_minimal(base_size = 15, base_family = "Aptos") +
  theme(
    panel.grid.major.x = element_blank(), panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"), plot.title.position = "plot",
    legend.position = "top", legend.justification = "left",
    plot.margin = margin_auto(20)
  )

# ==============================================================================
# Small Multiples
# ==============================================================================

ggplot(mpg, aes(x = hwy, y = displ)) +
  geom_point(size = 1.8, alpha = 0.6) +
  facet_wrap(~drv) + # one panel per drivetrain
  theme_bw()

ggplot(penguins, aes(x = sex, y = body_mass, fill = sex)) +
  geom_boxplot(show.legend = FALSE) +
  facet_wrap(~factor(year)) +
  scale_y_continuous(labels = scales::label_number(scale = 1/1000)) + # use scales::comma for g
  scale_fill_manual(
    values = c(female = "#d39001", male = "#0072b2"),
    na.value = "grey92"
  ) +
  labs(
    title = "Male penguins outweigh females, in every reported year",
    subtitle = "Body mass of 344 Palmer Archipelago penguins by sex and capture year",
    caption = "Source: Gorman KB, Williams TD, Fraser WR (2014)",
    x = "Capture year", y = "Body mass (kg)", fill = NULL
  ) +
  theme_linedraw(base_size = 15, base_family = "Aptos") +
  theme(
    panel.grid.major.x = element_blank(), panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"), plot.title.position = "plot",
    plot.margin = margin_auto(20)
  )

# ==============================================================================
# Ecosystem
# ==============================================================================

p1 <- ggplot(mpg, aes(drv, displ, color = drv)) +
  geom_boxplot(show.legend = FALSE) +
  geom_jitter(width = 0.2, alpha = 0.6)

p2 <- ggplot(mpg, aes(hwy, displ, color = drv)) +
  geom_point(alpha = 0.6, show.legend = FALSE)

p1 + p2     # side by side — p1 / p2 stacks

ggplot(subset(msleep, vore == "omni"), aes(x = sleep_rem, y = sleep_total)) +
  geom_point(size = 2, alpha = .6) +
  ggrepel::geom_text_repel(aes(label = name)) +
  labs(title = "A Sleep Map of Omnivores", subtitle = "Some sleep a little. The opossum commits.")

ggplot(penguins, aes(x = sex, y = body_mass, fill = sex)) +
  geom_boxplot(show.legend = FALSE) +
  facet_wrap(~factor(year)) +
  scale_y_continuous(labels = scales::label_number(scale = 1/1000)) + # use scales::comma for g
  scale_fill_manual(
    values = c(female = "#d39001", male = "#0072b2"),
    na.value = "grey92"
  ) +
  labs(
    title = "<b style='color: #016ba8;'>Male penguins</b> outweigh <b style='color: #c28500;'>females</b>, in every reported year",
    subtitle = "Body mass of 344 Palmer Archipelago penguins by sex and capture year",
    caption = "Source: *Gorman KB, Williams TD, Fraser WR* **(2014)**",
    x = "Capture year", y = "Body mass *(kg)*", fill = NULL
  ) +
  theme_linedraw(base_size = 13, base_family = "Aptos") +
  theme(
    panel.grid.major.x = element_blank(), panel.grid.minor = element_blank(),
    plot.title = ggtext::element_markdown(face = "bold"), plot.title.position = "plot",
    plot.caption = ggtext::element_markdown(), axis.title.y = ggtext::element_markdown(),
    plot.margin = margin_auto(12)
  )

g_int <- ggplot(mpg, aes(hwy, displ, color = class)) +
  ggiraph::geom_point_interactive(
    aes(data_id = manufacturer, tooltip = manufacturer),
    alpha = 0.8
  )

ggiraph::girafe(
  ggobj = g_int, width_svg = 9, height_svg = 4,
  options = list(
    opts_hover(css = "opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.2;"),
    opts_tooltip(css = "font-size: 16pt; background-color: #F1F1F1; padding: 6px;")
  )
)

# ==============================================================================
# APPENDIX — extra demos from the deck
# ==============================================================================

# categorical column: hues + keys
ggplot(mpg, aes(x = displ, y = hwy,
       color = drv)) +
  geom_point(size = 2)

# numeric column: gradient + colorbar
ggplot(mpg, aes(x = displ, y = hwy,
       color = cty)) +
  geom_point(size = 2)

ggplot(penguins, aes(x = flipper_len)) +
  geom_histogram() # default stat = "bin"

ggplot(penguins, aes(x = flipper_len)) +
  geom_histogram(bins = 12) # default stat = "bin"

ggplot(mpg, aes(y = manufacturer)) +
  geom_bar(aes(fill = class), position = "dodge")

ggplot(mpg, aes(y = manufacturer)) +
  geom_bar(aes(fill = class), position = position_dodge(preserve = "single"))

ggplot(penguins, aes(x = year, y = body_mass)) +
  geom_boxplot()

ggplot(penguins, aes(x = year, y = body_mass)) +
  geom_boxplot(aes(group = year))

penguin_counts <- dplyr::count(penguins, species, year)

ggplot(penguin_counts, aes(x = year, y = n)) +
  geom_line()

penguin_counts <- dplyr::count(penguins, species, year)

ggplot(penguin_counts, aes(x = year, y = n)) +
  geom_line(aes(group = species))

penguin_counts <- dplyr::count(penguins, species, year)

ggplot(penguin_counts, aes(x = year, y = n, group = species)) +
  geomtextpath::geom_labelline(aes(label = species, hjust = .9))

ggplot(penguins, aes(x = flipper_len, y = body_mass)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  coord_trans(y = "log10")

ggplot(penguins, aes(x = flipper_len, y = body_mass)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  scale_y_log10()

ggplot(mpg, aes(x = hwy, y = displ)) +
  geom_point(size = 1.8, alpha = 0.6) +
  facet_wrap(~drv, scales = "free") +
  theme_bw()

ggplot(mpg, aes(x = hwy, y = displ)) +
  geom_point(size = 1.8, alpha = 0.6) +
  facet_wrap(~drv, scales = "free_x", space = "free_x") +
  theme_bw()
