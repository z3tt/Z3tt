################################################################################
#                                                                              #
#                          LS Uppsala DataViz Course                           #
#   "Reproducible Data Visualization with ggplot2: Principles & Fundamentals"  #
#                  Dr Cédric Scherer | November 25, 2025                       #
#                                                                              #
#                                Exercises                                     #
#                                                                              #
################################################################################


install.packages("ggplot2") # run once after installing R

pkgs <- c("readr", "scales", "ragg")
install.packages(setdiff(pkgs, rownames(installed.packages())))

library(ggplot2)


# ==============================================================================
# YOUR TURN: EXERCISE 1
# ==============================================================================

# Create a scatter plot of life expectancy versus per-capita GDP for all
# countries using the 2023 data from Gapminder.

# 1. Import the Gapminder data and store a subset of the 2023 data in an object.
# 2. Initialize a ggplot using this object as the data source.
# 3. Inside aes(), map gdp_pcap to x and life_exp to y.
# 4. Add a point geometry to draw the scatter plot.












# ==============================================================================
# YOUR TURN: EXERCISE 2
# ==============================================================================

# Turn the scatter plot of life expectancy versus per-capita GDP into a
# colorful bubble chart.

# 1. Use the size aesthetic to represent each country's population.
# 2. Adjust your code to use logarithmic GDP values as in the original graphic.
# 3. Color each bubble according to the country’s continent.
# 4. Set the transparency of the points (alpha) to .75.
# Bonus: Add a regression line showing the overall trend behind the points.












# ==============================================================================
# YOUR TURN: EXERCISE 3
# ==============================================================================

# Polish and export the Gapminder bubble chart.

# 1. Overwrite the default axis titles with meaningful labels.
# 2. Change the legend title for bubble size and remove it for color.
# 3. Add a title and a data source.
# 4. Use your favorite (non-default) theme.
# Bonus: Adjust the labels on the x axis to include $ and , as separator.












################################################################################
#                                  WELL DONE!                                  #
################################################################################
