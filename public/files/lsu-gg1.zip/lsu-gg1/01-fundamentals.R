################################################################################
#                                                                              #
#                          LS Uppsala DataViz Course                           #
#   "Reproducible Data Visualization with ggplot2: Principles & Fundamentals"  #
#                  Dr Cédric Scherer | November 25, 2025                       #
#                                                                              #
################################################################################


# SETUP ------------------------------------------------------------------------

install.packages("ggplot2") # run once after installing R
library(ggplot2) # run every time you open R

ggplot() # a function
diamonds # a data set

pkgs <- c("readr", "dplyr", "forcats", "scales", "ragg")
install.packages(setdiff(pkgs, rownames(installed.packages())))


# use as part of the tidyverse collection:
# install.packages("tidyverse") # run once after installing R
# library(tidyverse)            # run every time you open R


# return to previous version of ggplot2:
# install.packages("remotes")
# remotes::install_version(
#   package = "ggplot2", version = "3.5.2", repos = "http://cran.us.r-project.org"
# )


# DATA IMPORT + PREPARATION ----------------------------------------------------

gapminder <- readr::read_csv(file.path("data", "gapminder-2000s.csv"))
# gapminder <- read.csv("./data/gapminder-2000s.csv")
# gapminder <- readr::read_csv("./data/gapminder-2000s.csv")
# gapminder <- readr::read_csv("https://www.cedricscherer.com/data/gapminder-2020s.csv")


library(dplyr)
glimpse(gapminder)


gm2023 <- subset(gapminder, year == 2023)
glimpse(gm2023)


# DATA -------------------------------------------------------------------------

?ggplot


ggplot(data = gm2023)


# AESTHETICS -------------------------------------------------------------------

ggplot(
  data = gm2023,
  mapping = aes(
    x = continent,
    y = fertility
  )
)


ggplot(data = gm2023) +
  aes(x = continent, y = fertility)


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
)


# GEOMETRICAL LAYERS -----------------------------------------------------------

ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_point()


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter()


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_text(
    aes(label = country)
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_bin_2d()


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot()


# ==============================================================================
# YOUR TURN: EXERCISE 1
# ==============================================================================

# Create a scatter plot of life expectancy versus per-capita GDP for all
# countries using the 2023 data from Gapminder.

# 1. Import the Gapminder data and store a subset of the 2023 data in an object.
# 2. Initialize a ggplot using this object as the data source.
# 3. Inside aes(), map gdp_pcap to x and life_exp to y.
# 4. Add a point geometry to draw the scatter plot.



# SOLUTION EXERCISE 1

gapminder <- readr::read_csv("./data/gapminder-1950-2023.csv")
gm2023 <- subset(gapminder, year == 2023)


ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point()

# ==============================================================================
# END EXERCISE 1
# ==============================================================================


# A FEW MORE NOTES ON LAYERS ---------------------------------------------------

ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_point() +
  geom_boxplot()


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(
    outliers = FALSE,
    fill = "khaki"
  ) +
  geom_jitter(
    width = .1,
    alpha = .5,
    color = "navy"
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    color = "navy"
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    aes(color = continent)
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    color = "navy",
    size = 3
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    aes(
      color = continent,
      size = pop
    )
  )


# TYPICAL ISSUES WITH AESTHETICS -----------------------------------------------

## meant to showcase unintended behavior
ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    aes(color = "navy"),
    width = .2,
    alpha = .5
  )


## meant to return error
ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    color = continent,
    alpha = .7
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    aes(color = life_exp),
    width = .2
  )


ggplot(
  data = gm2023,
  aes(
    x = continent,
    y = sqrt(fertility)
  )
) +
  geom_jitter(
    width = .2
  )


ggplot(
  data = gm2023,
  aes(
    x = continent,
    y = scales::rescale(fertility)
  )
) +
  geom_jitter(
    width = .2
  )


ggplot(
  data = gm2023,
  aes(
    x = forcats::fct_reorder(continent, fertility),
    y = scales::rescale(fertility)
  )
) +
  geom_jitter(
    width = .2
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    aes(color = life_exp >= 65),
    width = .2
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_jitter(
    aes(color = continent == "Africa"),
    width = .2,
    show.legend = FALSE
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = continent),
    width = .2
  )


ggplot(
  data = gm2023,
  aes(
    x = continent, y = fertility,
    color = continent
  )
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    width = .2
  )


# ==============================================================================
# YOUR TURN: EXERCISE 2
# ==============================================================================

# Turn the scatter plot of life expectancy versus per-capita GDP into a
# colorful bubble chart.

# 1. Use the size aesthetic to represent each country's population.
# 2. Adjust your code to use logarithmic GDP values as in the original graphic.
# 3. Color each bubble according to the country’s continent.
# 4. Set the transparency of the points (alpha) to .75.
# Bonus: Add a regression line showing the overall trend behind the points.



# SOLUTION EXERCISE 2

ggplot(
  data = gm2023,
  aes(x = log10(gdp_pcap), y = life_exp)
) +
  geom_point(
    aes(
      size = pop,
      color = continent
    ),
    alpha = .75
  )

# better:
ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(
      size = pop,
      color = continent
    ),
    alpha = .75
  ) +
  scale_x_log10()

# bonus:
ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_smooth(
    method = "lm"
  ) +
  geom_point(
    aes(
      size = pop,
      color = continent
    ),
    alpha = .75
  ) +
  scale_x_log10()

# ==============================================================================
# END EXERCISE 2
# ==============================================================================


# MORE CAHRT TYPES -------------------------------------------------------------

ggplot(
  data = gm2023,
  aes(x = continent)
) +
  geom_bar()


ggplot(
  data = gm2023,
  aes(x = fertility)
) +
  geom_histogram()

ggplot(
  data = gm2023,
  aes(x = fertility)
) +
  geom_histogram(
    bins = 50
    # binwidth = .1
  )


ggplot(
  data = gm2023,
  aes(x = fertility)
) +
  geom_histogram(
    aes(fill = continent)
  )


ggplot(
  data = gm2023,
  aes(x = fertility)
) +
  geom_density(
    aes(color = continent)
  )


ggplot(
  data = gm2023,
  aes(x = fertility)
) +
  geom_density(
    aes(
      color = continent,
      fill = continent
    ),
    alpha = .3
  )


ggplot(
  data = gm2023,
  aes(x = fertility)
) +
  geom_density(
    aes(
      color = continent,
      fill = continent
    ),
    alpha = .3,
    position = "fill"
  )


ggplot(
  data = gapminder,
  aes(x = life_exp, y = fertility)
) +
  geom_point(alpha = .2)


ggplot(
  data = gapminder,
  aes(x = life_exp, y = fertility)
) +
  geom_bin2d()


ggplot(
  data = gapminder,
  aes(x = life_exp, y = fertility)
) +
  geom_hex()


ggplot(
  data = gapminder,
  aes(x = life_exp, y = fertility)
) +
  geom_density_2d_filled()


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(
    staplewidth = .3,
    outlier.size = .5,
    notch = TRUE,
    varwidth = TRUE
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_violin()


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_violin(
    bw = .15,
    draw_quantiles = c(.05, .5, .95),
    quantile.color = c("blue", "red", "blue"),
    trim = FALSE
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  stat_summary() # mean ± se


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  stat_summary( # mean ± sd
    fun.data = mean_sdl,
    fun.args = list(mult = 1)
  )


# Titles & Labels --------------------------------------------------------------

ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = life_exp),
    width = .2, alpha = .5
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = life_exp),
    width = .2, alpha = .5
  ) +
  labs(
    x = "Continent",
    y = "Average fertility rate (children per woman)"
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = life_exp),
    width = .2, alpha = .5
  ) +
  labs(
    x = "Continent",
    y = "Average fertility rate (children per woman)",
    color = "Life expectancy\n(in years)"
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = life_exp),
    width = .2, alpha = .5
  ) +
  labs(
    x = NULL,
    y = "Average fertility rate (children per woman)",
    color = "Life expectancy\n(in years)"
  )


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = life_exp),
    width = .2, alpha = .5
  ) +
  labs(
    x = NULL,
    y = "Average fertility rate (children per woman)",
    color = "Life expectancy\n(in years)",
    title = "Globally, the fertility rate was 2.3 in 2023",
    subtitle = "All European countries reported lower fertility levels",
    caption = "Source: Gapminder project",
    tag = "Fig. 1"
  )


g <-
  ggplot(
    data = gm2023,
    aes(x = continent, y = fertility)
  ) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = life_exp),
    width = .2, alpha = .5
  ) +
  labs(
    x = NULL,
    y = "Average fertility rate (children per woman)",
    color = "Life expectancy\n(in years)",
    title = "Globally, the fertility rate was 2.3 in 2023",
    subtitle = "All European countries reported lower fertility levels",
    caption = "Source: Gapminder project"
  )

# Theming ----------------------------------------------------------------------

g + theme_grey() # or theme_gray()


g + theme_classic()


g + theme_minimal()


g + theme_bw()


g +
  theme_bw(
    base_size = 13,
    base_family = "Tahoma"
  )


# Exporting Plots --------------------------------------------------------------

# ggsave(filename = "my_plot.png", plot = g)


# ggsave("my_plot.png")


# ggsave("my_plot.png", width = 6, height = 5, dpi = 600)


# ggsave("my_plot.png", width = 6*2.54, height = 5*2.54, unit = "cm", dpi = 600)


# ggsave("my_plot.pdf", width = 6, height = 5, device = cairo_pdf)


# ggsave("my_plot.svg", width = 6, height = 5)


# ==============================================================================
# YOUR TURN: EXERCISE 3
# ==============================================================================

# Polish and export the Gapminder bubble chart.

# 1. Overwrite the default axis titles with meaningful labels.
# 2. Change the legend title for bubble size and remove it for color.
# 3. Add a title and a data source.
# 4. Use your favorite (non-default) theme.
# Bonus: Adjust the labels on the x axis to include $ and , as separator.



# SOLUTION EXERCISE 3

ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10() +
  labs(
    x = "GDP per capita in $ (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  ) +
  theme_light() +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

# bonus:
ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10(
    labels = scales::label_dollar(),
    breaks = 1000 * 4^(0:4)
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  ) +
  theme_light() +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

# ==============================================================================
# END EXERCISE 3
# ==============================================================================


# FACETS -----------------------------------------------------------------------

gm <-
  ggplot(
    data = gm2023,
    aes(x = gdp_pcap, y = life_exp)
  ) +
  geom_point(
    aes(color = continent),
    alpha = .75
  ) +
  scale_x_log10() +
  theme_light() +
  theme(legend.position = "none")

gm +
  facet_wrap(
    vars(continent)
  )

gm +
  facet_wrap(
    ~continent
  )

gm +
  facet_wrap(
    ~continent,
    nrow = 1 # or ncol = 5
  )

gm +
  facet_wrap(
    ~continent,
    scales = "free_x",
    space = "free_x"
  )

ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  # only works with ggplot v4
  geom_point(
    color = "grey85",
    size = .7,
    layout = "fixed"
  ) +
  geom_point(size = 1) +
  scale_x_log10() +
  facet_wrap(
    ~continent
  ) +
  theme_light()

ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  # works with older versions as well
  geom_point(
    data = select(gm2023, -continent),
    color = "grey85",
    size = .7
  ) +
  geom_point(size = 1) +
  scale_x_log10() +
  facet_wrap(
    ~continent
  ) +
  theme_light()

gm +
  facet_grid(
    region ~ continent,
    labeller = labeller(
      region = label_wrap_gen(10)
    )
  )


################################################################################
#                        THAT'S IT, FOLKS — THANK YOU!                         #
################################################################################
