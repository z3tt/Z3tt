################################################################################
#                                                                              #
#                          LS Uppsala DataViz Course                           #
#      "Reproducible Data Visualization with ggplot2: Advanced & Extended"     #
#                  Dr Cédric Scherer | November 26, 2025                       #
#                                                                              #
################################################################################


# SETUP ------------------------------------------------------------------------

install.packages("ggplot2") # run once after installing R
library(ggplot2) # run every time you open R

pkgs <- c(
  "readr", "dplyr", "stringr", "scales", "ggbeeswarm", "ggdist",
  "ggridges", "ggpointdensity", "ggdensity", "ggtext", "ggrepel",
  "ggforce", "concaveman", "patchwork", "ggiraph", "remotes"
)
install.packages(setdiff(pkgs, rownames(installed.packages())))

remotes::install_github("AllanCameron/geomtextpath")

# install.packages("remotes")
#
# remotes::install_version(
#   package = "ggplot2", version = "3.5.2", repos = "http://cran.us.r-project.org"
# )


# return to previous version of ggplot2:
# install.packages("remotes")
# remotes::install_version(
#   package = "ggplot2", version = "3.5.2", repos = "http://cran.us.r-project.org"
# )


# DATA IMPORT + PREPARATION ----------------------------------------------------

gapminder <- readr::read_csv(file.path("data", "gapminder-2000s.csv"))
# gapminder <- read.csv("./data/gapminder-2000s.csv")
# gapminder <- readr::read_csv("./data/gapminder-2000s.csv")
# gapminder <- readr::read_csv("https://www.cedricscherer.com/data/gapminder-2020s.csv")

library(dplyr)
glimpse(gapminder)

gm2023 <- subset(gapminder, year == 2023)
glimpse(gm2023)

gm_compare <- subset(gapminder, continent %in% c("Africa", "Americas"))
glimpse(gm_compare)


# THE COMPONENTS OF GGPLOT (so far) --------------------------------------------

ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10(
    labels = scales::label_dollar(),
    breaks = 1000 * 4^(0:4)
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  ) +
  theme_light(base_family = "Verdana") +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )


# STORE A GGPLOT OBJECT --------------------------------------------------------

g <-
  ggplot(
    data = gm2023,
    aes(x = gdp_pcap, y = life_exp)
  ) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10(
    labels = scales::label_dollar(),
    breaks = 1000 * 4^(0:4)
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  )


# WORKING WITH THEMES ----------------------------------------------------------

set_theme(theme_light())
# theme_set(theme_light()) in ggplot2 v3

g


set_theme(theme_light(
  base_size = 12,
  base_family = "Verdana"
))

g


ggplot(
  data = gm2023,
  aes(x = continent, y = fertility)
) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    width = .2, alpha = .5
  ) +
  labs(
    x = NULL,
    y = "Average fertility rate (children per woman)",
    title = "Globally, the fertility rate was 2.3 in 2023",
    subtitle = "All European countries reported lower fertility levels",
    caption = "Source: Gapminder project"
  )

update_theme( # theme_update() in ggplot2 v3
  plot.title.position = "plot",
  plot.caption.position = "plot",
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  panel.background = element_rect(
    fill = "#F8F8F8", color = NA
  )
)

g


theme_grey


theme_minimal


theme_gapminder <- function(
    base_family = "Verdana", base_size = 11,
    base_line_size = base_size / 22, base_rect_size = base_size / 22,
    ink = "#292929", paper = "#F8F8F8", accent = "firebrick", ...) {
  theme_minimal(
    base_family = base_family, base_size = base_size,
    base_line_size = base_line_size, base_rect_size = base_rect_size,
    ink = ink, paper = paper, accent = accent, ...
  ) %+replace%
    theme(
      plot.title = element_text(
        size = rel(1.3), face = "bold",
        margin = margin(b = base_size), hjust = 0
      ),
      plot.title.position = "plot",
      plot.caption = element_text(
        color = "grey50", margin = margin(t = base_size / 6),
        size = rel(0.8), hjust = 0, vjust = 1
      ),
      plot.caption.position = "plot",
      axis.title.x = element_text(hjust = 1, vjust = 0, margin = margin(t = base_size / 3)),
      axis.title.y = element_text(hjust = 1, vjust = 0, angle = 90, margin = margin(r = base_size / 2)),
      panel.background = element_rect(fill = "white", color = "grey20"),
      panel.border = element_rect(fill = NA, color = "grey20"),
      panel.grid.minor = element_blank(),
      legend.justification = "top",
      strip.text = element_text(size = rel(1.05), margin = margin(base_size / 2, 0, base_size / 2, 0)),
      plot.margin = margin_auto(base_size),
      complete = TRUE
    )
}


g + theme_gapminder()


g + geom_smooth(method = "lm") + theme_gapminder()


g +
  theme_gapminder(
    base_size = 10,
    base_family = "Georgia"
  )


g +
  theme_gapminder(
    base_size = 10,
    base_family = "Georgia"
  ) +
  theme(
    panel.grid.major = element_line(
      color = "grey85", linewidth = .3
    ),
    legend.box.background = element_rect(
      color = "#292929", fill = "#F8F8F8"
    )
  )


set_theme(theme_gapminder())


# SCALES -----------------------------------------------------------------------

ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  # default scales
  scale_x_continuous() +
  scale_y_continuous() +
  scale_color_discrete() +
  scale_size() +
  labs(
    x = "GDP per capita in $",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  )


ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10(
    breaks = 1000 * 4^(0:4),
    labels = scales::label_dollar()
  ) +
  scale_y_continuous(
    breaks = seq(55, 90, by = 5)
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  )


ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10(
    breaks = 1000 * 4^(0:4),
    labels = scales::label_dollar()
  ) +
  scale_y_continuous(
    breaks = seq(55, 90, by = 5)
  ) +
  scale_size_area(
    max_size = 20,
    breaks = 1 * 10^(6:9),
    labels = c("1 Million", "10 Million", "100 Million", "1 Billion")
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  )


ggplot(
  data = gm2023,
  aes(x = gdp_pcap, y = life_exp)
) +
  geom_point(
    aes(size = pop, color = continent),
    alpha = .75
  ) +
  scale_x_log10(
    breaks = 1000 * 4^(0:4),
    labels = scales::label_dollar()
  ) +
  scale_y_continuous(
    breaks = seq(55, 90, by = 5)
  ) +
  scale_size_area(
    max_size = 20,
    breaks = 1 * 10^(6:9),
    labels = c("1 Million", "10 Million", "100 Million", "1 Billion")
  ) +
  scale_color_manual(
    values = c(Africa = "#0E93A1", Americas = "#30A300", Asia = "#C30044", Europe = "#AC9C08", Oceania = "#981AA7")
  ) +
  labs(
    x = "GDP per capita (log scale)",
    y = "Life expectancy in years",
    size = "Population:",
    color = NULL,
    title = "Gapminder 2023: Health vs. Income",
    caption = "Data source: Gapminder project"
  )


# EXCITING CHART TYPES ---------------------------------------------------------

ggplot(gm2023, aes(x = continent, y = life_exp)) +
  geom_boxplot()


# VISUALIZING DISTRIBUTIONS ....................................................

ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm()


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(priority = "descending")


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(side = -1)


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_beeswarm(method = "hex", size = 1.5, cex = 2)


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_quasirandom()


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggbeeswarm::geom_quasirandom(method = "smiley")


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_eye()


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye() ## default: `.width = c(.66, .95)`


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = .5)


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = c(0, 1))


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_halfeye(.width = c(0, 1), adjust = .5, shape = 23, point_size = 5)


ggplot(
  subset(gm_compare, year %in% c(2003, 2013, 2023)),
  aes(x = factor(year), y = life_exp, fill = continent)
) +
  ggdist::stat_halfeye(.width = 0, adjust = .5, slab_alpha = .5, shape = 21) +
  scale_fill_manual(values = c("#DB4706", "#069ADB"), name = NULL)


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval()


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25, linewidth = 10) +
  scale_color_viridis_d(option = "rocket", direction = -1, end = .9)


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25) +
  ggdist::stat_dots(position = position_nudge(x = .05), scale = .8) +
  scale_color_viridis_d(option = "rocket", direction = -1, end = .9)


ggplot(gm2023, aes(x = continent, y = life_exp)) +
  ggdist::stat_interval(.width = 1:4 * .25) +
  ggdist::stat_halfeye(.width = 0, color = "white", position = position_nudge(x = .025)) +
  scale_color_viridis_d(option = "rocket", direction = -1, end = .9)


ggplot(gm2023, aes(x = life_exp, y = continent)) +
  ggridges::geom_density_ridges()


ggplot(
  gm_compare,
  aes(x = life_exp, y = factor(year), fill = continent)
) +
  ggridges::geom_density_ridges(
    alpha = .5
  ) +
  scale_y_discrete(limits = rev)


ggplot(
  data = gm_compare,
  aes(x = life_exp, y = factor(year), fill = continent)
) +
  ggridges::geom_density_ridges(
    alpha = .5,
    color = "transparent",
    scale = 1.5
  ) +
  scale_y_discrete(limits = rev) +
  scale_fill_manual(
    values = c("#DB4706", "#069ADB"),
    name = NULL
  ) +
  theme(legend.position = "top")


# VISUALIZING X-Y RELATIONSHIPS ................................................

ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_point(size = 3, alpha = .5)


ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_point(size = 3, alpha = .05)


ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  ggpointdensity::geom_pointdensity(size = 2)


ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  ggpointdensity::geom_pointdensity(size = 2, adjust = .5) +
  scale_color_gradient(low = "#FFCE52", high = "#663399")


ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_point(alpha = .02, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines()


ggplot(gm_compare, aes(x = life_exp, y = fertility, color = factor(continent))) +
  geom_point(alpha = .1, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines() +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)


ggplot(gm_compare, aes(x = life_exp, y = fertility, color = factor(continent))) +
  geom_point(alpha = .1, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines(method = "mvnorm", probs = c(.95, .75, .5, .25, .1)) +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)


ggplot(gm_compare, aes(x = life_exp, y = fertility)) +
  geom_density_2d_filled() +
  coord_cartesian(expand = FALSE) +
  ggtitle("geom_density_2d_filled()") +
  theme(plot.title = element_text(face = "bold"), legend.position = "top")


ggplot(gapminder, aes(x = life_exp, y = fertility)) +
  ggdensity::geom_hdr(probs = seq(.999, .2, length.out = 5)) +
  coord_cartesian(expand = FALSE) +
  ggtitle("ggdensity::geom_hdr()") +
  theme(plot.title = element_text(face = "bold"), legend.position = "top")


# WORKING WITH TEXT ------------------------------------------------------------

g2 <-
  g +
  scale_y_continuous(
    breaks = seq(55, 90, by = 5)
  ) +
  scale_size_area(
    max_size = 20,
    breaks = 1 * 10^(6:9),
    labels = c("1 Million", "10 Million", "100 Million", "1 Billion")
  ) +
  scale_color_discrete(
    type = c(Africa = "#0E93A1", Americas = "#30A300", Asia = "#C30044", Europe = "#AC9C08", Oceania = "#981AA7"),
    guide = "none"
  ) +
  theme(legend.justification = "top")


# TEXT RENDERING ...............................................................

library(ggtext)

g2 +
  labs(
    x = "**Per-capita GDP** *(log scale)*",
    y = "**Life expectancy** *in years*",
    subtitle = "Comparing key country-level metrics across continents: <b style='color:#0E93A1'>Africa</b> &#x2055; <b style='color:#30A300'>Americas</b> &#x2055; <b style='color:#C30044'>Asia</b> &#x2055; <b style='color:#AC9C08'>Europe</b> &#x2055; <b style='color:#981AA7'>Oceania</b>",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.subtitle = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )


g2 +
  labs(
    x = "**Per-capita GDP** *(log scale)*",
    y = "**Life expectancy** *in years*",
    subtitle = "Comparing key country-level metrics across continents: <b style='color:#0E93A1'>Africa</b> &#x2055; <b style='color:#30A300'>Americas</b> &#x2055; <b style='color:#C30044'>Asia</b> &#x2055; <b style='color:#AC9C08'>Europe</b> &#x2055; <b style='color:#981AA7'>Oceania</b>",
    size = "&rarr; Population:"
  ) +
  theme(
    plot.subtitle = element_textbox_simple(
      fill = "white",
      box.colour = "#292929",
      linetype = "solid",
      padding = margin(8, 12, 6, 12),
      margin = margin(b = 12),
    ),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown(),
    legend.title = element_markdown()
  )


g2 +
  geom_richtext(
    aes(
      label = "My <b style='color:#28a87d;'>fancy</b><br>annotation",
      x = 2000, y = 83,
      family = "Georgia"
    )
  )


g2 +
  marquee::geom_marquee(
    data = subset(gm2023, country %in% c("India", "China")),
    aes(label = paste0("{.firebrick **", country, ",  \n*", pop / 10^6, " Million***}")),
    color = "black", size = 3.5,
    vjust = c(-.9, 2.1), hjust = c(-.1, .1)
  )


md <-
  "## Gapminder {.red 2023}
The visualization shows

1. _life expectancy_ on the *y-axis*

2. _GDP per-capita_ on the *x-axis* with a **log scale**, and

3. _population size_ encoded by *area*.

"

g2 +
  ggtitle(md) +
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc"), size = rel(.9)
    )
  )


# CLEVER ANOTATIONS ............................................................

g2 +
  ggrepel::geom_label_repel(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    )
  )


g2 +
  ggrepel::geom_label_repel(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE
  )


g2 +
  ggrepel::geom_label_repel(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Verdana",
    ylim = 86,
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))


g2 +
  geom_point(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Verdana",
    ylim = c(86, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))


g2 +
  geom_point(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(size = pop),
    shape = 21
  ) +
  ggrepel::geom_label_repel(
    data = filter(gm2023, pop > 3 * 10^8),
    aes(
      label = country,
      color = continent
    ),
    show.legend = FALSE,
    family = "Verdana",
    ylim = c(86, NA),
    segment.colour = "grey20"
  ) +
  coord_cartesian(ylim = c(NA, 88))


g2 +
  ggforce::geom_mark_ellipse(
    aes(
      label = continent,
      color = continent
    )
  ) +
  theme(legend.position = "none")


g2 +
  ggforce::geom_mark_ellipse(
    aes(
      label = continent,
      color = continent
    )
  ) +
  scale_y_continuous(
    expand = expansion(mult = 1.3)
  ) +
  theme(legend.position = "none")


g2 +
  ggforce::geom_mark_rect(
    aes(
      label = continent,
      color = continent
    )
  ) +
  scale_y_continuous(
    expand = expansion(mult = 1.3)
  ) +
  theme(legend.position = "none")


g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      color = continent,
      filter = country == "India"
    )
  )


g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      color = continent,
      filter = country == "India"
    ),
    alpha = .5,
    linewidth = 1,
    expand = unit(24, "pt"),
    description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    label.family = c("Verdana", "Georgia"),
    con.cap = unit(1, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )


g2 +
  ggforce::geom_mark_circle(
    aes(
      label = country,
      group = country,
      filter = country %in% c("India", "China")
    ),
    alpha = .5,
    size = 1,
    expand = unit(24, "pt"),
    label.family = "Verdana",
    con.cap = unit(.5, "mm"),
    con.arrow = arrow(type = "closed", length = unit(2, "mm")),
    show.legend = FALSE
  )


gm_trends <- filter(gapminder, country %in% c("Germany", "Turkey", "Zambia", "India"))

ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geom_line(
    linewidth = 1
  )


ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geom_line(
    linewidth = 1
  ) +
  geom_text(
    data = filter(gm_trends, year == 1997),
    aes(label = country),
    family = "Verdana",
    fontface = "bold",
    vjust = -.5
  ) +
  theme(legend.position = "none")


ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Verdana",
    fontface = "bold"
  ) +
  theme(legend.position = "none")


ggplot(
  data = gm_trends,
  aes(
    x = year, y = life_exp,
    color = country
  )
) +
  geomtextpath::geom_textline(
    aes(label = country),
    linewidth = 1,
    size = 5,
    family = "Verdana",
    fontface = "bold",
    hjust = .1,
    halign = "left",
    straight = TRUE
  ) +
  theme(legend.position = "none")


# WORKING WITH MULTI-PLOT COMPOSITION ------------------------------------------

g1 <-
  ggplot(
    data = gm2023,
    aes(x = continent, y = gdp_pcap)
  ) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = continent),
    width = .2, alpha = .5
  ) +
  scale_color_manual(
    values = c(Africa = "#0E93A1", Americas = "#30A300", Asia = "#C30044", Europe = "#AC9C08", Oceania = "#981AA7"),
    guide = "none"
  ) +
  labs(x = NULL, y = "Life expectancy in years")


g3 <-
  ggplot(
    data = gm2023,
    aes(x = continent, y = life_exp)
  ) +
  geom_boxplot(outliers = FALSE) +
  geom_jitter(
    aes(color = continent),
    width = .2, alpha = .5
  ) +
  scale_color_manual(
    values = c(Africa = "#0E93A1", Americas = "#30A300", Asia = "#C30044", Europe = "#AC9C08", Oceania = "#981AA7"),
    guide = "none"
  ) +
  labs(x = NULL, y = "GDP per capita in $")


library(patchwork)

g2 / (g1 + g3)


(g2 / (g1 + g3)) +
  plot_layout(heights = c(.3, .1))


g2 + plot_spacer() + g1 + g3 +
  plot_layout(widths = c(1, .5, 1, 1))


picasso <- "
AAAAAA#BBBB
#CCCCCCCCC#
#CCCCCCCCC#"

g1 + g3 + g2 + plot_layout(design = picasso)


g2 / (g1 + g3) +
  plot_annotation(tag_levels = "1", tag_prefix = "P", title = "An overarching title for all 3 plots, placed on the very top while all other titles are sitting below the tags.")


g2 / (g3 + g1) +
  plot_annotation(tag_levels = "a", tag_prefix = "(", tag_suffix = ")", title = "An overarching title for all 3 plots, placed on the very top while all other titles are sitting below the tags.")


g2 + inset_element(g3, l = .6, b = .05, r = .97, t = .4)


g2 + inset_element(g3, l = .6, b = 0, r = 1, t = .5, align_to = "full")


# WORKING WITH INTERACTIVITY ---------------------------------------------------

library(ggiraph)

g_int <-
  g_raw +
  geom_point_interactive(
    aes(size = pop, color = continent),
    alpha = .75
  )

g_int


girafe(
  ggobj = g_int,
  width_svg = 5.5,
  height_svg = 6.6
)


g_int <-
  g_raw +
  geom_point_interactive(
    aes(
      size = pop, color = continent,
      data_id = iso_a3, tooltip = country
    ),
    alpha = .75
  )

girafe(
  ggobj = g_int,
  width_svg = 5.5,
  height_svg = 6.6
)


girafe(
  ggobj = g_int,
  width_svg = 5.5,
  height_svg = 6.6,
  options = list(
    opts_tooltip(css = "color: black; font-size: 16pt;"),
    opts_hover(css = "opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.3;"),
    opts_toolbar(position = "bottomright", pngname = "gapminder-2023")
  )
)


girafe(
  ggobj = g_int,
  width_svg = 5.5,
  height_svg = 6.6,
  options = list(
    opts_tooltip(use_fill = TRUE, css = "font-family: verdana; font-size: 18pt; font-weight: 600; color: white; padding: 12px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.3);"),
    opts_hover(css = "stroke: black; stroke-width: 1px; opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.3;"),
    opts_toolbar(position = "bottomright", pngname = "gapminder-2023")
  )
)


girafe(
  ggobj = g_int, width_svg = 9, height_svg = 5.5,
  options = list(
    opts_tooltip(use_fill = TRUE, css = "font-family: verdana; font-size:18pt; font-weight:600; color:white; padding:7px;"),
    opts_hover(css = "stroke: black; stroke-width: 1px; opacity: 1;"),
    opts_hover_inv(css = "opacity: 0.3;"),
    opts_toolbar(position = "bottomright"),
    opts_zoom(min = 1, max = 4)
  )
)


################################################################################
#                        THAT'S IT, FOLKS — THANK YOU!                         #
################################################################################
