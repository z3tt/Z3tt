################################################################################
#                          LS Uppsala DataViz Course                           #
#  "Data Visualization with ggplot2: Extended Use of the Grammar of Graphics"  #
#                     Cédric Scherer | November 29, 2023                       #
################################################################################


## to run all codes, install the following typefaces and restart RStudio:
## Sofia Sans Semi Condensed + Spline Sans Mono 
## The font files are located in the `fonts` folder. 

## also, make sure to install the following packages 
packages <- c(
  "ggplot2", "readr", "dplyr", "forcats", "stringr", "scales", 
  "ragg", "systemfonts", "RColorBrewer", "ggtext", "ggforce", "ggrepel", 
  "geomtextpath", "patchwork"
)

install.packages(setdiff(packages, rownames(installed.packages())))


## -----------------------------------------------------------------------------
bikes <- 
  readr::read_csv(
    "https://cedricscherer.com/data/london-bikes-custom.csv",
    ## or: "./data/london-bikes-custom.csv"
    col_types = "Dcfffilllddddc"
  ) |> 
  dplyr::filter(!is.na(weather_type))


## -----------------------------------------------------------------------------
library(ggplot2)

theme_set(theme_minimal(
  base_size = 14, base_family = "Sofia Sans Semi Condensed"
))

theme_update(
  panel.grid.minor = element_blank(),
  legend.position = "top",
  plot.title.position = "plot"
)


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = temp)) +
  geom_point(stat = "identity")

ggplot(bikes, aes(x = date, y = temp)) +
  stat_identity(geom = "point")


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = count)) +
  stat_smooth(geom = "smooth")

ggplot(bikes, aes(x = temp, y = count)) +
  geom_smooth(stat = "smooth")


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = is_weekend)) +
  geom_bar(stat = "count")

ggplot(bikes, aes(x = is_weekend)) +
  stat_count(geom = "bar")


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  stat_summary() 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "pointrange"  ## the default
  ) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  geom_boxplot() +
  stat_summary(
    fun = mean,
    geom = "point",
    color = "#28a87d",
    size = 3
  ) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  stat_summary() +
  stat_summary(
    fun = mean,
    geom = "text",
    aes(label = after_stat(y))
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  stat_summary() +
  stat_summary(
    fun = mean,
    geom = "text",
    aes(label = after_stat(
      paste0(round(y, 1), "°C"))
    ),
    hjust = -.3,
    family = "Sofia Sans Semi Condensed",
    size = 5
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  stat_summary(
    fun = mean, 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y) 
  ) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1)
  ) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel,
        color = year)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1)
  ) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel,
        color = year)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1),
    position = position_dodge(
      width = .25
    )
  ) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = season, y = temp_feel,
        color = year)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1),
    position = position_dodge(
      width = .25
    )
  ) +
  stat_summary(
    fun = mean,
    geom = "text",
    aes(
      label = after_stat(paste0(round(y, 1), "°C")),
      hjust = year == "2015"
    ),
    position = position_dodge(
      width = -.6
    ),
    family = "Sofia Sans Semi Condensed",
    size = 4.5
  )


## -----------------------------------------------------------------------------
g <- 
  ggplot(
    data = bikes,
    aes(x = temp_feel, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "Feels Like temperature (°F)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    caption = "Data: TfL",
    color = NULL
  )

g


## -----------------------------------------------------------------------------
g +
  ggtitle(
    "**TfL bike sharing trends by _season_**"
  )


## -----------------------------------------------------------------------------
library(ggtext)

g +
  ggtitle("**TfL bike sharing trends by _season_**") +
  theme(
    plot.title = element_markdown()
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("<b style='font-family:tabular;font-size:25pt'>TfL</b> bike sharing trends by <i style='color:#28a87d;'>season</i>") +
  theme(
    plot.title = element_markdown()
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes, 
    aes(x = weather_type,
        y = count)
  ) +
  geom_boxplot()


## -----------------------------------------------------------------------------
library(stringr)

ggplot(
    data = bikes, 
    aes(x = str_wrap(weather_type, 6),
        y = count)
  ) +
  geom_boxplot()


## -----------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods")


## -----------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple()
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      margin = margin(t = 12, b = 12),
      lineheight = .95
    ),
    plot.title.position = "plot"
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      margin = margin(t = 12, b = 12),
      fill = "grey90",
      lineheight = .95
    ),
    plot.title.position = "plot"
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      margin = margin(t = 12, b = 12),
      padding = margin(rep(12, 4)),
      fill = "grey90",
      r = unit(9, "pt"),
      halign = .5,
      face = "bold",
      lineheight = .95
    ),
    plot.title.position = "plot"
  )


## -----------------------------------------------------------------------------
ga <- 
  ggplot(bikes, 
         aes(x = temp, y = count)) +
  geom_point(
    aes(color = count > 40000),
    size = 2
  ) +
  scale_color_manual(
    values = c("grey", "firebrick"),
    guide = "none"
  )

ga


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?"
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?",
    color = "firebrick",
    size = 6,
    family = "Sofia Sans Semi Condensed",
    fontface = "bold",
    lineheight =  .8
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = c(18, max(bikes$temp)),
    y = c(48000, 1000),
    label = c("What happened here?", "Powered by TfL"),
    color = c("firebrick", "black"),
    size = c(6, 3),
    family = c("Sofia Sans Semi Condensed", "Hepta Slab"),
    fontface = c("bold", "plain"),
    hjust = c(.5, 1)
  )


## -----------------------------------------------------------------------------
# ggannotate::ggannotate(g)


## -----------------------------------------------------------------------------
ga + 
  annotate(
    geom = "text",
    x = 19.5,
    y = 42000,
    label = "What happened here?",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    vjust = 1.3
  ) +
  annotate(
    geom = "rect",
    xmin = 17, 
    xmax = 22,
    ymin = 42000, 
    ymax = 54000,
    color = "firebrick", 
    fill = NA
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "segment",
    x = 14, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 14, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow()
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed",
      ends = "both"
    )
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .8,
    angle = 130,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed"
    )
  )


## -----------------------------------------------------------------------------
gh <- 
  ggplot(
    data = filter(bikes, temp >= 27),
    aes(x = date, y = temp)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5)

gh


## -----------------------------------------------------------------------------
gh +
  geom_text(
    aes(label = format(date, "%m/%d")),
    nudge_x = 10,
    hjust = 0
  )


## -----------------------------------------------------------------------------
gh +
  geom_label(
    aes(label = format(date, "%m/%d")),
    nudge_x = .3,
    hjust = 0
  )


## -----------------------------------------------------------------------------
set.seed(20230918)

gh +
  ggrepel::geom_text_repel(
    aes(label = format(date, "%m/%d"))
  )


## -----------------------------------------------------------------------------
set.seed(20230918)

gh + 
  ggrepel::geom_text_repel(
    aes(label = format(date, "%m/%d")),
    family = "Tabular",
    size = 4.5,
    fontface = "bold"
  )


## -----------------------------------------------------------------------------
gh +
  ggrepel::geom_text_repel(
    aes(label = format(date, "%m/%d")),
    family = "Tabular",
    # space between points + labels
    box.padding = .8,
    # always draw segments
    min.segment.length = 0
  )


## -----------------------------------------------------------------------------
gh +
  ggrepel::geom_text_repel(
    aes(label = format(date, "%y/%m/%d")),
    family = "Tabular",
    # force to the right
    xlim = c(NA, as.Date("2015-06-01")), 
    hjust = 1
  )


## -----------------------------------------------------------------------------
gh +
  ggrepel::geom_text_repel(
    aes(label = format(date, "%y/%m/%d")),
    family = "Tabular",
    xlim = c(NA, as.Date("2015-06-01")),
    # style segment
    segment.curvature = .01,
    arrow = arrow(length = unit(.02, "npc"), type = "closed")
  )


## -----------------------------------------------------------------------------
gh +
  ggrepel::geom_text_repel(
    aes(label = format(date, "%y/%m/%d")),
    family = "Tabular",
    xlim = c(NA, as.Date("2015-06-01")),
    # style segment
    segment.curvature = .001,
    segment.inflect = TRUE
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000)
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    color = "black",
    label.family = "Sofia Sans Semi Condensed"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = c("Hepta Slab", "Sofia Sans Semi Condensed"),
    expand = unit(8, "pt"),
    radius = unit(12, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_circle(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_hull(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  group_by(month, day_night) |> 
  summarize(count = sum(count)) |> 
  ggplot(aes(x = month, y = count, 
             color = day_night,
             group = day_night)) +
  geom_line(linewidth = 1) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    name = NULL
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  group_by(month, day_night) |> 
  summarize(count = sum(count)) |> 
  ggplot(aes(x = month, y = count, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    family = "Sofia Sans Semi Condensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  group_by(month, day_night) |> 
  summarize(count = sum(count)) |> 
  mutate(day_night = if_else(
    day_night == "day", 
    "Day period (6am-6pm)", 
    "Night period (6pm-6am)"
  )) |> 
  ggplot(aes(x = month, y = count, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    hjust = .05,
    family = "Sofia Sans Semi Condensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  ggplot(aes(x = month, y = count, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night), 
    stat = "summary", fun = sum,
    linewidth = 1
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    name = NULL
  )


## -----------------------------------------------------------------------------
g + 
  theme(
    plot.background = element_rect(
      color = "orange",
      fill = "grey40",
      size = 2,
      linetype = "dotted"
    ),
    axis.text = element_text( 
      family = "Hepta Slab",
      color = "orange",
      angle = 15,
      size = 20
    )
  )


## -----------------------------------------------------------------------------
library(systemfonts)

register_variant(
  name = "Sofia Sans Black",
  family = "Sofia Sans Semi Condensed", 
  weight = "heavy"
)

g +
  theme(
    plot.title = element_text(
      family = "Sofia Sans Black"
    ),
    axis.title = element_text(
      family = "Sofia Sans Semi Condensed",
      face = "bold"
    )
  )


## -----------------------------------------------------------------------------
theme_grey


## -----------------------------------------------------------------------------
theme_minimal


## -----------------------------------------------------------------------------
theme_custom <- function(base_size = 15, base_family = "Sofia Sans Semi Condensed", ...) { 
  theme_bw(base_size = base_size, base_family = base_family, 
           base_line_size = base_size / 30, ...) +
  theme(
    axis.ticks = element_blank(), 
    axis.text = element_text(size = base_size * .8),
    legend.text = element_text(size = base_size * .8),
    legend.background = element_blank(), 
    legend.key = element_blank(), 
    legend.position = "top", 
    panel.background = element_rect(fill = "grey97", color = NA), 
    panel.border = element_blank(), 
    panel.grid.major = element_line(color = "grey88"), 
    panel.grid.minor = element_blank(), 
    strip.background = element_blank(), 
    plot.background = element_blank(), 
    plot.title = ggtext::element_textbox_simple( 
      face = "bold", color = "black", fill = "grey97", 
      size = base_size * 1.4, r = unit(.5, "lines"), 
      margin = margin(15, 0, 15, 0), padding = margin(rep(8, 4)) 
    ), 
    plot.title.position = "plot"
  )
}


## -----------------------------------------------------------------------------
g + theme_custom()


## -----------------------------------------------------------------------------
g +
  labs(
    title = "I went to <b style='color:#28a87d;'>Cédric's ggplot2 course</b> and now I know how to build my own special <span style=font-family:tabular;>ggplot2</span> theme!"
  ) +
  theme_custom()


## -----------------------------------------------------------------------------
g +
  labs(
    title = "I went to <b style='color:#28a87d;'>Cédric's ggplot2 course</b> and now I know how to build my own <span style=font-family:tabular;>ggplot2</span> theme!"
  ) +
  theme_custom(
    base_size = 11, base_family = "Chubbo"
  ) +
  theme(legend.position = "right")


## -----------------------------------------------------------------------------
(time <- ggplot(bikes, aes(x = date, y = temp_feel)) +
  geom_point(aes(color = season)) +
  scale_color_brewer(palette = "Set1", guide = "none"))


## -----------------------------------------------------------------------------
(box <- ggplot(bikes, aes(temp_feel, season)) +
  geom_boxplot(aes(color = season)) +
  scale_color_brewer(palette = "Set1", guide = "none"))


## -----------------------------------------------------------------------------
library(patchwork)
time + box


## -----------------------------------------------------------------------------
time / box


## -----------------------------------------------------------------------------
time + box + plot_layout(widths = c(2, 1))


## -----------------------------------------------------------------------------
time + plot_spacer() + box + plot_layout(widths = c(2, .5, 1))


## -----------------------------------------------------------------------------
scatter <- 
  ggplot(
    data = bikes,  
    aes(temp_feel, humidity)
  ) +
  geom_point(aes(color = season)) +
  scale_color_brewer(
    palette = "Set1", 
    guide = "none"
  )

(box + scatter) / time + 
  plot_layout(heights = c(2, 1))


## -----------------------------------------------------------------------------
layout <- "
  AAAAA#
  BB####
  BB#CCC
  BB#CCC
"

time + scatter + box + 
  plot_layout(design = layout)


## -----------------------------------------------------------------------------
(box + scatter) / time + 
  plot_layout(
    heights = c(2, 1)
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL"
  )


## -----------------------------------------------------------------------------
scatter_t <- scatter + ggtitle("Title A")
box_t <- box + ggtitle("Title B")

(scatter_t + box_t) / time + 
  plot_layout(
    heights = c(2, 1)
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL"
  )


## -----------------------------------------------------------------------------
(box + scatter) / time +
  plot_layout(
    heights = c(2, 1)
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A"
  )


## -----------------------------------------------------------------------------
time / (box + scatter) + 
  plot_layout(
    heights = c(1, 2)
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A",
    tag_suffix = ")",
  )


## -----------------------------------------------------------------------------
time / (box + scatter) + 
  plot_layout(
    heights = c(1, 2)
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A",
    tag_prefix = "(",
    tag_suffix = ")"
  )


## -----------------------------------------------------------------------------
time / (box + scatter) + 
  plot_layout(
    heights = c(1, 2)
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "a",
    tag_prefix = "Fig. 1"
  )


## -----------------------------------------------------------------------------
scatter + inset_element(box, left = .75, bottom = .6, right = .99, top = .99) 


## -----------------------------------------------------------------------------
scatter + inset_element(box + labs(x = NULL, y = NULL), .75, .6, .99, .99) 


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_color_distiller(
    name = "Dark2" 
  )


## -----------------------------------------------------------------------------
library(RColorBrewer)

ggplot(
    data = bikes,  
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = brewer.pal(
      name = "Dark2", n = 4
    )
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = brewer.pal(
      name = "Dark2", n = 6
    )[c(1, 6, 4, 3)]
  )


## -----------------------------------------------------------------------------
pal_custom <- 
  brewer.pal(
    name = "Dark2", n = 6
  )[c(1, 6, 4, 3)]

ggplot(
    data = bikes,  
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
library(colorspace)

pal_light <- lighten(pal_custom, .7)

ggplot(
    data = bikes,  
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = pal_light
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(fill = season,
        fill = after_scale(
          lighten(fill, .7)
    ))
  ) +
  scale_fill_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(
      fill = stage(
        season,
        after_scale =
          lighten(fill, .7)
      )
    )
  ) +
  scale_fill_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .7)
    ))
  ) +
  scale_color_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .7)
    )),
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season), 
    position = position_jitterdodge(
      dodge.width = .75, 
      jitter.width = .2
    ),
    alpha = .4
  ) +
  scale_color_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .7)
        )),
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season,
        color = after_scale(
          darken(color, .3)
    )), 
    position = position_jitterdodge(
      dodge.width = .75, 
      jitter.width = .2
    ),
    alpha = .4
  ) +
  scale_color_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
ggplot(
    data = bikes,  
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .7)
        )),
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season,
        color = after_scale(
          darken(color, .3)
        )), 
    position = position_jitterdodge(
      dodge.width = .75, 
      jitter.width = .2
    ),
    alpha = .4
  ) +
  scale_color_manual(
    values = pal_custom
  )


## -----------------------------------------------------------------------------
## THAT'S IT FOLKS...
## -----------------------------------------------------------------------------

