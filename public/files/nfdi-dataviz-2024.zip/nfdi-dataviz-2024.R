################################################################################
#                    NFDI4Biodiversity Seasonal School 2024                    #
#        "Data Analysis & Visualisation According to FAIR Principles"          #
#                     Cédric Scherer | December 5, 2024                        #
################################################################################


## To run all codes, install the typeface Sofia Sans Semi Condensed and 
## restart RStudio. The font files are located in the `fonts` folder. 

## Also, make sure to install the following packages:
packages <- c(
  "ggplot2", "readr", "dplyr", "forcats", "stringr", "scales", 
  "ragg", "rcartocolor", "janitor", "ggtext", "here"
)

install.packages(setdiff(packages, rownames(installed.packages())))



## Import the Data -------------------------------------------------------------

trydb <- read.csv("data/try_reduced.csv")
gbif <- read.csv("data/gbif1.csv")


trydb <- readr::read_csv(here::here("data", "try_reduced.csv"))
gbif <- readr::read_csv(here::here("data", "gbif1.csv"))


library(readr)
library(here)
 
trydb <- read_csv(here("data", "try_reduced.csv"))
gbif <- read_csv(here("data", "gbif1.csv"))


trydb <- read_csv("https://raw.githubusercontent.com/NFDI4Biodiversity/SeasonalSchool2024/refs/heads/main/day4/practical_session4/data/try_reduced.csv")
gbif <- read_csv("https://raw.githubusercontent.com/NFDI4Biodiversity/SeasonalSchool2024/refs/heads/main/day4/practical_session4/data/gbif1.csv")


## Inspect the Data ------------------------------------------------------------

dplyr::glimpse(trydb)

trydb <- janitor::clean_names(trydb)

dplyr::glimpse(trydb)


unique(trydb$unit_name)

length(unique(trydb$species_name))

median(trydb$std_value)

median(trydb$std_value, na.rm = TRUE)

quantile(trydb$std_value, na.rm = TRUE)


summary(trydb)


dplyr::count(trydb)


dplyr::count(trydb, species_name)


dplyr::count(trydb, trait_name)


dplyr::count(trydb, species_name, trait_name)


## Wrangle the Data ------------------------------------------------------------

library(dplyr)

filter(trydb, trait_name == "Leaf nitrogen (N) content per leaf area")


trydb_nitro <- filter(trydb, trait_name == "Leaf nitrogen (N) content per leaf area")
select(trydb_nitro, species_name, std_value)


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  select(species_name, std_value)


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  select(species_name, std_value) |> 
  arrange(std_value)


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  select(species_name, std_value) |> 
  arrange(-std_value)


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  select(species_name, std_value) |> 
  arrange(-std_value) |> 
  mutate(genus_name = stringr::word(species_name, 1))


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  select(species_name, std_value) |> 
  arrange(-std_value) |> 
  mutate(genus_name = stringr::word(species_name, 1)) |> 
  filter(genus_name == "Larix")


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  select(species_name, std_value) |> 
  arrange(-std_value) |> 
  filter(stringr::str_detect(species_name, "Larix"))


trydb |> 
  filter(trait_name == "Leaf nitrogen (N) content per leaf area") |> 
  group_by(species_name) |> 
  summarize(std_value_avg = mean(std_value, na.rm = TRUE)) |> 
  arrange(-std_value_avg)


## Visualize the Data ----------------------------------------------------------

library(ggplot2)

?ggplot


ggplot(data = trydb) +
  aes(x = std_value,
      y = trait_name) +
  geom_boxplot()


ggplot(data = trydb) +
  aes(x = std_value, y = trait_name) +
  geom_boxplot()

ggplot(data = trydb) +
  aes(
    x = std_value, 
    y = trait_name
  ) +
  geom_boxplot()

ggplot(data = trydb,
       mapping = aes(x = std_value, y = trait_name)) +
  geom_boxplot()

ggplot(trydb,
       aes(std_value, trait_name)) +
  geom_boxplot()


ggplot(trydb) +
  aes(
    x = std_value,
    y = stringr::str_trunc(trait_name, 30)
  ) +
  geom_boxplot()


ggplot(trydb) +
  aes(
    x = std_value,
    y = stringr::str_trunc(trait_name, 30)
  ) +
  geom_jitter()


ggplot(trydb) +
  aes(
    x = std_value,
    y = stringr::str_trunc(trait_name, 30)
  ) +
  geom_jitter(
    height = .3,
    alpha = .05
  )


ggplot(trydb) +
  aes(
    x = std_value,
    y = stringr::str_trunc(trait_name, 30)
  ) +
  geom_jitter(
    height = .3,
    alpha = .05
  ) +
  scale_x_log10()


ggplot(data = trydb) +
  aes(
    x = std_value + 1,
    y = stringr::str_trunc(trait_name, 30)
  ) +
  geom_jitter(
    height = .3,
    alpha = .05
  ) +
  scale_x_log10()


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram()


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram(
    bins = 50
  )


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram(
    binwidth = .2
  )


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram(
    aes(fill = species_name)
  )


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram(
    aes(fill = species_name == "Pinus sylvestris")
  )


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram(
    aes(fill = stringr::word(species_name, 1))
  )


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram(
    aes(fill = stringr::word(species_name, 1))
  ) +
  rcartocolor::scale_fill_carto_d(
    palette = "Prism",
    name = "Genus:"
  )


ggplot(trydb_nitro) +
  aes(x = std_value) +
  geom_histogram() +
  facet_wrap(
    ~ stringr::word(species_name, 1),
    ncol = 2
  )


ggplot(trydb_nitro) +
  aes(
    x = std_value,
    y = species_name
  ) +
  geom_boxplot()


ggplot(trydb_nitro) +
  aes(
    x = std_value,
    y = species_name
  ) +
  stat_summary()


ggplot(trydb_nitro) +
  aes(
    x = std_value,
    y = species_name
  ) +
  stat_summary(
    fun = "mean",
    fun.min = function(x) mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE),
    fun.max = function(x) mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE)
  )


ggplot(trydb_nitro) +
  aes(
    x = std_value,
    y = species_name
  ) +
  stat_summary(
    fun = "mean",
    fun.min = function(x) mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE),
    fun.max = function(x) mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE)
  ) +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    labels = scales::number_format(suffix = " g/m²")
  ) +
  scale_y_discrete(limits = rev) +
  labs(
    x = "Leaf nitrogen (N) content per leaf area",
    y = NULL
  ) +
  theme_minimal(
    base_family = "Roboto Condensed",
    base_size = 13
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0)
  )


ggplot(trydb_nitro) +
  aes(
    x = std_value,
    y = forcats::fct_reorder(species_name, std_value, .fun = "mean")
  ) +
  stat_summary(
    fun = "mean",
    fun.min = function(x) mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE),
    fun.max = function(x) mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE)
  ) +
  coord_cartesian(clip = "off") +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    labels = scales::number_format(suffix = " g/m²")
  ) +
  labs(
    x = "Leaf nitrogen (N) content per leaf area",
    y = NULL
  ) +
  theme_minimal(
    base_family = "Roboto Condensed",
    base_size = 13
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0)
  )


ggplot(trydb_nitro) +
  aes(
    x = std_value,
    y = forcats::fct_reorder(species_name, std_value, .fun = "mean")
  ) +
  geom_jitter(
    height = .25,
    alpha = .3,
    size = .6,
    color = "grey60"
  ) +
  stat_summary(
    fun = "mean",
    fun.min = function(x) mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE),
    fun.max = function(x) mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE)
  ) +
  coord_cartesian(clip = "off") +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    labels = scales::number_format(suffix = " g/m²")
  ) +
  scale_y_discrete(limits = rev) +
  labs(
    x = "Leaf nitrogen (N) content per leaf area",
    y = NULL
  ) +
  theme_minimal(
    base_family = "Roboto Condensed",
    base_size = 13
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0)
  )


trydb_nitro |> 
  mutate(genus_name = stringr::word(species_name, 1)) |> 
  ggplot() +
  aes(
    x = std_value,
    y = forcats::fct_reorder(genus_name, std_value, .fun = "mean")
  ) +
  geom_jitter(
    height = .25,
    alpha = .2,
    size = .6,
    color = "grey60"
  ) +
  stat_summary(
    fun = "mean",
    fun.min = function(x) mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE),
    fun.max = function(x) mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE)
  ) +
  coord_cartesian(clip = "off") +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    labels = scales::number_format(suffix = " g/m²")
  ) +
  scale_y_discrete(limits = rev) +
  labs(
    x = "Leaf nitrogen (N) content per leaf area",
    y = NULL
  ) +
  theme_minimal(
    base_family = "Roboto Condensed",
    base_size = 13
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0)
  )


trydb_nitro |> 
  mutate(genus_name = stringr::word(species_name, 1)) |> 
  ggplot() +
  aes(
    x = std_value,
    y = forcats::fct_reorder(genus_name, std_value, .fun = "median")
  ) +
  geom_boxplot(
    color = "grey50",
    fill = "grey92",
    outlier.colour = NA,
    width = .7
  ) +
  geom_jitter(
    height = .2,
    alpha = .1,
    size = .6
  ) +
  coord_cartesian(clip = "off") +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    labels = scales::number_format(suffix = " g/m²")
  ) +
  scale_y_discrete(limits = rev) +
  labs(
    x = "Leaf nitrogen (N) content per leaf area",
    y = NULL
  ) +
  theme_minimal(base_family = "Roboto Condensed") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0)
  )


ggplot(gbif) +
  aes(y = species) +
  geom_bar(width = .7)


gbif |> 
  group_by(species) |> 
  filter(n() > 10000) |> 
  ggplot() +
  aes(y = species) +
  geom_bar(width = .7)


gbif_common <-
  gbif |> 
  group_by(species) |> 
  filter(n() > 10000) |> 
  ungroup()
  

ggplot(gbif_common) +
  aes(y = species) +
  geom_bar(width = .7)


ggplot(gbif_common) +
  aes(y = forcats::fct_infreq(species)) +
  geom_bar(width = .7) +
  scale_y_discrete(limits = rev)


g <- 
  ggplot(gbif_common) +
  aes(y = forcats::fct_infreq(species)) +
  geom_bar(
    aes(fill = species == "Quercus robur"),
    width = .7
  ) +
  scale_y_discrete(limits = rev) +
  scale_fill_manual(
    values = c("grey40", "#28A87D"), guide = "none"
  ) +
  labs(
    x = "Number of observations in Germany",
    y = NULL,
    caption = "Data: Global Biodiversity Information Facility (GBIF)"
  )  +
  theme_minimal(
    base_family = "Roboto Condensed",
    base_size = 14
  )
  
g


g +
  coord_cartesian(clip = "off") +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    labels = scales::comma
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.title.x = element_text(hjust = 0),
    axis.text.y = element_text(face = "italic", hjust = 0, size = rel(.9)),
    plot.caption = element_text(color = "grey40", hjust = 0, margin = margin(t = 15)),
    plot.caption.position = "plot"
  )


g +
  stat_count(
    geom = "text",
    aes(label = after_stat(count)),
    hjust = 1.1,
    family = "Roboto Condensed",
    color = "white",
    fontface = "bold"
  ) +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    guide = "none",
    name = NULL
  ) +
  labs(title = "The English oak (Quercus robur) is the most observed tree species in Germany") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0, size = rel(.9)),
    plot.caption = element_text(color = "grey60", hjust = 0, margin = margin(t = 15)),
    plot.caption.position = "plot",
    plot.title = element_text(face = "bold.italic", size = rel(1.3)),
    plot.title.position = "plot"
  )


g +
  stat_count(
    geom = "text",
    aes(label = after_stat(format(count, big.mark = ","))),
    hjust = 1.2,
    family = "Roboto Condensed",
    color = "white",
    fontface = "bold"
  ) +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    guide = "none",
    name = NULL
  ) +
  labs(title = "The English oak (Quercus robur) is the most observed tree species in Germany") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0, size = rel(.9)),
    plot.caption = element_text(color = "grey60", hjust = 0, margin = margin(t = 15)),
    plot.caption.position = "plot",
    plot.title = ggtext::element_textbox_simple(face = "bold.italic", size = rel(1.3)),
    plot.title.position = "plot"
  )


g +
  stat_count(
    geom = "text",
    aes(label = after_stat(format(count, big.mark = ","))),
    hjust = 1.2,
    family = "Roboto Condensed",
    color = "white",
    fontface = "bold"
  ) +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    guide = "none",
    name = NULL
  ) +
  labs(title = "The English oak (*Quercus robur*) is the most observed tree species in Germany") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0, size = rel(.9)),
    plot.caption = element_text(color = "grey60", hjust = 0, margin = margin(t = 15)),
    plot.caption.position = "plot",
    plot.title = ggtext::element_textbox_simple(face = "bold", size = rel(1.3), lineheight = 1),
    plot.title.position = "plot"
  )


g +
  stat_count(
    geom = "text",
    aes(label = after_stat(format(count, big.mark = ","))),
    hjust = 1.1,
    family = "Roboto Condensed",
    color = "white",
    fontface = "bold"
  ) +
  scale_x_continuous(
    expand = expansion(add = c(0, .5)),
    limits = c(0, NA),
    guide = "none",
    name = NULL
  ) +
  labs(title = "The <span style='color:#28A87D;font-weight:700;'>English oak (*Quercus robur*)</span> is the most observed tree species in Germany") +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    axis.text.y = element_text(face = "italic", hjust = 0, size = rel(.9)),
    plot.caption = element_text(color = "grey60", hjust = 0, margin = margin(t = 15)),
    plot.caption.position = "plot",
    plot.title = ggtext::element_textbox_simple(face = "bold", size = rel(1.3), lineheight = 1),
    plot.title.position = "plot"
  )


## Export the Graphic ----------------------------------------------------------

## save stored plot
ggsave(filename = "my_plot.png", plot = g)

## save last plot (with implicit matching of `filename`)
ggsave("my_plot.png")

## save last plot with custom settings
ggsave("my_plot.png", width = 6.7, height = 5, dpi = 600)

## save last plot with custom unit
ggsave("my_plot.png", width = 17.02, height = 12.7, unit = "cm", dpi = 600)

## save last plot as PDF file
ggsave("my_plot.pdf", width = 6.7, height = 5, device = cairo_pdf)

## save last plot as SVG file
ggsave("my_plot.svg", width = 6.7, height = 5)



## -----------------------------------------------------------------------------
## THAT'S IT FOLKS...
## -----------------------------------------------------------------------------
