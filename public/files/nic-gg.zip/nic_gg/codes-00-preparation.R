#------------------------------------------------------------------------------#
#                                                                              #
#           Engaging Data Visualizations for Graphical Storytelling            #
#                              Install R Packages                              #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                        NIC.br Workshop // August 2024                        #
#                                                                              #
#------------------------------------------------------------------------------#


pkgs <- c("ggplot2", "readr", "dplyr", "tibble", "tidyr", "forcats", 
          "stringr", "lubridate", "purrr", "here", "scales", "ragg", 
          "systemfonts", "RColorBrewer", "patchwork", "ragg", "camcorder", 
          "marquee", "ggtext", "ggdist", "ggridges", "ggbeeswarm", "ggblend", 
          "ggpointdensity", "ggforce", "concavemen", "ggiraph")

install.packages(setdiff(pkgs, rownames(installed.packages())))

remotes::install_github("AllanCameron/geomtextpath")
