#------------------------------------------------------------------------------#
#                                                                              #
#           Engaging Data Visualizations for Graphical Storytelling            #
#                      From Theory to Practice with ggplot2                    #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                        NIC.br Workshop // August 2024                        #
#                                                                              #
#------------------------------------------------------------------------------#


## SETUP ----------------------------------------------------------------------#

## The Data Set

years <- c(2015:2020, 2022, 2023)
  
dat <- 
  tibble::tibble(
    year = rep(years, 2),
    pop = rep(c("urban", "rural"), each = length(years)),
    share = c(.63, .65, .71, .74, .77, .83, .82, .85,
              .34, .39, .44, .49, .53, .70, .72, .78)
  ) |> 
  dplyr::mutate(pop = forcats::fct_rev(pop))

## Load the ggplot2 Package

library(ggplot2)

# library(tidyverse)


## A BASIC GGPLOT EXAMPLE -----------------------------------------------------#

## Data

?ggplot

ggplot(data = dat)


## Aesthetic Mapping

ggplot(data = dat) +
  aes(x = year, y = share)

ggplot(data = dat, mapping = aes(x = year, y = share))

ggplot(dat, aes(temp, count))

ggplot(dat, aes(x = year, y = share))


## Geometrical Layers

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point()

ggplot(
    dat,
    aes(x = factor(year), y = share)
  ) +
  geom_point()

ggplot(
    dat,
    aes(x = pop, y = share)
  ) +
  geom_point()

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    color = "#28a87d",
    shape = "X",
    stroke = 1,
    size = 4
  )

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    color = "#28a87d",
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    aes(color = pop),
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    aes(color = share >= .67),
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    aes(color = pop),
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share,
        color = pop)
  ) +
  geom_point(
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share,
        color = pop)
  ) +
  geom_point(,
    size = 2
  ) +
  geom_line()

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    aes(color = pop),
    size = 2
  ) +
  geom_line()

ggplot(
    dat,
    aes(x = year, y = share)
  ) +
  geom_point(
    aes(color = pop),
    size = 2
  ) +
  geom_line(
    aes(group = pop)
  )

ggplot(
    dat,
    aes(x = year, y = share,
        color = pop)
  ) +
  geom_point(
    size = 2,
    color = "black"
  ) +
  geom_line()

ggplot(
    dat,
    aes(x = year, y = share,
        color = pop)
  ) +
  geom_line() +
  geom_point(
    size = 2,
    color = "black"
  )

ggplot(
    dat,
    aes(x = year, y = share,
        color = interaction(pop, year > 2021))
  ) +
  geom_line() +
  geom_point(
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share,
        color = pop,
        geoup = interaction(pop, year > 2021))
  ) +
  geom_line() +
  geom_point(
    size = 2
  )

ggplot(
    dat,
    aes(x = year, y = share,
        shape = pop)
  ) +
  geom_point(
    size = 2
  ) +
  geom_line()


## Store a ggplot as Object

g <-
  ggplot(
    dat,
    aes(x = year, y = share,
        color = pop)
  ) +
  geom_point(
    size = 2
  ) +
  geom_line()

class(g)


## More Geometries

g +
  geom_smooth(
    method = "lm"
  )

g +
  geom_smooth(
    method = "lm",
    color = "black"
  )

g +
  geom_rug(
    alpha = .7,
    sides = "r"
  )

g +
  geom_label(
    aes(label = share),
    vjust = -.3
  )

g +
  geom_label(
    aes(label = share),
    vjust = -.3,
    show.legend = FALSE
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        color = pop)
  ) +
  geom_step()

ggplot(
    dat,
    aes(x = year,
        y = share,
        color = pop)
  ) +
  geom_area()

ggplot(
    dat,
    aes(x = year,
        y = share,
        color = pop,
        fill = pop)
  ) +
  geom_area(
    alpha = .5
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        color = pop,
        fill = pop)
  ) +
  geom_area(
    alpha = .5,
    position = "identity"
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        color = pop,
        fill = pop)
  ) +
  geom_area(
    alpha = .5,
    position = "fill"
  )


## A POLISHED GGPLOT EXAMPLE --------------------------------------------------#

## Modify/Add Titles

g + 
  xlab("Year") +
  ylab("Share of Internet Users") +
  ggtitle("Rural areas catch up!")

g +
  labs(
    x = "Year",
    y = "Share of Internet Users",
    title = "Rural areas catch up!"
  )

g +
  labs(
    x = "Year",
    y = "Share of Internet Users",
    title = "Rural areas catch up!",
    color = "Population:"
  )

g +
  labs(
    x = "Year",
    y = "Share of Internet Users",
    title = "Rural areas catch up!",
    subtitle = "Internet usage in Brazil by urbanity",
    caption = "Note that data for 2021 is missing.",
    color = "Population:",
    tag = "Fig. 1"
  )

g +
  labs(
    x = "",
    caption = "Note that data for 2021 is missing."
  )

g +
  labs(
    x = NULL,
    caption = "Note that data for 2021 is missing."
  )

g <- 
  g +
  labs(
    x = NULL,
    y = "Share of Internet Users",
    title = "Rural areas catch up!",
    subtitle = "Internet usage in Brazil by urbanity",
    color = NULL
  )
  
g


## Modify Axis Labels

g +
  scale_y_continuous(
    labels = function(y) paste0(
      y * 100, "%"
    )
  )

g +
  scale_y_continuous(
    labels = scales::percent
  )

g +
  scale_y_continuous(
    labels = scales::percent,
    name = "New title"
  )

g +
  scale_y_continuous(
    labels = scales::percent,
    position = "right"
  )

g +
  scale_x_continuous(
    breaks = 2015:2023
  ) +
  scale_y_continuous(
    labels = scales::percent
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023),
    expand = c(0, .1)
  ) +
  scale_y_continuous(
    labels = scales::percent
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023),
    expand = expansion(
      add = c(.1, 3) ## or `mult`
    )
  ) +
  scale_y_continuous(
    labels = scales::percent
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_discrete(
    labels = c("Urban areas", "Rural areas")
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_discrete(
    labels = stringr::str_to_title
  )


## Customize Colors

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_discrete(
    labels = stringr::str_to_title,
    type = c("orange", "forestgreen")
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_discrete(
    labels = stringr::str_to_title,
    type = c("#EFAC00", "#28A87D")
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_manual(
    labels = stringr::str_to_title,
    values = c("#EFAC00", "#28A87D")
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_manual(
    labels = stringr::str_to_title,
    values = RColorBrewer::brewer.pal(
      n = 2, name = "Set2"
    )
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_brewer(
    labels = stringr::str_to_title,
    palette = "Set2"
  )

g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  rcartocolor::scale_color_carto_d(
    labels = stringr::str_to_title,
    palette = "Bold"
  )

g <- 
  g +
  scale_x_continuous(
    breaks = c(2015:2020, 2022, 2023)
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_discrete(
    labels = stringr::str_to_title,
    type = c("#EFAC00", "#28A87D")
  )
  
g


## Complete Themes

g + theme_bw()

g + theme_minimal()

g + theme_bw(
  base_size = 11 # default
)

g + theme_minimal(
  base_size = 13
)

g + theme_bw(
  base_size = 11, # default
  base_family = "Comic Sans MS"
)

g + theme_minimal(
  base_size = 13,
  base_family = "Georgia"
)

theme_set(
  theme_minimal()
)

g

theme_set(
  theme_minimal(
    base_size = 13,
    base_family = "Georgia"
  )
)

g


## Overwrite Specific Theme Settings

g +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank()
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot",
    legend.position = "top",
    legend.justification = "left"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot",
    legend.position = "none"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    plot.title = element_text(face = "bold"),
    plot.title.position = "plot",
    legend.position = "inside",
    legend.position.inside = c(.7, .78)
  )

theme_update(
  panel.grid.minor = element_blank(),
  panel.grid.major.x = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  legend.position = "top"
)

g +
  theme(
    legend.position = "inside",
    legend.position.inside = c(.7, .78)
  )


## Saving Plots

ggsave(filename = "my_plot.png", plot = g)

ggsave("my_plot.png")

ggsave("my_plot.png", width = 5, height = 6, dpi = 600)

ggsave("my_plot.png", width = 5*2.54, height = 6*2.54, unit = "cm", dpi = 600)

ggsave("my_plot.pdf", width = 5, height = 6)

ggsave("my_plot.svg", width = 5, height = 6)


## ANOTHER GGPLOT EXAMPLE -----------------------------------------------------#

## Bar Charts

ggplot(
    dat,
    aes(x = year)
  ) +
  geom_bar()

ggplot(
    dat,
    aes(x = year,
        fill = pop)
  ) +
  geom_bar()

ggplot(
    dat,
    aes(x = year,
        y = share)
  ) +
  geom_col()

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col()

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    position = "dodge",
    width = .7
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    position = position_dodge(
      width = .7
    )
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    position = position_dodge2()
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    position = position_dodge2(
      padding = .3
    ),
    width = .5
  )


## Small Multiples

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop,
    ncol = 1
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop
  ) +
  theme(
    legend.position = "none"
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop, 
    switch = "x"
  ) +
  theme(
    legend.position = "none"
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop, 
    switch = "x"
  ) +
  theme(
    legend.position = "none",
    strip.placement = "outside",
    axis.title.x = element_blank()
  )

ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop, 
    switch = "x",
    labeller = labeller(
      .default = stringr::str_to_title
    )
  ) +
  theme(
    legend.position = "none",
    strip.placement = "outside",
    axis.title.x = element_blank()
  )


## Store the Plot

p <- 
  ggplot(
    dat,
    aes(x = year,
        y = share,
        fill = pop)
  ) +
  geom_col(
    width = .7
  ) +
  facet_wrap(
    ~ pop, 
    switch = "x",
    labeller = labeller(
      .default = stringr::str_to_title
    )
  ) +
  theme(
    legend.position = "none",
    strip.placement = "outside",
    axis.title.x = element_blank()
  )
  
p


## Polish the Bar Chart

p <- p +
  scale_x_continuous(
    breaks = c(2015:2020, 2022:2023),
    labels = function(x) paste0(
      "'", substr(x, 3, 5)
    )
  ) +
  scale_y_continuous(
    expand = c(0, 0),
    labels = scales::percent,
    sec.axis = dup_axis(),
    name = NULL
  ) +
  scale_fill_manual(
    values = c("#EFAC00", "#28A87D")
  )
  
p

p +
  labs(subtitle = "Share of Internet Users in Brazil by Urbanity") +
  theme(
    strip.text.x = element_text(
      face = "bold",
      hjust = 0,
      size = rel(1.3)
    ),
    panel.spacing = unit(.05, "npc")
  )

p +
  labs(subtitle = "Share of Internet Users in Brazil by Urbanity") +
  theme(
    strip.text.x = element_text(
      face = "bold",
      hjust = 0,
      size = rel(1.3)
    ),
    panel.grid.major.x = element_blank(),
    panel.spacing = unit(.05, "npc")
  )

#------------------------------------------------------------------------------#
# THAT'S IT, FOLKS!                                                            #
#------------------------------------------------------------------------------#