########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 1–5 2021  #
########################################################################

#### ANNOTATIONS #######################################################
#-----------------------------------------------------------------------



## Preparation ---------------------------------------------------------

library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/chicago-nmmaps.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)


## Annotations #########################################################

## annotate() -----------------------------------------------------------
ggplot(chic, aes(temp, o3)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "rect",
    xmin = 10,
    xmax = 60,
    ymin = 5,
    ymax = 20,
    fill = NA,
    color = "red"
  )

ggplot(chic, aes(temp, o3)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "rect",
    xmin = 60,
    xmax = Inf,
    ymin = -Inf,
    ymax = Inf,
    fill = "red",
    alpha = .5
  )

ggplot(chic, aes(temp, o3)) +
  annotate(
    geom = "rect",
    xmin = 60,
    xmax = Inf,
    ymin = -Inf,
    ymax = Inf,
    fill = "red",
    alpha = .5
  )  +
  geom_point(alpha = .4)

ggplot(chic, aes(temp, o3)) +
  annotate(
    geom = "rect",
    xmin = 60,
    xmax = Inf,
    ymin = -Inf,
    ymax = Inf,
    fill = "red",
    alpha = .5
  )  +
  geom_point(alpha = .4) +
  facet_wrap(~ year)

ggplot(chic, aes(death, o3)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "text",
    x = 150,
    y = 45,
    label = "Some\nadditional\ntext",
    size = 5,
    color = "blue",
    fontface = "bold"
  )

ggplot(chic, aes(death, o3)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "text",
    x = 150,
    y = 45,
    label = "Some\nadditional\ntext",
    size = 5,
    color = "blue",
    fontface = "bold"
  ) +
  facet_wrap(~ year)

ggplot(chic, aes(death, o3)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "text",
    x = 150,
    y = 45,
    label = "Some\nadditional\ntext",
    size = 5,
    color = "blue",
    fontface = "bold"
  ) +
  facet_wrap(
    ~ year,
    scales = "free"
  )

## annotation_custom() --------------------------------------------------
ggplot(chic, aes(death, o3)) +
  geom_point(alpha = .4) +
  annotation_custom(
    grid::textGrob(
      x = 0.8, 
      y = 0.8, 
      label = "Some\nadditional\ntext",
      gp = grid::gpar(
        col = "blue",
        fontsize = 15,
        fontface = "bold"
      )
    )
  ) +
  facet_wrap(
    ~ year,
    scales = "free"
  )

## with annotate_custom we can also add images:

#install.packages("magick")
url <- "https://image.jimcdn.com/app/cms/image/transf/dimension=640x10000:format=png/path/sc907c1c4cc8c1f1e/image/i71ccc2b41a89bd06/version/1590433540/image.png"
img <- magick::image_read(url)

ggplot(chic, aes(death, o3)) +
  annotation_custom(
    grid::rasterGrob(
      image = img
    )
  ) +
  geom_point(alpha = .4)

ggplot(chic, aes(death, o3)) +
  annotation_custom(
    grid::rasterGrob(
      image = img,
      width = unit(.8, "npc"),
      height = unit(.5, "npc")
    )
  ) +
  geom_point(alpha = .4)

ggplot(chic, aes(death, o3)) +
  annotation_custom(
    grid::rasterGrob(
      image = img,
      x = .85,
      y = .85,
      width = .25
    )
  ) +
  geom_point(alpha = .4)

## geom_text() and geom_label() -----------------------------------------
## You can easily add text labels to your plot by using 
## geom_text() or geom_label():
chic_sum <-
  chic %>%
  group_by(season) %>%
  summarize(
    avg = mean(temp, na.rm = TRUE)
  )

chic_sum

(g <-
  ggplot(chic_sum,
    aes(
      season,
      avg,
      fill = season
    )) +
    geom_col() +
    scale_fill_brewer(
      palette = "Dark2",
      guide = FALSE
    ) +
   labs(
     x = NULL,
     y = "Mean temperature (°F)"
   )
)

g +
  geom_text(
    aes(
      label = round(avg, 1)
    )
  )

g +
  geom_label(
    aes(
      label = round(avg, 1)
    )
  )

g +
  geom_label(
    aes(
      label = round(avg, 1)
    ),
    fill = "white"
  )

g +
  geom_label(
    aes(
      label = round(avg, 1),
      color = season
    ),
    fill = "white"
  )

g <-
  g +
  scale_color_brewer(
    palette = "Dark2",
    guide = FALSE
  )

g +
  geom_label(
    aes(
      label = round(avg, 1),
      color = season
    ),
    fill = "white"
  )

g +
  geom_label(
    aes(
      label = round(avg, 1),
      color = season
    ),
    fill = "white",
    nudge_y = 5
  )

g +
  geom_label(
    aes(
      label = round(avg, 1),
      color = season
    ),
    fill = "white",
    nudge_y = -10
  )

g +
  geom_label(
    aes(
      y = 5,
      label = round(avg, 1),
      color = season
    ),
    fill = "white"
  )

g +
  geom_label(
    aes(
      y = avg / 2,
      label = round(avg, 1),
      color = season
    ),
    fill = "white"
  )

g +
  geom_label(
    aes(
      y = avg / 2,
      label = round(avg, 1)
    ),
    fill = "white",
    size = 6,
    family = "Roboto Mono",
    fontface = "bold",
    vjust = .7
  )

g +
  geom_label(
    aes(
      y = avg / 2,
      label = round(avg, 1)
    ),
    fill = "white",
    size = 6,
    family = "Roboto Mono",
    fontface = "bold",
    label.padding = unit(1.1, "lines"),
    label.r = unit(1.5, "lines"),
    label.size = 2
  )

g +
  geom_label(
    aes(
      y = avg / 2,
      label = round(avg, 1)
    ),
    fill = "white",
    size = 6,
    family = "Roboto Mono",
    fontface = "bold",
    label.padding = unit(1.1, "lines"),
    label.r = unit(0, "lines"),
    label.size = 0
  )

set.seed(2020)

sample <- chic %>%
  group_by(season) %>%
  sample_frac(0.01)

ggplot(sample, aes(date, temp)) +
  geom_point() +
  geom_text(
    aes(
      color = temp,
      label = season),
    fontface = "bold",
    nudge_y = 1.5) +
  scale_color_viridis_c(guide = FALSE)

## geom_text_repel() and geom_label_repel() -----------------------------
#install.packages("ggrepel")
library(ggrepel)

ggplot(sample, aes(date, temp)) +
  geom_point() +
  geom_text_repel(
    aes(
      color = temp,
      label = season),
    fontface = "bold",
    nudge_y = 1.5) +
  scale_color_viridis_c(guide = FALSE)

ggplot(sample, aes(date, temp)) +
  geom_point() +
  geom_label_repel(
    aes(
      color = temp,
      label = season),
    fontface = "bold",
    nudge_y = 1.5,
    label.size = .8
  ) +
  scale_color_viridis_c(guide = FALSE)

## geom_mark_*() --------------------------------------------------------
#install.packages("ggforce")
library(ggforce)

ggplot(chic, aes(date, temp)) +
  geom_mark_rect(
    aes(
      label = year,
      fill = year
    ),
    con.cap = unit(0, "pt"),
    expand = unit(2, "pt")
  ) +
  geom_point() +
  scale_fill_viridis_d(
    guide = FALSE
  ) +
  scale_x_date(
    expand = c(.4, .4)
  )

ggplot(chic, aes(dewpoint, temp)) +
  geom_mark_ellipse(
    aes(
      label = season,
      filter = season == "Summer"
    )
  ) +
  geom_point(alpha = .7) +
  scale_fill_viridis_d() +
  scale_x_continuous(
    expand = c(.1, .1)
  ) +
  scale_y_continuous(
    expand = c(.1, .1)
  ) +
  theme(
    legend.position = c(.85, .2)
  )


## {ggtext} ----------------------------------------------------------
#install.packages("ggtext")
library(ggtext)

ggplot(chic, aes(season, temp)) +
  geom_jitter(
    aes(color = year),
    width = 0.3
  ) +
  ggtitle("**Temperature** per *Season* and *Year*") +
  theme(plot.title = element_markdown())

ggplot(chic, aes(season, temp)) +
  geom_jitter(
    aes(color = year),
    width = 0.3
  ) +
  ggtitle("<b style='color:red;font-size:25pt;'>Temperature</b> per <i style='color:blue;'>Season</i> and <i style='color:blue;'>Year</i>") +
  theme(plot.title = element_markdown())

ggplot(chic, aes(season, temp)) +
  geom_jitter(
    aes(color = year),
    width = 0.3
  ) +
  ggtitle("<b style='color:red;font-size:25pt;'>Temperature</b> per <i style='color:blue;'>Season</i> and <i style='color:blue;'>Year</i>") +
  theme(
    plot.title = element_textbox_simple(
      size = 18,
      fill = "grey70",
      hjust = .5,
      padding = margin(10, 10, 10, 10),
      margin = margin(0, 0, 10, 0),
      r = unit(8, "pt")
    )
  )

(labels <- 
  tibble(
    season = factor(c("Spring", "Summer"), levels = levels(chic$season)),
    temp = c(5, 70),
    label = c(
      "<b style='color:red'>An important note!</b><br>Please report <b>R<sup>2</sup></b>!",
      "**Nice Viz!**<br>*Well done my friend.*"
    ),
    angle = c(40, -10),
    fill = c("grey40", "goldenrod"),
    hjust = c(0, .5)
  )
)

ggplot(chic, aes(season, temp)) +
  geom_jitter(
    aes(color = year),
    width = 0.3
  ) +
  geom_richtext(
    data = labels,
    aes(
      label = label,
      fill = fill,
      angle = angle,
      hjust = hjust
    ),
    size = 5,
    color = "white"
  ) +
  scale_fill_identity()

(labels <- 
  tibble(
    label = rep("Some very very long text describing some important finding or just telling a story - I mean, it is *really really long*, and a ridiculuous task to add the linebreaks manually.<br>*If you want*,<br>**you still can<br>do<br>so.**", 2),
    x = c(.4, .8),
    y = c(.8, .3),
    orientation = c("upright", "right-rotated")
  )
)

ggplot(
  labels,
  aes(
    x, y,
    label = label,
    orientation = orientation
  )) +
  geom_textbox(
    size = 4,
    fill = "moccasin",
    width = unit(0.5, "npc")
  ) +
  xlim(0, 1) + ylim(0, 1)

## {cowplot} (once again) -----------------------------------------------
## cowplot can be used to add images as well
library(cowplot)

g <- ggplot(chic, aes(death, o3)) +
  geom_point(alpha = .4)

ggdraw(g) +
  draw_image(
    img, 
    x = .98, 
    y = .98,
    hjust = 1,
    vjust = 1,
    width = .25, 
    height = .25
  )

g <- ggplot(chic, aes(death, o3)) +
  geom_point(alpha = .4) +
  theme(
    panel.background = element_rect(
      fill = "transparent",
      color = "black"
    ),
    plot.background = element_rect(
      fill = "transparent"
    )
  )

cowplot::ggdraw() +
  cowplot::draw_image(
    img,
    scale = .5
  ) +
  cowplot::draw_plot(g)


## WRAP-UP #########################################################
theme_set(theme_minimal(base_size = 17, base_family = "Montserrat"))

(g <- ggplot(mpg, aes(hwy, displ)) +
  stat_smooth(method = "lm",
              color = "black",
              se = FALSE) +
  geom_point(aes(fill = manufacturer != "volkswagen"),
             shape = 23,
             size = 8,
             alpha = .4,
             color = "black",
             stroke = .6) +
  labs(x = "Miles per Gallon on Highways",
       y = "Engine Displacement (liters)") +
  scale_x_continuous(breaks = seq(15, 45, by = 5),
                     limits = c(NA, 46)) +
  scale_y_continuous(expand = c(.01, .01),
                     limits = c(0, 7.5)) +
  scale_fill_manual(values = c("#2058AF", "grey75"),
                    name = NULL,
                    labels = c("Volkswagen", "Other manufacturers")
  ))

library(ggtext)

(g <- g +
  labs(title = '<i>&nbsp;"New Beetle"&nbsp;</i> and <i>&nbsp;"Jetta"&nbsp;</i> by <b style="color:#2058AF;">Volkswagen</b> have the worst car efficiency',
       subtitle = "Linear regression of engine displacement versus highway miles per gallon (MPG) for 38 popular models of cars from 1999 to 2008.",
       caption = "Visualization: Cédric Scherer  •  Data: EPA (www.fueleconomy.gov)") +
  guides(fill = guide_legend(nrow = 2, override.aes = list(size = 7, alpha = .7))) +
  theme(plot.title.position = "plot",
        plot.title = element_markdown(face = "bold", size = 24, margin = margin(5, 0, 5, 0)),
        plot.subtitle = element_text(size = 16, color = "grey40", margin = margin(5, 0, 35, 0)),
        plot.caption = element_text(color = "grey40", size = 11, margin = margin(20, 0, 0, 0)),
        plot.margin = margin(30, 40, 30, 40),
        plot.background = element_rect(color = "black", size = 1.2),
        panel.grid.major = element_line(color = "grey93"),
        panel.grid.minor = element_blank(),
        legend.position = c(.89, .63),
        legend.text = element_text(size = 13, margin = margin(9, 5, 9, 5)),
        axis.text = element_text(family = "Roboto Mono", size = 14),
        axis.title.x = element_text(margin = margin(t = 12)),
        axis.title.y = element_text(margin = margin(r = 12))))

logo <- magick::image_read("https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Volkswagen_Logo_till_1995.svg/2048px-Volkswagen_Logo_till_1995.svg.png")
img <- grid::rasterGrob(logo, interpolate = TRUE)

g +
  ggrepel::geom_text_repel(
    data = filter(mpg, hwy > 40),
    aes(hwy, displ, group = model,
        label = glue::glue("{str_to_title(model)}\n{trans}")),
    nudge_x = .15, nudge_y = 1,
    box.padding = .5, point.padding = .9,
    lineheight = 1, fontface = "bold",
    color = "grey40", segment.color = "#2058AF"
  )  +
  annotation_custom(
    img,
    xmin = 40.2, xmax = 44.8,
    ymin = 5.5, ymax = 7.5
  )
