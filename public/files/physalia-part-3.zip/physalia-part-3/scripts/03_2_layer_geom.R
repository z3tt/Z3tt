########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 1–5 2021  #
########################################################################


#### THE STRUCTURE OF GGPLOT2 (continued) ##############################
#-----------------------------------------------------------------------

## Geometric Layers: geom_*() ------------------------------------------

## geom_*() are geometrical layers directly applied to the data:

## Our scatter plot as a line plot:
ggplot(chic, aes(date, temp)) +
  geom_line()

## ... or as a bar plot:
ggplot(chic, aes(date, temp)) +
  geom_col()

## ... or a box and whiskers plot:
ggplot(chic, aes(date, temp)) +
  geom_boxplot()

## We need to specify the variable as categorial, not as continuous:
ggplot(chic, aes(as.factor(date), temp))
  geom_boxplot() 

class(chic$year)

class(chic$season)
    
ggplot(chic, aes(year, temp)) +
    geom_boxplot() 

ggplot(chic, aes(season, temp)) +
  geom_boxplot() 

## Other layers can be added to an existing plot
## For example, we add a line and a rug representation:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  geom_line()
  geom_rug(sides = "r")
  
## Add labels

## You can change the axes titles by adding `xlab()` and `ylab()` 
## to your ggplot:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  xlab("Day of the Year") +
  ylab("Temperature (°F)")

## ... and a title by adding `ggtitle()`:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  xlab("Day of the Year") + 
  ylab("Temperature (°F)") +
  ggtitle("Seasonal Change of Temperatures in Chicago")

## Using `labs()` you can also change all and more in one go:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  labs( #<<
    x = "Day of the Year",  
    y = "Temperature (°F)", 
    title = "Seasonal Change of Temperatures in Chicago",
    subtitle = "Daily temperatures (°F) in the city of Chicago, IL,\nmeasured between 1997 and 2001",
    caption = "Data: National Morbidity and Mortality Air Pollution Study (NMMAPS)",
    tag = " 1"
  )

## ggplots as objects
g <- ggplot(chic, aes(date, temp)) +
  geom_point()

g + 
  geom_line() +
  geom_rug(sides = "r")

## Save ggplots
# name the plot yiou want to save explicitly
ggsave(filename = "my_first_ggplot.pdf", plot = g, width = 10, height = 7, device = cairo_pdf)
ggsave(filename = "my_first_ggplot.png", plot = g, width = 10, height = 7, dpi = 300)

# ggsave always uses the last ggplot object implicitly
ggsave(filename = "my_first_ggplot.pdf", width = 10, height = 7, device = cairo_pdf)
ggsave(filename = "my_first_ggplot.png", width = 10, height = 7, dpi = 300)


#!!! Import the data on password strength from Information is Beautiful 
##   directly from GitHub
##   (https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/passwords.csv)

#!! Have a look at the raw data (both in the browser and R)

#!! Investigate the data set via summary functions.

#!! Create two plots with geom's of your choice to answer the following:
#    * Which password category is ranked the lowest and which the highest?
#    * Is there a password category that is more common than others?
