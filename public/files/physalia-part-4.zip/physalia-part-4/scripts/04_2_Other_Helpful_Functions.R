########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 1–5 2021  #
########################################################################

#### OTHER HELPFUL FUNCTIONS FROM DPLYR AND THE TIDYVERSE ##############
#-----------------------------------------------------------------------


## slice(): Extract rows by ordinal position
## distinct() and n_distinct(): Find and count unique values
## sample_n() and sample_frac(): Select rows randomly
## top_n() and top_frac(): Pick top or bottom values by variable
## count() and top_frac(): Count number of observations
## complete(): Create all possible combinations of two variables
## *_join(): Merge two tables
## pivot_longer() and pivot_wider(): Turn wide data into long and vice versa
## fct_*() from the `forcats` package: Change factor levels dynamically
## str_*() from the `stringr` package: Manipulate character strings
## glue() from the `glue` package: Combine strings


## slice() allows you to filter rows based on their row value - 
slice(mpg, 100:120)

mpg %>% group_by(manufacturer) %>% slice(1)


## distinct() allows you to retain only unique values 
## (as the base function `unique()` does):
distinct(mpg, manufacturer)

distinct(mpg, hwy)


## n_distinct() allows you to calculate the number of unique values 
## (as the ombination of the base functions `length(unique())` does):
n_distinct(mpg$model)


## sample_n() allows you to create random subsets based on a number of rows:
sample_n(mpg, 5)

mpg %>% group_by(year, manufacturer) %>% sample_n(1)


## sample_frac()`allows you to create random subsets based on a fraction:
sample_frac(mpg, .05)


## top_n() allows you to filter the top or bottom values, 
## ranked by a variable:
top_n(mpg, 5, hwy)

top_n(mpg, 5, -hwy)

mpg %>% group_by(manufacturer) %>% top_n(1, hwy)


## top_frac() allows you to filter the top or bottom values, 
## ranked by a variable:

top_frac(mpg, .01, displ)


## count() calculates the sample size of your data as summary statistic:
count(mpg)

## is the same as:
summarize(mpg, n = n())

mpg %>% group_by(manufacturer) %>% count()

mpg %>% group_by(manufacturer) %>% count(sort = TRUE)

## tally() does basically the same as `count()`:
tally(mpg)


## add_count() adds the sample size of your data as additional column:
add_count(mpg2)

## is the same as:
summarize(mpg2, n = n())


## complete() turns missing values into explicit missing values:
mpg3 <- mpg %>% group_by(manufacturer, class) %>% count() %>% ungroup()
complete(mpg3, manufacturer, nesting(class))

mpg3 <- mpg %>% group_by(manufacturer, class) %>% count() %>% ungroup()
complete(mpg3, manufacturer, nesting(class), fill = list(n = 0))


## Several `*_join()` functions let you merge two data tables:
band_members
band_instruments

left_join(band_members, band_instruments)

right_join(band_members, band_instruments)

inner_join(band_members, band_instruments)

full_join(band_members, band_instruments)

full_join(band_members, band_instruments, by = "name")


band_instruments2

full_join(band_members, band_instruments2, by = c("name" = "artist"))


## pivot_wider() and `pivot_longer)= from the `tidyr` package

## pivot_wider() let's you turn a long data frame into a wide one:
(mpg_wide <-
  mpg %>% 
  group_by(manufacturer, model, trans, cyl, year) %>% 
  summarize(cty = mean(cty, na.rm = TRUE)) %>% 
  pivot_wider(
    id_cols = c(manufacturer, model, trans, cyl),
    names_from = year,
    values_from = cty,
    names_prefix = "cty_"
  ))

##pivot_longer() let's you turn a wide data frame into a long one:
mpg_wide %>% 
  pivot_longer(
    cols = starts_with("cty_"),
    names_to = "year",
    values_to = "cty",
    names_prefix = "cty_"
  )


## fct_*() functions from the `forcats` Package
  
## The `forcats` package provides helpers for reordering factor levels:
mpg_avg <- 
  mpg %>% 
  mutate(
    m_fct = factor(manufacturer)
  ) %>% 
  filter(!is.na(cty)) %>% 
  group_by(m_fct) %>% 
  summarize(avg = mean(cty)) %>% 
  ungroup()

mpg_avg %>% 
  ggplot(aes(avg, m_fct)) +
  geom_segment(
    aes(xend = 0, yend = m_fct),
    size = 1.5
  ) +
  geom_point(size = 4)

mpg_avg %>% 
  mutate( #<<
    m_fct = fct_reorder(m_fct, avg) #<<
  ) %>%  #<<
  ggplot(aes(avg, m_fct)) +
  geom_segment(
    aes(xend = 0, yend = m_fct),
    size = 1.5
  ) +
  geom_point(size = 4)

mpg_avg %>% 
  mutate(m_fct = fct_lump( #<<
    m_fct, #<<
    n = 8, #<<
    w = avg #<<
  )) %>% #<<
  group_by(m_fct) %>% 
  summarize(avg = mean(avg)) %>% 
  ungroup() %>% 
  mutate(m_fct = fct_reorder(m_fct, avg)) %>% 
  ggplot(aes(avg, m_fct)) +
  geom_segment(
    aes(xend = 0, yend = m_fct),
    size = 1.5
  ) +
  geom_point(size = 4)

    mpg_avg %>% 
      mutate(m_fct = fct_lump( #<<
        m_fct, #<<
        n = 8, #<<
        w = avg #<<
      )) %>% #<<
      group_by(m_fct) %>%  #<<
      summarize(avg = mean(avg)) %>% #<<
      ungroup() %>%  #<<
      mutate(m_fct = fct_reorder(m_fct, avg)) %>%  #<<
      ggplot(aes(avg, m_fct)) +
      geom_segment(
        aes(xend = 0, yend = m_fct),
        size = 1.5
      ) +
      geom_point(size = 4)

mpg_avg %>% 
  mutate(m_fct = fct_lump(
    m_fct,
    n = 8,
    w = avg
  )) %>% 
  group_by(m_fct) %>% 
  summarize(avg = mean(avg)) %>% 
  ungroup() %>% 
  mutate(m_fct = fct_reorder(m_fct, avg)) %>% 
  ggplot(aes(avg, m_fct,
             color = m_fct != "Other")) + #<<
  geom_segment(
    aes(xend = 0, yend = m_fct),
    size = 1.5
  ) +

  
## str_*() functions from the `stringr` Package
  
## Functions from the `stringr` package operate on character strings:
(manufacturers <- mpg %>% distinct(manufacturer) %>% pull(manufacturer))

str_sub(manufacturers, 1, 3)

str_replace(manufacturers, "[aeiou]", "X")


## glue() from the `glue` package

## glue()allows you to glue strings together.
mpg %>% 
  select(manufacturer, model, year, trans) %>% 
  mutate(
    text = glue::glue("The model {manufacturer} {model} with {trans} as transission was build in {year}.")
  )

mpg %>% 
  select(manufacturer, model, year, trans) %>% 
  mutate(text = 
           glue::glue("The {str_to_title(manufacturer)} {str_to_title(model)} with {trans} as transission was build in {year}.")
  ) 
