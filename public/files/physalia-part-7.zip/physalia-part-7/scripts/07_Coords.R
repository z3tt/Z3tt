########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 1–5 2021  #
########################################################################

#### SCALES + COORDINATE SYSTEMS #######################################
#-----------------------------------------------------------------------

## Coordinate systems produce a 2d position based on the relative geo-
## metric arrangement of the two position aesthetics (usually x and y).

## The meaning of the position aesthetics depends on the coordinate 
## system used: 

##  * Linear coordinate systems that preserve the shape of geoms.
##      - coord_cartesian() and coord_fixed(): 
##        the default with two fixed perpendicular oriented axes
##      - coord_flip():
##        a Cartesian coordinate system with flipped axes
##      - coord_fixed():
##        a Cartesian coordinate system with a fixed aspect ratio

##  * Non-linear coordinate systems that likely change the shapes.
##      - coord_map() and coord_sf():
##        map projections
##      - coord_polar():
##        a polar coordinate system
##      - coord_trans():
##        arbitrary transformations to x and y positions


## Preparation ---------------------------------------------------------

library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/chicago-nmmaps.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)



## Linear coordinate systems ###########################################

## coord_cartesian() ---------------------------------------------------

## coord_*() functions allow you to zoom in a plot:

ggplot(chic, aes(date, temp)) +
  geom_line() +
  coord_cartesian( 
    ylim = c(50, 70) 
  ) 

ggplot(chic, aes(date, temp)) +
  geom_line() +
  coord_cartesian( 
    ylim = c(50, 70) 
  ) 

## Note that data points outside the plot area are not removed!

## In case you want to remove those data points, use 
## scale_y_continuous(limits = c(min, max)):
ggplot(chic, aes(date, temp)) +
  geom_line() +
  scale_y_continuous(limits = c(50, 70)) 

ggplot(chic, aes(season, temp)) +
  geom_boxplot()  +
  coord_cartesian(ylim = c(50, 70)) 

ggplot(chic, aes(season, temp)) +
  geom_boxplot()  +
  scale_y_continuous(limits = c(50, 70)) 

## coord_*() is also used to prevent "clipping" of points and 
## the correct alignment of axis ticks:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  coord_cartesian(
    ylim = c(0, 75) 
  )

ggplot(chic, aes(date, temp)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0) 
  ) + 
  coord_cartesian(ylim = c(0, 75))

ggplot(chic, aes(date, temp)) +
  geom_point() +
  coord_cartesian(
    ylim = c(0, 75),
    clip = "off" 
  )

ggplot(chic, aes(date, temp)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0)
  ) + 
  coord_cartesian(
    ylim = c(0, 75), 
    clip = "off"
  )


## coord_fixed() ------------------------------------------------------

## coord_fixed() forces a specified ratio as physical representation of 
## units on the axes:
ggplot(chic, aes(temp, o3)) +
  geom_point() +
  coord_fixed() 

ggplot(chic, aes(temp, o3)) +
  geom_point() +
  coord_fixed() +
  scale_x_continuous( 
    breaks = seq(0, 100, by = 20) 
  ) 

ggplot(chic, aes(temp, o3)) +
  geom_point() +
  coord_fixed(
    ratio = 3 
  ) +
  scale_x_continuous(
    breaks = seq(0, 100, by = 20)
  )


## coord_flip() -------------------------------------------------------

chic_month <-
  chic %>% 
  mutate(
    month = lubridate::month(
      date,
      label = TRUE
    )
  ) %>% 
  group_by(month) %>% 
  summarize(
    temp = mean(temp),
    n = n()
  ) %>% 
  ungroup()

## coord_flip() allows you to flip a Cartesian coordinate system:
ggplot(chic_month, aes(month, temp)) +
  geom_col() +
  coord_cartesian()

ggplot(chic_month, aes(month, temp)) +
  geom_col() +
  coord_flip() 

ggplot(
  chic_month, 
  aes(
    fct_rev(month),  
    temp
  )) +
  geom_col() +
  coord_flip()

ggplot(
  chic_month, 
  aes(
    fct_reorder(month, temp),  
    temp
  )) +
  geom_col() +
  coord_flip()


# Non-linear coordinate systems ########################################

## coord_polar() -------------------------------------------------------
  
## You can easily transform a rectangular coordinate system into a polar 
## one with coord_polar():

ggplot(chic, aes(season, temp)) +
    stat_summary(fun.y = mean,
                 geom = "col") +
    coord_cartesian()

ggplot(chic, aes(season, temp)) +
  stat_summary(fun.y = mean,
               geom = "col") +
  coord_polar() 

## This way, we can create pie charts:
ggplot(
  chic_month, 
  aes(
    factor(1), n, 
    fill = month
  )) +
  geom_col() +
  coord_polar() + 
  scale_x_discrete(
    name = NULL, 
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    name = NULL, 
    expand = c(0, 0)
  )

ggplot(
  chic_month, 
  aes(
    factor(1), n, 
    fill = month
  )) +
  geom_col() +
  coord_polar(theta = "y") + 
  scale_x_discrete(
    name = NULL, 
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    name = NULL, 
    expand = c(0, 0)
  )

## ... and doughnut charts:
chic_month %>% 
  mutate( 
    perc = n / n(), 
    ymax = cumsum(perc), 
    ymin = c(0, head(ymax, n = -1)) 
  ) %>%  
  ggplot(
    aes(
      xmin = 4, xmax = 6, 
      ymin = ymin, ymax = ymax, 
      fill = month
    )) +
  geom_rect() + 
  coord_polar(theta = "y") + 
  scale_x_discrete(
    name = NULL, 
    limits = c(2, 4)
  )

## Our doughnut charts looks like this in a Cartesian coordinate system:

chic_month %>% 
  mutate( 
    perc = n / n(), 
    ymax = cumsum(perc), 
    ymin = c(0, head(ymax, n = -1)) 
  ) %>%  
  ggplot(
    aes(
      xmin = 4, xmax = 6,
      ymin = ymin, ymax = ymax, 
      fill = month
    )) +
  geom_rect() + 
  #coord_polar(theta = "y") + 
  scale_x_discrete(
    name = NULL, 
    limits = c(2, 4)
  ) 


## coord_map() and coord_sf() ------------------------------------------

## Maps often come as polygons:
world <- map_data("world")
head(world)

g_world <- 
  ggplot(
    world,
    aes(
      long, lat, 
      group = group
    )) +
  geom_polygon( 
    fill = "tan", 
    color = "grey20" 
  ) 

g_world

## We can fix that by using `coord_fixed()`:
g_world +
  coord_fixed()

## Since maps are displaying spherical data, we should project the data 
## by using `coord_map()`:
g_world +
  coord_map()

g_world +
  coord_map(
    xlim = c(-20, 45), 
    ylim = c(20, 58) 
  )

g_world +
  coord_map("mollweide")

g_world +
  coord_map("ortho")


## Simple Features (Access)
  
## Simple features or simple features access refers to a formal standard 
## (ISO 19125-1:2004) that describes how objects in the real world can be 
## represented in computers, with emphasis on the spatial geometry.

## {sf} is an R package that provides simple features access for R.

#install.packages("sf")
library(sf)

#install.packages("rnaturalearth")
library(rnaturalearth)

## download simple feature objects with the {rnaturalearth} package_
sf_world <- ne_countries(returnclass = "sf")
sf_airports <- ne_download(scale = "large", category = "cultural", type = "airports", returnclass = "sf")

tibble::glimpse(sf_world)

## {ggplot2} comes with a set of `geom`, `stat`, and `coord` are used to 
## visualize sf objects:

ggplot(sf_world) +
  geom_sf()

ggplot(sf_world) +
  geom_sf() +
  geom_sf(data = sf_airports)

ggplot(sf_world) +
  geom_sf(color = "forestgreen", alpha = .4) +
  geom_sf(data = sf_airports, color = "purple", alpha = .4)

## Create your onw sf objects:
sf_bln <- sf::st_sfc(sf::st_point(c(13.4050, 52.5200)), crs = sf::st_crs(sf_world))

sf_bln

ggplot(sf_world) +
  geom_sf(color = NA) +
  geom_sf(data = sf_bln, shape = 21, color = "firebrick", fill = NA, size = 5, stroke = 2)

ggplot(sf_world) +
  geom_sf(color = "forestgreen", fill = "forestgreen", alpha = .4)

ggplot(sf_world) +
  geom_sf(aes(fill = economy))

ggplot(sf_world) +
  geom_sf(aes(fill = economy), color = "white", size = .2)

## One can change the projection again within the `coord_` call:
ggplot(sf_world) +
  geom_sf(aes(fill = economy), color = "white", size = .2) +
  coord_sf(crs = "+proj=moll")

ggplot(sf_world) +
  geom_sf(aes(fill = economy), color = "white", size = .2) +
  coord_sf(crs = "+proj=laea +x_0=0 +y_0=0 +lon_0=0 +lat_0=0")

ggplot(sf_world) +
  geom_sf(aes(fill = economy), color = "white", size = .2) +
  coord_sf(crs = "+proj=laea +x_0=0 +y_0=0 +lon_0=-30 +lat_0=-25")

ggplot(sf_world) +
  geom_sf(aes(fill = economy), color = "white", size = .2) +
  coord_sf(crs = "+proj=laea +x_0=0 +y_0=0 +lon_0=-70 +lat_0=0")

#!! For a data set of your choice
#!!   - create a scatter plot with a linear fitting and test how coord_fixed() 
#!!     changes the perception of the relationship
#!!   - create a pie or doughnut chart for one variable in that data set

#!! For your home country
#!!   - Download simple feature data with {rnaturalearth} and plot it/them.
#!!   - Change the projection with coord_sf and observe how the spatial 
#!!     mapping changes.
#!!   - Add a locator pin for your home city.

