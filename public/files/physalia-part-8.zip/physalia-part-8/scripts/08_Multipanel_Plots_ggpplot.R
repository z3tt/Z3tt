########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 1–5 2021  #
########################################################################

#### MULTIPANEL PLOTS ##################################################
#-----------------------------------------------------------------------



## Preparation ---------------------------------------------------------

library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/chicago-nmmaps.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)


## Facets ##############################################################

## Create small multiples based on one or two variables.


## facet_wrap() --------------------------------------------------------
## splits the data into small multiples based on one grouping variable:

ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  )

ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(~ season) 

ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(color = year),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_wrap(~ year) 

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(~ year) 
    
ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(
    ~ year, 
    scales = "free" 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(
    ~ year, 
    scales = "free_x" 
  )

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(
    ~ year, 
    nrow = 4 
  )
    

ggplot(chic, aes(date, temp)) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  scale_color_brewer(
    palette = "Set1"
  ) +
  facet_wrap(
    ~ year, 
    ncol = 3 
  )


## facet_grid() --------------------------------------------------------
## spans a grid of each combination of two grouping variables:

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(season ~ year) 
    
ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(year ~ season) 
    
ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(
    year ~ season,
    scales = "free" 
  )

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  facet_grid(
    year ~ season,
    scales = "free",
    space = "free"
  )
    
## facet_rep_grid()` from the lemon package allows you to draw 
## axis lines and ticks for all facets:
  
install.packages("lemon")
  
ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = year)) +
  scale_color_brewer(
    palette = "Dark2"
  ) +
  lemon::facet_rep_grid( 
    year ~ season
  )


## The `patchwork` package #############################################

## Build up your multipanel plot sequentially:

install.packages("patchwork")
library(patchwork)

## first plot  
(time <- ggplot(chic, aes(date, temp)) +
        geom_point(aes(color = season)) +
        scale_color_brewer(palette = "Set1", 
                           guide = FALSE))
    
## second plot
(box <- ggplot(chic, aes(temp, season)) +
      geom_boxplot(aes(color = season)) +
      scale_color_brewer(palette = "Set1", 
                         guide = FALSE))

time + box

time / box

time + box + plot_layout(widths = c(2, 1))

time + plot_spacer() + box + plot_layout(widths = c(2, .5, 1))

## third plot
scatter <- 
  ggplot(
    chic, 
    aes(temp, o3)
  ) +
  geom_point(aes(color = season)) +
  scale_color_brewer(
    palette = "Set1", 
    guide = FALSE
  )
    
time / (box + scatter) + plot_layout(heights = c(1, 2))
    
## third plot wih legend:
scatter <- 
  ggplot(
    chic, 
    aes(temp, o3)
  ) +
  geom_point(aes(color = season)) +
  scale_color_brewer(
    palette = "Set1"#, 
    #guide = FALSE 
  ) + guides(color = guide_legend(override.aes = list(alpha = .8)))

time / (box + scatter) + plot_layout(heights = c(1, 2))
 
time / (box + scatter) + 
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  )
    
time / (box + scatter) + 
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation( 
    title = "Temperature & Ozone in Chicago, IL" 
  ) 
    
time / (box + scatter) + 
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A" 
  )
    

## The `cowplot` package #############################################

## Arrange plots into a grid and label them or add inset plots:
  
install.packages("patchwork")
library(patchwork)

## The `cowplot` package provides the function plot_grid() to arrange 
#  plots into a grid and label them:
plot_grid(box, scatter, labels = c('A', 'B'), label_size = 12)

ggdraw(scatter) + draw_plot(box, .06, .62, .25, .35)


#!! Create the following two facets (exercise-7.png)

#!! Create three plots with legends for shape amd fill. Combine them with `patchwork` or `cowplot`.
