########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 1–5 2021  #
########################################################################

#### VISUAL THEMES #####################################################
#-----------------------------------------------------------------------

## * Themes control the display of all non-data elements of the plot
##     - titles
##     - labels
##     - fonts
##     - background + borders
##     - gridlines
##     - legends
##
## * Themes can be modified for each plot by calling theme() and 
##   element_ functions
##
## * Themes can be used to give plots a consistent customized look by 
##   defining a custom theme using theme_update() or theme_set()


## Preparation ---------------------------------------------------------

library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/chicago-nmmaps.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

## Build-In Themes ------------------------------------------------------
## We have already seen several build-in theme examples in the first lecture:
ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_grey() +
  ggtitle("theme_grey()  or  theme_gray()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_classic() +
  ggtitle("theme_classic()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_bw() +
  ggtitle("theme_bw()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_light() +
  ggtitle("theme_light()")

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_minimal() +
  ggtitle("theme_minimal()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_dark() +
  ggtitle("theme_dark()") 

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_linedraw() +
  ggtitle("theme_linedraw()")

ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)) +
  theme_void() +
  ggtitle("theme_void()") 

## theme_set() ---------------------------------------------------------
## You can set themes for each plot or globally for the current session and 
## thus all following plots with theme_set():
theme_set(theme_light())

(g <- ggplot(chic, aes(temp, o3)) +
  geom_point(aes(color = season)))

ggplot(chic, aes(date, temp)) +
  geom_line(color = "grey60") +
  geom_point(aes(color = o3)) +
  scale_color_distiller(palette = 8)

## theme_set() invisibly returns the previous theme so you can 
## easily save it, then later restore it:
old_theme <- theme_set(theme_dark())

g +
  scale_color_brewer(palette = 8)

ggplot(chic, aes(date, temp)) +
  geom_point(aes(color = o3)) +
  geom_line(color = "grey60") +
  scale_color_distiller(palette = 8)

theme_set(old_theme)

g +
  scale_color_brewer(palette = 8)

ggplot(chic, aes(date, temp)) +
  geom_point(aes(color = o3)) +
  geom_line(color = "grey60") +
  scale_color_distiller(palette = 8)

theme_set(theme_light(base_size = 32))

g

theme_set(theme_light(base_size = 16))

g

## Themes have a base_size argument which is a simple way to increase or 
## decrease the font size:
g +
  theme_bw(base_size = 5)

g +
  theme_dark(base_size = 50)


## You can also set the font of the theme via base_family:
theme_set(theme_light(
    base_size = 20,
    base_family = "Roboto Mono"
  ))
g

theme_set(theme_light(
    base_size = 20,
    base_family = "Bangers"
  ))
g

theme_set(theme_light(base_size = 16, base_family = "Open Sans"))


## Custom Fonts --------------------------------------------------------

## Fonts that are imported into extrafont can be used with PDF or PostScript 
## output files. On Windows, extrafont will also make system fonts available 
## for bitmap output.

## install.packages("extrafont")
## library(extrafont)

## import your system fonts (only 1 time)
#font_import() press "y"
#loadfonts()

## which fonts are available?
## fonts()


## The 'showtext' package is able to support more font formats and more graphics 
## devices, and avoids using external software such as Ghostscript. 
## showtext makes it even easier to use various types of fonts (TrueType, 
## OpenType, Type 1, web fonts, etc.) in R graphs.

## install.packages("showtext")
## library(showtext)

## Loading Google fonts (https://fonts.google.com/) installed on your system
## font_add_google("Roboto", "Roboto")
## font_add_google("Roboto Mono", "Roboto Mono")


## The 'systemfonts' package provides bindings to the native libraries on 
## Windows, macOS and Linux for finding font files that can then be used 
## further by e.g. graphic devices. 

## install.packages("systemfonts")
library(systemfonts)

system_fonts() %>% 
  filter(str_detect(family, "Roboto")) %>% 
  pull(name)

## Back to the theme_*() functions:
## ... and change the size of geometric elements via `base_line_size` and `base_rect_size`:
g +
  theme_bw(
    base_size = 20,
    base_line_size = 2 
  )

g +
  theme_bw(
    base_size = 20,
    base_line_size = 2,
    base_rect_size = 5 
  )

## Theme Elements ------------------------------------------------------
## There are many theme elements you can customize. 
## You can either group them by their type or by their category:

## element types
##  - `text`: all labels, axis text, legend title and text
##  - `line`: axis lines, ticks, grid lines
##  - `rect`: plot area, panel area, legend and legend keys, facets

## element categories
##  - `axis.*`: titles, text, ticks, lines
##  - `legend.*`: background, margin, spacing, keys, text, title, position, direction, box
##  - `panel.*`: background, border, margin, spacing, grid (major and minor)
##  - `plot.*`: background, title, subtitle, caption, tag, margin
##  - `strip.*`: background, placement, text

theme_grey

g +
  ggtitle("My New\nTitle") +
  theme(
    plot.title = element_text(
      family = "Roboto",
      face = "bold",
      size = 18,
      color = "red",
      lineheight = .7,
      angle = 180,
      hjust = .5,
      vjust = .0,
      margin = margin(
        10,
        0,
        30,
        0
      )
    )
  )

g +
  theme(
    panel.grid = element_line(
      color = "red",
      size = 10,
      linetype = "dashed",
      lineend = "square", ## round, butt
      arrow = arrow(
        angle = 30,
        length = unit(0.25, "inches")
      )
    )
  )

g +
  theme(
    plot.background = element_rect(
      color = "orange",
      fill = "black",
      size = 2,
      linetype = "dotted"
    )
  )

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = "top",
    plot.title.position = "plot"
  )

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = "none",
    plot.title.position = "panel"
  )

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = c(.2, .8),
    plot.title.position = "plot"
  )

?grid::unit
unit(50, "pt")
unit(10, "mm")
unit(2.5, "lines")
unit(.15, "npc") ## Normalised Parent Coordinates

g +
  theme(
    axis.ticks.length =
      unit(2.5, "lines"),
    legend.key.size =
      unit(.15, "npc")
  )


## You can remove elements via element_blank():
g +
  theme(
    axis.ticks.x = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.y = element_blank(),
    legend.title = element_blank()
  )

g +
  labs(
    title = "A very short title"
  ) +
  theme_minimal() +
  theme(
    plot.title =
      element_text(
        family = "Staatliches"
      ),
    axis.text =
      element_text(
        family = "Roboto Mono"
      )
  )

theme_set(theme_bw(base_size = 20))

g

theme_update(
  panel.grid.major = element_line(color = "red")
)

g

#!! Have a closer look at the code of theme_grey and of the one you have 
#!! chosen in lecture 3. What's the difference? 

#!! Create a plot and change the theme to be as ugly as possible!
  
#!! If you like, build your own theme by editing theme_grey or updating one 
#!! of the others. You could also search for other themes provided by 
#!! extension packages.
