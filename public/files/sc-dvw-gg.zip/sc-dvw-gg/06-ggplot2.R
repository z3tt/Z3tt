#------------------------------------------------------------------------------#
#                                                                              #
#                     Communicating Insights with Engaging                     # 
#                       Data Visualizations & Dashboards                       #
#                                                                              #
#                       The Layered Grammar of Graphics                        #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                          Supercell // February 2024                          #
#                                                                              #
#------------------------------------------------------------------------------#


pkgs <- c(
  "ggplot2", "readr", "dplyr", "tibble", "tidyr", "forcats", "stringr", 
  "lubridate", "scales", "ragg", "systemfonts", "grDevices", "ggforce", 
  "ggtext", "concavemen", "remotes"
)

install.packages(setdiff(pkgs, rownames(installed.packages())))

remotes::install_github("AllanCameron/geomtextpath")



## -----------------------------------------------------------------------------
library(ggplot2)


## -----------------------------------------------------------------------------
bikes <- readr::read_csv(
  "https://cedricscherer.com/data/london-bikes.csv",
  col_types = "Dcfffilllddddc"
)


## -----------------------------------------------------------------------------
## scatter plot of plot bikes$n versus bikes$temp
ggplot(bikes, aes(temp, n)) +
  geom_point(size = 2.2)


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  ## colored, semi-transparent points
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  ) +
  ## add a linear fitting for each time of the day
  geom_smooth(
    aes(group = day_night),
    method = "lm", color = "black"
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm", color = "black"
  ) +
  ## create small multiples of time of day versus workday
  facet_grid(day_night ~ is_workday)


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm", color = "black"
  ) +
  ## create free-ranging, proportionally sized small multiples
  facet_grid(
    day_night ~ year,
    scales = "free_y", space = "free_y"
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm", color = "black"
  ) +
  facet_grid(
    day_night ~ year,
    scales = "free_y", space = "free_y"
  ) +
  ## add labels + titles
  labs(
    x = "Temperature", y = NULL,
    caption = "Data: TfL (Transport for London), Jan 2015 — Dec 2016",
    title = "In the summer of 2015 TfL bike shares skyrocket due to the tube network strikes"
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm", color = "black"
  ) +
  facet_grid(
    day_night ~ year,
    scales = "free_y", space = "free_y"
  ) +
  ## add custom colors + legend styling
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), name = "Season:",
    guide = guide_legend(override.aes = list(size = 5))
  ) +
  labs(
    x = "Temperature", y = NULL,
    caption = "Data: TfL (Transport for London), Jan 2015 — Dec 2016",
    title = "In the summer of 2015 TfL bike shares skyrocket due to the tube network strikes"
  ) +
  ## use different theme and typeface
  theme_light(base_size = 18, base_family = "Spline Sans")


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  ## format seasons
  geom_point(
    aes(color = forcats::fct_relabel(season, stringr::str_to_title)),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm", color = "black"
  ) +
  ## format facet strip text
  facet_grid(
    day_night ~ year,
    scales = "free_y", space = "free_y",
    labeller = labeller(day_night = stringr::str_to_title)
  ) +
  ## customize x axis
  scale_x_continuous(
    expand = c(.02, .02),
    breaks = seq(0, 30, by = 5), labels = function(x) paste0(x, "°C")
  ) +
  ## customize y axis
  scale_y_continuous(
    expand = c(.1, .1), limits = c(0, NA),
    breaks = 0:5*10000, labels = scales::comma_format()
  ) +
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), name = NULL,
    guide = guide_legend(override.aes = list(size = 5))
  ) +
  labs(
    x = "Temperature", y = NULL,
    caption = "Data: TfL (Transport for London), Jan 2015 — Dec 2016",
    title = "In the summer of 2015 TfL bike shares skyrocket due to the tube network strikes"
  ) +
  theme_light(
    base_size = 18, base_family = "Spline Sans"
  ) +
  ## theme adjustments
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.title = element_text(face = "bold"),
    strip.text = element_text(face = "bold"),
    legend.position = "top"
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  geom_point(
    aes(color = forcats::fct_relabel(season, stringr::str_to_title)),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night), method = "lm", color = "black"
  ) +
  facet_grid(
    day_night ~ year,
    scales = "free_y", space = "free_y",
    labeller = labeller(day_night = stringr::str_to_title)
  ) +
  scale_x_continuous(
    expand = c(.02, .02),
    breaks = seq(0, 30, by = 5), labels = function(x) paste0(x, "°C")
  ) +
  scale_y_continuous(
    expand = c(.1, .1), limits = c(0, NA),
    breaks = 0:5*10000, labels = scales::comma_format()
  ) +
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), name = NULL,
    guide = guide_legend(override.aes = list(size = 5))
  ) +
  labs(
    x = "Temperature", y = NULL,
    caption = "Data: TfL (Transport for London), Jan 2015 — Dec 2016",
    title = "In the summer of 2015 TfL bike shares skyrocket due to the tube network strikes"
  ) +
  theme_light(
    base_size = 18, base_family = "Familjen Grotesk"
  ) +
  ## more theme adjustments
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.title = element_text(face = "bold", size = rel(1.45)),
    axis.text = element_text(family = "Spline Sans Mono"),
    axis.title.x = element_text(hjust = 0, color = "grey30", margin = margin(t = 12)),
    strip.text = element_text(face = "bold" , size = rel(1.15)),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.spacing = unit(2.5, "lines"),
    legend.position = "top",
    legend.text = element_text(size = rel(1)),
    ## for fitting my slide background
    legend.key = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    legend.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    plot.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8")
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(temp, n)) +
  ## point outline
  geom_point(
    color = "black", fill = "white",
    shape = 21, size = 2.8
  ) +
  ## opaque point background
  geom_point(
    color = "white", size = 2.2
  ) +
  ## colored, semi-transparent points
  geom_point(
    aes(color = forcats::fct_relabel(season, stringr::str_to_title)),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night), method = "lm", color = "black"
  ) +
  facet_grid(
    day_night ~ year,
    scales = "free_y", space = "free_y",
    labeller = labeller(day_night = stringr::str_to_title)
  ) +
  scale_x_continuous(
    expand = c(.02, .02),
    breaks = seq(0, 30, by = 5), labels = function(x) paste0(x, "°C")
  ) +
  scale_y_continuous(
    expand = c(.1, .1), limits = c(0, NA),
    breaks = 0:5*10000, labels = scales::comma_format()
  ) +
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), name = NULL,
    guide = guide_legend(override.aes = list(size = 5))
  ) +
  labs(
    x = "Temperature", y = NULL,
    caption = "Data: TfL (Transport for London), Jan 2015 — Dec 2016",
    title = "In the summer of 2015 TfL bike shares skyrocket due to the tube network strikes"
  ) +
  theme_light(
    base_size = 18, base_family = "Familjen Grotesk"
  ) +
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.title = element_text(face = "bold", size = rel(1.45)),
    axis.text = element_text(family = "Spline Sans Mono"),
    axis.title.x = element_text(hjust = 0, color = "grey30", margin = margin(t = 12)),
    strip.text = element_text(face = "bold" , size = rel(1.15)),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.spacing = unit(2.5, "lines"),
    legend.position = "top",
    legend.text = element_text(size = rel(1)),
    ## for fitting my slide background
    legend.key = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    legend.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    plot.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8")
  )


## -----------------------------------------------------------------------------
g <-
  ggplot(
    bikes,
    aes(x = temp, y = n,
        color = season)
  ) +
  geom_point(
    alpha = .5
  )


## -----------------------------------------------------------------------------
class(g)


## -----------------------------------------------------------------------------
g$data


## -----------------------------------------------------------------------------
g$mapping


## -----------------------------------------------------------------------------

gbuilt <- ggplot_build(g)
names(gbuilt)


## -----------------------------------------------------------------------------
head(gbuilt$data[[1]])


## -----------------------------------------------------------------------------
head(gbuilt$data[[2]])


## -----------------------------------------------------------------------------
theme_set(theme_minimal())

g


## -----------------------------------------------------------------------------
theme_set(theme_minimal(
  base_size = 13,
  base_family = "Asap SemiCondensed"
))

g


## -----------------------------------------------------------------------------
library(systemfonts)

match_font("Asap", bold = TRUE)


## -----------------------------------------------------------------------------
system_fonts()


## -----------------------------------------------------------------------------
library(dplyr)

system_fonts() |>
  filter(stringr::str_detect(family, "Asap")) |>
  select(family) |>
  unique() |> 
  arrange(family)


## -----------------------------------------------------------------------------
g +
  theme_minimal(
    base_family = "Asap Expanded",
    base_size = 13
  )


## -----------------------------------------------------------------------------
theme_update(
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  plot.title.position = "plot",
  legend.position = "top"
)

g


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = temp, y = n)
  ) +
  geom_point(
    aes(color = temp > 20),
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = temp, y = n)
  ) +
  geom_point(
    aes(color = season == "summer"),
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = temp, y = n)
  ) +
  geom_point(
    aes(color = season %in% c("winter", "spring")),
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = temp)) +
  geom_point(stat = "identity") # default

ggplot(bikes, aes(x = date, y = temp)) +
  stat_identity(geom = "point") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = weather_type)) +
  geom_bar(stat = "count") # default

ggplot(bikes, aes(x = weather_type)) +
  stat_count(geom = "bar") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = n)) +
  geom_smooth(stat = "smooth") # default

ggplot(bikes, aes(x = temp, y = n)) +
  stat_smooth(geom = "smooth") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = n)) +
  stat_smooth(geom = "pointrange")

ggplot(bikes, aes(x = temp, y = n)) +
  stat_smooth(geom = "col")


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary() 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = mean_se, # default
    geom = "pointrange" # default
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  geom_boxplot() +
  stat_summary(
    fun = mean,
    geom = "point",
    color = "#28a87d",
    size = 3
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun = mean, 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y) 
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun = mean, 
    fun.max = function(foo) mean(foo) + sd(foo), 
    fun.min = function(foo) mean(foo) - sd(foo)
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1)
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = mean,
    size = 2
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = mean,
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = mean,
    aes(label = after_stat(y))
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = mean,
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = mean,
    aes(label = after_stat(
      sprintf("%2.1f", y)
    )),
    hjust = -.3
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        fill = n)
  ) +
  geom_tile() 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        z = n)
  ) +
  stat_summary_2d() 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        z = n)
  ) +
  stat_summary_2d(
    geom = "tile", 
    fun = "sum", 
    color = "white", 
    linewidth = .7
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = date, y = n,
        color = season)
  ) +
  geom_point() +
  scale_x_date()


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = date, y = n,
        color = season)
  ) +
  geom_point() +
  scale_x_date(
    name = NULL,
    date_breaks = "4 months"
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = date, y = n,
        color = season)
  ) +
  geom_point() +
  scale_x_date(
    name = NULL,
    date_breaks = "20 weeks"
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = date, y = n,
        color = season)
  ) +
  geom_point() +
  scale_x_date(
    name = NULL,
    date_breaks = "6 months",
    date_labels = "%Y/%m/%d"
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = date, y = n,
        color = season)
  ) +
  geom_point() +
  scale_x_date(
    name = NULL,
    date_breaks = "6 months",
    date_labels = "%b '%y"
  )


## -----------------------------------------------------------------------------
bikes |> 
  mutate(
    month = lubridate::month(date, label = TRUE, abbr = FALSE)
  ) |> 
  ggplot(
    aes(x = month, y = temp, color = day_night)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1), 
    position = position_dodge(width = .4)
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(y = weather_type)
  ) +
  geom_bar() 


## -----------------------------------------------------------------------------
library(forcats)

ggplot(
    bikes,
    aes(
      y = fct_infreq(weather_type)
    )
  ) +
  geom_bar()


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(
      y = fct_rev(fct_infreq(weather_type))
    )
  ) +
  geom_bar()


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(
      x = fct_reorder(
        weather_type, -n
      ),
      y = n
    )
  ) +
  geom_boxplot()


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(
      x = fct_reorder(
        stringr::str_wrap(
          weather_type, 8
        ), 
        -n
      ),
      y = n
    )
  ) +
  geom_boxplot()


## -----------------------------------------------------------------------------
ggplot(
    bikes,
    aes(
      x = fct_reorder(
        stringr::str_wrap(
          weather_type, 8
        ), 
        n,
        .fun = max, 
        .desc = TRUE
      ),
      y = n
    )
  ) +
  geom_boxplot()


## -----------------------------------------------------------------------------
ga <- 
  ggplot(bikes, 
         aes(x = temp, y = n)) +
  geom_point(
    aes(color = n > 40000),
    size = 2
  ) +
  scale_color_manual(
    values = c("grey", "firebrick"),
    guide = "none"
  )

ga


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?"
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?",
    color = "firebrick",
    size = 6,
    family = "Asap SemiCondensed",
    fontface = "bold",
    lineheight =  .8
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = c(18, max(bikes$temp)),
    y = c(48000, 1000),
    label = c("What happened here?", "Powered by TfL"),
    color = c("firebrick", "black"),
    size = c(6, 3),
    family = c("Asap SemiCondensed", "Spline Sans Mono"),
    fontface = c("bold", "plain"),
    hjust = c(.5, 1)
  )


## -----------------------------------------------------------------------------
## ggannotate::ggannotate(g)


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "segment",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow()
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed",
      ends = "both"
    )
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .8,
    angle = 130,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed"
    )
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000)
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000),
    color = "black",
    label.family = "Asap SemiCondensed"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    radius = unit(12, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_circle(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
g +
  ggforce::geom_mark_hull(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  group_by(month, day_night) |> 
  summarize(n = sum(n)) |> 
  ggplot(aes(x = month, y = n, 
             color = day_night,
             group = day_night)) +
  geom_line(linewidth = 1) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    name = NULL
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  group_by(month, day_night) |> 
  summarize(n = sum(n)) |> 
  ggplot(aes(x = month, y = n, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    family = "Asap SemiCondensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  )


## -----------------------------------------------------------------------------
bikes |>
  filter(year == "2016") |>
  group_by(month, day_night) |> 
  summarize(n = sum(n)) |> 
  mutate(day_night = if_else(
    day_night == "day", 
    "Day period (6am-6pm)", 
    "Night period (6pm-6am)"
  )) |> 
  ggplot(aes(x = month, y = n, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    hjust = .05,
    family = "Asap SemiCondensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000)
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("**TfL bike sharing trends by _season_**")


## -----------------------------------------------------------------------------
g +
  ggtitle("**TfL bike sharing trends by _season_**") +
  theme(
    plot.title = ggtext::element_markdown()
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("<i style='font-family:times;font-size:30pt;'>TfL</i> bike sharing trends by <b style='color:#28a87d;'>season</b>") +
  theme(
    plot.title = ggtext::element_markdown()
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("<i style='font-family:times;font-size:30pt;'>TfL</i> bike sharing trends by <b style='color:#28a87d;'>season</b>") +
  theme(
    plot.title = 
      ggtext::element_textbox_simple(
        margin = margin(t = 12, b = 12),
        padding = margin(rep(12, 4)),
        fill = "grey90",
        box.colour = "grey30",
        linetype = "13",
        r = unit(9, "pt"),
        halign = .5,
        lineheight = 1
      )
  )


## -----------------------------------------------------------------------------
g +
  ggtext::geom_richtext(
    data = data.frame(
      temp = c(5, 25),
      n = c(40000, 5000),
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> **2**")
    ),
    aes(label = lab),
    color = "black"
  )


## -----------------------------------------------------------------------------
g +
  ggtext::geom_richtext(
    data = data.frame(
      temp = c(5, 25),
      n = c(40000, 5000),
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> **2**"),
      angle = c(35, 310)
    ),
    aes(label = lab,
        angle = angle),
    color = "black"
  )


## -----------------------------------------------------------------------------
g +
  ggtext::geom_textbox(
    data = data.frame(
      temp = 10,
      n = 40000,
      lab = "Lorem ipsum dolor sit amet, **consectetur adipiscing elit**, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud <i style='color:red;'>exercitation</i> ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ),
    aes(label = lab),
    color = "black",
    size = 3,
    halign = .5
  )



################################################################################
## EXERCISES                                                                   #
################################################################################

## Create one of the following visualizations as close as possible:


## Exercise 1 ------------------------------------------------------------------

##  A horizontal bar chart of box offices, highlighting the top movies "Star 
##  Wars VIII" and "Jumanji: Welcome to the Jungle".

movies <- data.frame(
  movie = c("Star Wars: The Last Jedi", "Jumanji: Welcome To The Jungle", 
            "Pitch Perfect 3", "Greatest Showman", "Ferdinand", "Coco"),
  gross_millions = c(66.814, 66.273, 21.676, 20.907, 14.852, 10.083)
)



## Exercise 2 ------------------------------------------------------------------

##  A line chart on where Americans get most of their news from 2001 to 2010, 
##  highlighting the increase of internet as primary news source.

news <- 
  tibble::tribble(
    ~year, ~Television, ~Newspaper, ~Internet, ~Radio,
    2001, 74, 45, 13, 18,
    2002, 82, 42, 14, 21,
    2003, 80, 50, 18, 20, 
    2004, 74, 46, 24, 21, 
    2005, 73, 36, 20, 16, 
    2006, 72, 36, 24, 14, 
    2007, 74, 34, 24, 13, 
    2008, 70, 35, 40, 18, 
    2009, 70, 32, 35, 17, 
    2010, 66, 31, 41, 16
  ) |> 
  tidyr::pivot_longer(
    cols = -c(year), names_to = "media", values_to = "percentage"
  ) |> 
  dplyr::mutate(media = forcats::fct_inorder(media))

title <- "An increasing proportion cite the <b style='color:#d4580a;'>internet</b> as their primary news source."
subtitle <- 'Responses to the question "where do you get most of your news about national and international issues?"'
caption <- 'Data source: Pew Research Center\nFigures sum to more than 100% because respondents could volunteer up to two main sources.'





################################################################################
## APPENDIX                                                                    #
################################################################################

pkgs <- c("camcorder", "here", "purrr", "patchwork")

install.packages(setdiff(pkgs, rownames(installed.packages())))


## -----------------------------------------------------------------------------
# ggsave(filename = "my_plot.png", plot = g)
# ggsave("my_plot.png")
# ggsave("my_plot.png", width = 6, height = 5, dpi = 600)
# ggsave("my_plot.png", width = 6*2.54, height = 5*2.54, unit = "cm", dpi = 600)
# ggsave("my_plot.png", device = agg_png)
# ggsave("my_plot.pdf", device = cairo_pdf)
# ggsave("my_plot.svg")


## -----------------------------------------------------------------------------
# camcorder::gg_record(
#   dir = here::here("temp"),  # path for plot files
#   device = "png",            # device to use
#   width = 10,                # figure width
#   height = 5,                # figure height
#   dpi = 600                  # plot resolution
# )
# 
# g <- ggplot(bikes, aes(x = temp, y = n, color = day_night)) +
#   geom_point(alpha = .3, size = 2) +
#   scale_color_manual(values = c(day = "#FFA200", night = "#757BC7")) +
#   theme_minimal(base_size = 13, base_family = "Asap SemiCondensed") +
#   theme(panel.grid.minor = element_blank())
# 
# g


## ----------------------------------------------------------------------------- 
# camcorder::gg_resize_film(width = 20) # update figure width
# 
# g


## -----------------------------------------------------------------------------
# camcorder::gg_stop_recording()


## -----------------------------------------------------------------------------
system_fonts() |>
  filter(family == "Asap SemiCondensed") |>
  select(name) |>
  arrange(name)


## -----------------------------------------------------------------------------
register_variant(
  name = "Asap SemiCondensed Semibold S1",
  family = "Asap SemiCondensed",
  weight = "semibold",
  features = font_feature(letters = "stylistic")
)


## -----------------------------------------------------------------------------
g + 
  theme_minimal(
    base_family = "Asap SemiCondensed Semibold S1",
    base_size = 13
  )


## -----------------------------------------------------------------------------
register_variant(
  name = "Spline Sans Tabular",
  family = "Spline Sans",
  weight = "normal",
  features = font_feature(numbers = "tabular")
)


## -----------------------------------------------------------------------------
theme_set(theme_minimal(base_size = 14, base_family = "Asap SemiCondensed"))

theme_update(
  panel.grid.minor = element_blank(),
  legend.position = "top"
)


## -----------------------------------------------------------------------------
smooth <- TRUE

ggplot(bikes, aes(x = temp, y = humidity)) +
  { if(smooth) geom_smooth(color = "red") } +
  geom_point(alpha = .5)


## -----------------------------------------------------------------------------
smooth <- FALSE

ggplot(bikes, aes(x = temp, y = humidity)) +
  { if(smooth) geom_smooth(color = "red") } +
  geom_point(alpha = .5)


## -----------------------------------------------------------------------------
draw_scatter <- function(smooth = TRUE) {
  ggplot(bikes, aes(x = temp, y = humidity)) +
    { if(smooth) geom_smooth(color = "red") } +
    geom_point(alpha = .5)
}


## -----------------------------------------------------------------------------
draw_scatter()


## -----------------------------------------------------------------------------
draw_scatter(smooth = FALSE)


## -----------------------------------------------------------------------------
geom_scatterfit <- function(pointsize = 1, pointalpha = 1, 
                            method = "lm", linecolor = "red", ...) {
  list(
    geom_point(size = pointsize, alpha = pointalpha, ...),
    geom_smooth(method = method, color = linecolor, ...)
  )
}


## -----------------------------------------------------------------------------
ggplot(bikes,
       aes(x = humidity, y = n)) +
  geom_scatterfit()


## -----------------------------------------------------------------------------
ggplot(bikes,
       aes(x = humidity, y = n)) +
  geom_scatterfit(
    color = "#28A87D", 
    linewidth = 3
  )


## -----------------------------------------------------------------------------
ggplot(diamonds, 
       aes(x = carat, y = price)) +
  geom_scatterfit(
    pointsize = .5, 
    pointalpha = .1,
    method = "gam",
    linecolor = "#EFAC00"
  )


## -----------------------------------------------------------------------------
scales_log <- function(sides = "xy") {
  list(
    if(stringr::str_detect(sides, "x")) {
      scale_x_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    },
    if(stringr::str_detect(sides, "y")) {
      scale_y_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    }
  )
}


## -----------------------------------------------------------------------------
ggplot(diamonds, 
       aes(x = carat, y = price)) +
  geom_scatterfit(
    pointsize = .5, 
    pointalpha = .1,
    method = "gam",
    linecolor = "#EFAC00"
  ) +
  scales_log(sides = "y")


## -----------------------------------------------------------------------------
trends_monthly <- function(grp = "January") {
  bikes |> 
    mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = temp, y = n, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    scale_color_manual(values = c("#FFA200", "#757bc7")) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}


## -----------------------------------------------------------------------------
trends_monthly("July")


## -----------------------------------------------------------------------------
trends_monthly <- function(grp = "January") {
  bikes |> 
    mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = temp, y = n, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    # keep axis ranges consistent
    scale_x_continuous(limits = range(bikes$temp)) +
    scale_y_continuous(limits = range(bikes$n)) +
    scale_color_manual(values = c("#FFA200", "#757bc7")) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}


## -----------------------------------------------------------------------------
trends_monthly("July")


## -----------------------------------------------------------------------------
plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
plots[[9]]


## -----------------------------------------------------------------------------
plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
patchwork::wrap_plots(plots)


## -----------------------------------------------------------------------------
plot_density <- function(data, var, grp = "") {
  ggplot(data, aes(x = !!sym(var))) +
    geom_density(aes(fill = !!sym(grp)), position = "identity",
                 color = "grey30", alpha = .3) +
    coord_cartesian(expand = FALSE, clip = "off") +
    scale_y_continuous(labels = scales::label_number()) +
    scale_fill_brewer(palette = "Dark2", name = NULL) +
    theme(legend.position = "top")
}


## -----------------------------------------------------------------------------
plot_density(
  bikes, "n"
)


## -----------------------------------------------------------------------------
plots <- purrr::map(
  c("n", "temp", "humidity", "wind_speed"), 
  ~ plot_density(data = bikes, var = .x, grp = "day_night")
)
patchwork::wrap_plots(plots, nrow = 1)


## -----------------------------------------------------------------------------
plots <- purrr::map(
  c("sleep_total", "sleep_rem", "sleep_cycle"), 
  ~ plot_density(data = filter(msleep, !is.na(vore)), var = .x, grp = "vore")
)
patchwork::wrap_plots(plots, nrow = 1)


## -----------------------------------------------------------------------------
plots <- purrr::map(
  names(select(midwest, where(is.numeric))),
  ~plot_density(data = midwest, var = .x)
)
patchwork::wrap_plots(plots)
