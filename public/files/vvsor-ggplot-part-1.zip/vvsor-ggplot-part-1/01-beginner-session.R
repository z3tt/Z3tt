#------------------------------------------------------------------------------#
#                 “Data Visualization in R — Part 1: Basics”                  #
#                     Cédric Scherer | December 1, 2021                        #
#                                                                              #
#             “Data Visualization Workshop Series” presented by                #
#       Nederlandse Vereniging voor Statistiek & Operations Research           #
#------------------------------------------------------------------------------#


# The Package ------------------------------------------------------------------

## install.packages("ggplot2")
## library(ggplot2)

## install.packages("tidyverse")
library(tidyverse)


# The Data ---------------------------------------------------------------------

graham <- 
  readr::read_csv("https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/caribous_graham.csv",
                  col_types = cols(season = col_factor(), sex = col_character()))

tibble::glimpse(graham)

graham_ind <- graham %>% 
  dplyr::filter(animal_id == "GR_C12") %>% 
  dplyr::select(-animal_id, -sex)

tibble::glimpse(graham_ind)

dplyr::n_distinct(graham_ind$date)

dplyr::n_distinct(graham_ind$year)

unique(graham_ind$year)

range(graham_ind$date)

range(graham_ind$tree_cover)


# Data: ggplot(data) -----------------------------------------------------------

ggplot

ggplot(data = graham_ind) 


# Aesthetics: aes() ------------------------------------------------------------

ggplot(data = graham_ind,
       mapping = aes(x = date, y = tree_cover))

ggplot(graham_ind, aes(date, tree_cover)) 


# Geometrical Layers: geom_*() -------------------------------------------------

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() 

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_line() 
ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  theme_classic()

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  theme_minimal()

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  theme_dark()

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  theme_linedraw()

theme_set(theme_light())

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point()


# Your Turn! ###################################################################

## Create a plot that connects all tracked positions of caribou C12.
ggplot(graham_ind, aes(longitude, latitude))

## What’s the difference between `geom_path()` and `geom_line()`?

## Create a box plot of tree cover over time.

## What is the problem? How could you find out why this is happening?

## Try to create box plots as you would expect them.

## Bonus: Choose the built-in theme you like the most!

################################################################################


# Multiple Layers --------------------------------------------------------------

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  geom_path() + 
  geom_rug(sides = "rb") 

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  geom_path(color = "grey67") + 
  geom_rug(sides = "rb", alpha = .05) 

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67") + 
  geom_point() + 
  geom_rug(sides = "rb", alpha = .05)

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67")+
  geom_point() +
  xlab("Longitude") + 
  ylab("Latitude") 

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67")+
  geom_point() +
  xlab("Longitude") + 
  ylab("Latitude") +
  ggtitle("Trajectory of Caribou C12") 

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67")+
  geom_point() +
  labs( 
    x = "Longitude",  
    y = "Latitude", 
    title = "Trajectory of Caribou C12", 
    subtitle = "Map of 10,248 locations of female C12 tracked between 2001\nand 2003 in Graham, Canada",
    caption = "Data: B.C. Ministry of Environment & Climate Change", 
    tag = "Fig. 1" 
  ) 

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67")+
  geom_point() +
  labs(
    x = NULL, ## don't use "" 
    y = NULL, ## don't use "" 
    title = "Trajectory of Caribou C12",
    subtitle = "Map of 10,248 locations of female C12 tracked between 2001\nand 2003 in Graham, Canada",
    caption = "Data: B.C. Ministry of Environment & Climate Change", 
    tag = "Fig. 1" 
  )

g <- ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point()

g

g + 
  geom_path(color = "grey67") + 
  geom_rug(sides = "rb", alpha = .05) 


## Saving a ggplot -------------------------------------------------------------

ggsave(filename = "my_ggplot.pdf", 
 width = 10, height = 7, 
 device = cairo_pdf)

ggsave(filename = "my_ggplot.png", 
 width = 10, height = 7, 
 dpi = 700)


# Aesthetics + Scales: aes() + scale_*() ---------------------------------------

ggplot(graham_ind, 
       aes(longitude, latitude,
           color = season)) +
  geom_point()

ggplot(graham_ind, 
       aes(longitude, latitude,
           color = tree_cover)) +
  geom_point()

ggplot(graham_ind, 
       aes(longitude, latitude,
           color = season, 
           shape = season)) + 
  geom_point()

ggplot(graham_ind, 
       aes(longitude, latitude,
           size = tree_cover)) + 
  geom_point(color = "darkgreen", 
             shape = 1)

ggplot(graham_ind, 
       aes(date, tree_cover,
           color = season)) + 
  geom_point() +
  scale_x_date() +
  scale_y_continuous() +
  scale_color_discrete() 

ggplot(graham_ind, 
       aes(date, tree_cover,
           color = season)) + 
  geom_point() +
  scale_x_date(
    expand = c(0, 0), ## general 
    date_breaks = "3 months", ## date-only  
    date_labels = "%m/%y", ## date only 
    name = NULL ## general
  ) +
  scale_y_continuous() +
  scale_color_discrete() 

ggplot(graham_ind, 
       aes(date, tree_cover,
           color = season)) + 
  geom_point() +
  scale_x_date(
    expand = c(0, 0), ## general 
    date_breaks = "3 months", ## date-only  
    date_labels = "%m/%y", ## date only 
    name = NULL ## general
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1), ## general
    sec.axis = dup_axis(name = NULL), ## axis only 
    name = "Tree Cover" ## general
  ) + 
  scale_color_discrete()

ggplot(graham_ind, 
       aes(date, tree_cover,
           color = season)) + 
  geom_point() +
  scale_x_date(
    expand = c(0, 0), ## general 
    date_breaks = "3 months", ## date-only  
    date_labels = "%m/%y", ## date only 
    name = NULL ## general
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1), ## general
    sec.axis = dup_axis(name = NULL), ## axis only 
    name = "Tree Cover" ## general
  ) +  
  scale_color_discrete(
    type = c("#c49c67", "#228b22"),## color only 
    name = "Season:" ## general
  )

ggplot(graham_ind, 
       aes(date, tree_cover,
           color = season)) + 
  geom_point() +
  scale_color_discrete( 
    type = c("#c49c67", "#228b22") 
  ) 

ggplot(graham_ind, 
       aes(date, tree_cover,
           color = season)) + 
  geom_point() +
  scale_color_manual( 
    values = c("#c49c67", "#228b22") 
  ) 

ggplot(graham_ind, 
       aes(longitude, latitude,
           color = yday)) + 
  geom_point() +
  scale_color_continuous( 
    type = "viridis" 
  ) 

ggplot(graham_ind, 
       aes(longitude, latitude,
           color = yday)) + 
  geom_point() +
  scale_color_gradient( 
    low = "#e8d8c3", high = "#134e13" 
  ) 


# Your Turn! ###################################################################

## Create the visualization `exercise-hex.png`

################################################################################


# Facets: facet_*() ------------------------------------------------------------

g <-
  ggplot(graham_ind,
         aes(longitude, latitude)) +
  geom_path(color = "grey67") +
  geom_point(aes(color = factor(year)))

g

g +
  facet_wrap(~ season)

g +
  facet_wrap(~ factor(year))

g +
  facet_wrap(
    ~ factor(year),
    nrow = 3
  )

g +
  facet_wrap(
    ~ factor(year),
    ncol = 2
  )

g +
  facet_grid(
    factor(year) ~ season
  )

g +
  facet_grid(
    season ~ factor(year)
  )


# Coordinate Systems: coord_*() ------------------------------------------------

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path() +
  coord_cartesian(ylim = c(56.8, NA))

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path() +
  coord_cartesian(ylim = c(56.8, NA))

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path() +
  coord_cartesian(ylim = c(56.8, NA))

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path() +
  scale_y_continuous(limits = c(56.8, NA))

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  coord_cartesian(expand = FALSE)

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  coord_cartesian(
    expand = FALSE,
    clip = "off",
    ylim = c(56.8, NA) 
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  coord_fixed()

ggplot(graham_agg, aes(longitude, latitude)) +
  geom_point() +
  coord_fixed(ratio = 5) +
  scale_y_continuous(breaks = seq(56, 58, by = .04))

ggplot(graham_agg, aes(longitude, latitude)) +
  geom_path() +
  coord_polar()

################################################################################
