#------------------------------------------------------------------------------#
#                                                                              #
#                          Crafting Publication-Ready                          #
#                       Data Visualizations with ggplot2                       #
#                                                                              #
#                           Advanced Use of ggplot2                            #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                           iDiv Workshop April 2025                           #
#                                                                              #
#------------------------------------------------------------------------------#


pkgs <- c(
  "ggplot2", "readr", "dplyr", "stringr", "forcats", "lubridate", "scales", 
  "ggforce", "concaveman", "systemfonts", "geomtextpath", "ggtext", "marquee", 
  "ggbeeswarm", "ggdist", "ggridges", "ggpointdensity", "ggdensity", "purrr", 
  "patchwork", "ggiraph", "gapminder"
)

install.packages(setdiff(pkgs, rownames(installed.packages())))


library(ggplot2)
library(dplyr)

bikes <- readr::read_csv(
  # here::here("data", "london-bikes-custom.csv"),
  "https://cedricscherer.com/data/london-bikes-custom.csv",
  col_types = "Dcfffilllddddc"
)

theme_set(theme_light(base_size = 14, base_family = "Asap SemiCondensed"))

theme_update(
  panel.grid.minor = element_blank(),
  legend.position = "top",
  plot.title.position = "plot"
)

g <-
  ggplot(
    bikes,
    aes(x = temp, y = count,
        color = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm",
    color = "black"
  ) +
  scale_color_manual(
    values = c(day = "#FFA200", night = "#757BC7")
  )

g

library(systemfonts)

match_font("Asap", bold = TRUE)

system_fonts()

system_fonts() |>
  filter(stringr::str_detect(family, "Asap")) |>
  select(family) |>
  unique() |> 
  arrange(family)

g +
  theme_minimal(
    base_family = "Asap Expanded",
    base_size = 13
  )

system_fonts() |>
  filter(family == "Asap SemiCondensed") |>
  select(name) |>
  arrange(name)

register_variant(
  name = "Asap SemiCondensed Semibold S1",
  family = "Asap SemiCondensed",
  weight = "semibold",
  features = font_feature(letters = "stylistic")
)

g + 
  theme_minimal(
    base_family = "Asap SemiCondensed Semibold S1",
    base_size = 13
  )

register_variant(
  name = "Spline Sans Tabular",
  family = "Spline Sans",
  weight = "normal",
  features = font_feature(numbers = "tabular")
)

ga <- 
  ggplot(bikes, 
         aes(x = temp, y = count)) +
  geom_point(
    aes(color = count > 40000),
    size = 2
  ) +
  scale_color_manual(
    values = c("grey", "firebrick"),
    guide = "none"
  )

ga

ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?"
  )

ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?",
    color = "firebrick",
    size = 6,
    family = "Asap SemiCondensed",
    fontface = "bold",
    lineheight =  .8
  )

ga +
  annotate(
    geom = "text",
    x = c(18, max(bikes$temp)),
    y = c(48000, 1000),
    label = c("What happened here?", "Powered by TfL"),
    color = c("firebrick", "black"),
    size = c(6, 3),
    family = c("Asap SemiCondensed", "Spline Sans Mono"),
    fontface = c("bold", "plain"),
    hjust = c(.5, 1)
  )

## ggannotate::ggannotate(g)

ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "segment",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )

ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )

ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow()
  )

ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed",
      ends = "both"
    )
  )

ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .8,
    angle = 130,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed"
    )
  )

g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000)
  )

g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    color = "black",
    label.family = "Asap SemiCondensed"
  )

g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed"
  )

g +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    radius = unit(12, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )

g +
  ggforce::geom_mark_circle(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )

g +
  ggforce::geom_mark_hull(
    aes(label = "Outliers?",
        filter = count > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )

bikes_monthly <-
  bikes |> 
  filter(year == "2016") |> 
  mutate(month = lubridate::month(date, label = TRUE)) |>
  summarize(
    count = sum(count), 
    .by = c(month, day_night)
  )

ggplot(
    bikes_monthly,
    aes(x = month, y = count, 
        color = day_night,
        group = day_night)
  ) +
  geom_line(linewidth = 1) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000),
    name = "Rented bikes per month"
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    name = NULL
  ) +
  labs(x = NULL)

ggplot(
    bikes_monthly,
    aes(x = month, y = count, 
        color = day_night,
        group = day_night)
  ) +
  geom_line(linewidth = 1) +
  geom_text(
    data = filter(bikes_monthly, month == "Jul"),
    aes(label = day_night),
    family = "Asap SemiCondensed",
    fontface = "bold",
    vjust = -.5,
    hjust = 0
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000),
    name = "Rented bikes per month"
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  ) +
  labs(x = NULL)

ggplot(
    bikes_monthly,
    aes(x = month, y = count, 
        color = day_night,
        group = day_night)
  ) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    family = "Asap SemiCondensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000),
    name = "Rented bikes per month"
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  ) +
  labs(x = NULL)

bikes_monthly |>
  mutate(day_night = if_else(
    day_night == "day", 
    "Day period (6am-6pm)", 
    "Night period (6pm-6am)"
  )) |> 
  ggplot(aes(x = month, y = count, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    hjust = .05,
    family = "Asap SemiCondensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_y_continuous(
    labels = scales::label_comma(
      scale = 1/10^3, suffix = "K"
    ),
    limits = c(0, 850000),
    name = "Rented bikes per month"
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  ) +
  labs(x = NULL)

g +
  ggtitle("**TfL bike sharing trends by *period of the day***")

g +
  ggtitle("**TfL bike sharing trends by *period of the day***") +
  theme(
    plot.title = ggtext::element_markdown()
  )

g +
  ggtitle("<i style='font-family:times;font-size:30pt;'>TfL</i> bike sharing trends during <b style='color:#FFA200;'>day</b> and <b style='color:#757BC7;'>night</b>") +
  theme(
    plot.title = ggtext::element_markdown()
  )

g +
  ggtitle("<i style='font-family:times;font-size:30pt;'>TfL</i> bike sharing trends during <b style='color:#FFA200;'>day</b> and <b style='color:#757BC7;'>night</b>") +
  theme(
    plot.title = 
      ggtext::element_textbox_simple(
        margin = margin(t = 12, b = 12),
        padding = margin(rep(12, 4)),
        fill = "grey90",
        box.colour = "grey30",
        linetype = "13",
        r = unit(9, "pt"),
        halign = .5,
        lineheight = 1
      )
  )

g +
  ggtext::geom_richtext(
    data = data.frame(
      temp = c(5, 25),
      count = c(40000, 5000),
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> **2**")
    ),
    aes(label = lab),
    color = "black"
  )

g +
  ggtext::geom_richtext(
    data = data.frame(
      temp = c(5, 25),
      count = c(40000, 5000),
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> **2**"),
      angle = c(35, 310)
    ),
    aes(label = lab,
        angle = angle),
    color = "black"
  )

g +
  ggtext::geom_textbox(
    data = data.frame(
      temp = 10,
      count = 40000,
      lab = "Lorem ipsum dolor sit amet, **consectetur adipiscing elit**, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud <i style='color:red;'>exercitation</i> ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ),
    aes(label = lab),
    color = "black",
    size = 3,
    halign = .5
  )

g +
  marquee::geom_marquee(
    data = filter(bikes, count > 40000),
    aes(label = paste0("{.orange **", date, "**} was a **Strike Day**")),
    color = "black",
    vjust = 1.3
  ) +
  coord_cartesian(clip = "off")

md <- 
"## Bike Rents in {.red London}
The visualization shows the _number of bikes_ versus _average temperature_."

g +
  ggtitle(md) + 
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc")
    )
  )

md <- 
"One can even add code chunks:

    text <- \"markdown **text**\"
    marquee_grob(text)

... and even lists:

1. this
1. is
1. awesome!
"

g +
  ggtitle(md) + 
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc")
    )
  )

logo <- "![](img/tfl.jpg)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      width = unit(1.15, "npc")
    )
  )

logo <- "Powered by TfL Open Data ![](img/tfl.png)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      size = 20, margin = margin(20, 0, 0, 0)
    )
  )

bikes_day <- filter(bikes, day_night == "day")

ggplot(bikes_day, aes(x = season, y = humidity)) +
  geom_boxplot()

ggplot(bikes_day, aes(x = season, y = humidity)) +
  geom_violin()

ggplot(bikes_day, aes(x = season, y = humidity)) +
  geom_violin() +
  geom_boxplot(width = .2)

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm()

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm(priority = "descending")

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm(side = -1)

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm(method = "hex", size = 1.5, cex = 2)

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_quasirandom()

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_quasirandom(method = "smiley")

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_eye()

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye() ## default: `.width = c(.66, .95)`

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye(.width = .5)  +
  ggtitle("stat_halfeye(.width = .5)") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"))

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye(.width = c(0, 1)) +
  ggtitle("stat_halfeye(.width = c(0, 1))") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"))

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye(.width = c(0, 1), adjust = .5, shape = 23, point_size = 5)

ggplot(bikes, aes(x = season, y = humidity, fill = day_night)) +
  ggdist::stat_halfeye(.width = 0, adjust = .5, slab_alpha = .5, shape = 21) +
  scale_fill_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval()

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval(.width = 1:4*.25, linewidth = 10) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval(.width = 1:4*.25) +
  ggdist::stat_dots(position = position_nudge(x = .05), scale = .8) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval(.width = 1:4*.25) +
  ggdist::stat_halfeye(.width = 0, color = "white", position = position_nudge(x = .025)) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(bikes_day, aes(x = humidity, y = season)) +
  ggridges::geom_density_ridges()

ggplot(bikes, aes(x = humidity, y = season, fill = day_night)) +
  ggridges::geom_density_ridges(alpha = .5)

ggplot(bikes, aes(x = humidity, y = season, fill = day_night)) +
  ggridges::geom_density_ridges(alpha = .5, color = "white", scale = 1.5) +
  scale_fill_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes_day, aes(x = humidity, y = season, fill = stat(x))) +
  ggridges::geom_density_ridges_gradient(color = "white", scale = 1.5) +
  scale_fill_gradient(low = "#FFCE52", high = "#663399", guide = "none")

ggplot(bikes, aes(x = humidity, y = temp)) +
  geom_point(size = 3, alpha = .5)

ggplot(bikes, aes(x = humidity, y = temp)) +
  geom_point(size = 3, alpha = .1)

ggplot(bikes, aes(x = humidity, y = temp)) +
  ggpointdensity::geom_pointdensity(size = 2)

ggplot(bikes, aes(x = humidity, y = temp)) +
  ggpointdensity::geom_pointdensity(size = 2, adjust = .5) +
  scale_color_gradient(low = "#FFCE52", high = "#663399")

ggplot(bikes, aes(x = humidity, y = temp, color = day_night)) +
  geom_point(size = 5, alpha = .5) +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes, aes(x = humidity, y = temp, color = day_night)) +
  geom_point(size = 5, alpha = .5) |> ggblend::blend("multiply") +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes, aes(x = humidity, y = temp, color = day_night)) +
  geom_point(alpha = .2, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines() +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes, aes(x = temp, y = count, color = day_night)) +
  geom_point(alpha = .2, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines() +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes, aes(x = temp, y = count, color = day_night)) +
  geom_point(alpha = .2, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines(method = "mvnorm", probs = c(.95, .75, .5, .25, .1)) +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)

ggplot(bikes, aes(x = humidity, y = temp)) +
  ggdensity::geom_hdr_points(method = "histogram", probs = c(.95, .5, .1), size = 3, alpha = .7) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(bikes, aes(x = humidity, y = temp)) +
  geom_density_2d_filled() +
  coord_cartesian(expand = FALSE) +
  ggtitle("geom_density_2d_filled()") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"), legend.position = "top")

ggplot(bikes, aes(x = humidity, y = temp)) +
  ggdensity::geom_hdr(probs = seq(.999, .2, length.out = 5)) +
  coord_cartesian(expand = FALSE) +
  ggtitle("ggdensity::geom_hdr()") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"), legend.position = "top")

theme_set(theme_minimal(base_size = 18, base_family = "Pally"))
theme_update(
  text = element_text(family = "Pally"),
  panel.grid = element_blank(),
  axis.text = element_text(color = "grey50", size = 12),
  axis.title = element_text(color = "grey40", face = "bold"),
  axis.title.x = element_text(margin = margin(t = 12)),
  axis.title.y = element_text(margin = margin(r = 12)),
  axis.line = element_line(color = "grey80", linewidth = .4),
  legend.text = element_text(color = "grey50", size = 12),
  plot.tag = element_text(size = 40, margin = margin(b = 15)),
  plot.background = element_rect(fill = "white", color = "white")
)

bikes_sorted <-
  bikes |>
  filter(!is.na(weather_type)) |>
  group_by(weather_type) |>
  mutate(sum = sum(count)) |>
  ungroup() |>
  mutate(
    weather_type = forcats::fct_reorder(
      stringr::str_to_title(stringr::str_wrap(weather_type, 5)), sum
    )
  )

p1 <- ggplot(
    bikes_sorted,
    aes(x = weather_type, y = count, color = weather_type)
  ) +
  geom_hline(yintercept = 0, color = "grey80", linewidth = .4) +
  stat_summary(
    geom = "point", fun = "sum", size = 12
  ) +
  stat_summary(
    geom = "linerange", ymin = 0, fun.max = function(y) sum(y),
    size = 2, show.legend = FALSE
  ) +
  coord_flip(ylim = c(0, NA), clip = "off") +
  scale_y_continuous(
    expand = c(0, 0), limits = c(0, 8500000),
    labels = scales::comma_format(scale = .0001, suffix = "K")
  ) +
  scale_color_viridis_d(
    option = "magma", direction = -1, begin = .1, end = .9, name = NULL,
    guide = guide_legend(override.aes = list(size = 7))
  ) +
  labs(
    x = NULL, y = "Sum of reported bike shares", tag = "P1",
  ) +
  theme(
    axis.line.y = element_blank(),
    axis.text.y = element_text(family = "Pally", color = "grey50", face = "bold",
                               margin = margin(r = 15), lineheight = .9)
  )

p1

p2 <- bikes_sorted |>
  filter(season == "winter", is_weekend == TRUE, day_night == "night") |>
  group_by(weather_type, .drop = FALSE) |>
  mutate(id = row_number()) |>
  ggplot(
      aes(x = weather_type, y = id, color = weather_type)
    ) +
    geom_point(size = 4.5) +
    scale_color_viridis_d(
      option = "magma", direction = -1, begin = .1, end = .9, name = NULL,
      guide = guide_legend(override.aes = list(size = 7))
    ) +
    labs(
      x = NULL, y = "Reported bike shares on\nweekend winter nights", tag = "P2",
    ) +
    coord_cartesian(ylim = c(.5, NA), clip = "off")

p2

my_colors <- c("#cc0000", "#000080")

p3 <- bikes |>
  group_by(week = lubridate::week(date), day_night, year) |>
  summarize(count = sum(count)) |>
  group_by(week, day_night) |>
  mutate(avg = mean(count)) |>
  ggplot(aes(x = week, y = count, group = interaction(day_night, year))) +
    geom_line(color = "grey65", linewidth = 1) +
    geom_line(aes(y = avg, color = day_night), stat = "unique", linewidth = 1.7) +
    annotate(
      geom = "text", label = c("Day", "Night"), color = my_colors,
      x = c(5, 18), y = c(125000, 29000), size = 8, fontface = "bold", family = "Pally"
    ) +
    scale_x_continuous(breaks = c(1, 1:10*5)) +
    scale_y_continuous(labels = scales::comma) +
    scale_color_manual(values = my_colors, guide = "none") +
    labs(
      x = "Week of the Year", y = "Reported bike shares\n(cumulative # per week)", tag = "P3",
    )

p3

library(patchwork)

(p1 + p2) / p3

(p1 + p2) / p3 + plot_layout(guides = "collect")

((p1 + p2) / p3 & theme(legend.justification = "top")) + plot_layout(guides = "collect")

((p1 + p2) / p3 & theme(legend.position = "none")) +
  plot_layout(heights = c(.2, .1), widths = c(2, 1))

picasso <- "
AAAAAA#BBBB
CCCCCCCCC##
CCCCCCCCC##"

(p1 + p2 + p3 & theme(legend.position = "none")) + plot_layout(design = picasso)

pl1 <- p1 + labs(tag = NULL, title = "Plot One") + theme(legend.position = "none")
pl2 <- p2 + labs(tag = NULL, title = "Plot Two") + theme(legend.position = "none")
pl3 <- p3 + labs(tag = NULL, title = "Plot Three") + theme(legend.position = "none")

(pl1 + pl2) / pl3 +
  plot_annotation(tag_levels = "1", tag_prefix = "P", title = "An overarching title for all 3 plots, placed on the very top while all other titles are sitting below the tags.")

pl1 + inset_element(pl2, l = .6, b = .1, r = 1, t = .6)

pl1 + inset_element(pl2, l = .6, b = 0, r = 1, t = .5, align_to = 'full')

smooth <- TRUE

ggplot(bikes, aes(x = temp, y = humidity)) +
  { if(smooth) geom_smooth(color = "red") } +
  geom_point(alpha = .5)

smooth <- FALSE

ggplot(bikes, aes(x = temp, y = humidity)) +
  { if(smooth) geom_smooth(color = "red") } +
  geom_point(alpha = .5)

draw_scatter <- function(smooth = TRUE) {
  ggplot(bikes, aes(x = temp, y = humidity)) +
    { if(smooth) geom_smooth(color = "red") } +
    geom_point(alpha = .5)
}

draw_scatter()

draw_scatter(smooth = FALSE)

geom_scatterfit <- function(pointsize = 1, pointalpha = 1, 
                            method = "lm", linecolor = "red", ...) {
  list(
    geom_point(size = pointsize, alpha = pointalpha, ...),
    geom_smooth(method = method, color = linecolor, ...)
  )
}

ggplot(bikes,
       aes(x = humidity, y = count)) +
  geom_scatterfit()

ggplot(bikes,
       aes(x = humidity, y = count)) +
  geom_scatterfit(
    color = "#28A87D", 
    linewidth = 3
  )

ggplot(diamonds, 
       aes(x = carat, y = price)) +
  geom_scatterfit(
    pointsize = .5, 
    pointalpha = .1,
    method = "gam",
    linecolor = "#EFAC00"
  )

scales_log <- function(sides = "xy") {
  list(
    if(stringr::str_detect(sides, "x")) {
      scale_x_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    },
    if(stringr::str_detect(sides, "y")) {
      scale_y_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    }
  )
}

ggplot(diamonds, 
       aes(x = carat, y = price)) +
  geom_scatterfit(
    pointsize = .5, 
    pointalpha = .1,
    method = "gam",
    linecolor = "#EFAC00"
  ) +
  scales_log(sides = "y")

trends_monthly <- function(grp = "January") {
  bikes |> 
    mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = temp, y = count, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    scale_color_manual(values = c("#FFA200", "#757bc7")) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}

trends_monthly("July")

trends_monthly <- function(grp = "January") {
  bikes |> 
    mutate(month = lubridate::month(date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = temp, y = count, color = day_night)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    # keep axis ranges consistent
    scale_x_continuous(limits = range(bikes$temp)) +
    scale_y_continuous(limits = range(bikes$n)) +
    scale_color_manual(values = c("#FFA200", "#757bc7")) +
    labs(title = grp, x = "Temperature", y = "Bike shares", color = NULL)
}

trends_monthly("July")

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
plots[[9]]

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
patchwork::wrap_plots(plots)

plot_density <- function(data, var, grp = "") {
  ggplot(data, aes(x = !!sym(var))) +
    geom_density(aes(fill = !!sym(grp)), position = "identity",
                 color = "grey30", alpha = .3) +
    coord_cartesian(expand = FALSE, clip = "off") +
    scale_y_continuous(labels = scales::label_number()) +
    scale_fill_brewer(palette = "Dark2", name = NULL) +
    theme(legend.position = "top")
}

plot_density(
  bikes, "count"
)

plots <- purrr::map(
  c("count", "temp", "humidity", "wind_speed"), 
  ~ plot_density(data = bikes, var = .x, grp = "day_night")
)
patchwork::wrap_plots(plots, nrow = 1)

plots <- purrr::map(
  c("sleep_total", "sleep_rem", "sleep_cycle"), 
  ~ plot_density(data = filter(msleep, !is.na(vore)), var = .x, grp = "vore")
)
patchwork::wrap_plots(plots, nrow = 1)

plots <- purrr::map(
  names(select(midwest, where(is.numeric))),
  ~plot_density(data = midwest, var = .x)
)
patchwork::wrap_plots(plots)

plot(bikes[, c(6, 10:13)])

ggplot(bikes, aes(x = .panel_x, y = .panel_y)) +
  geom_point() +
  ggforce::facet_matrix(
    vars(count, temp, temp_feel, humidity, wind_speed)
  )

ggplot(bikes, aes(x = .panel_x, y = .panel_y)) +
  geom_point(aes(color = day_night), alpha = .5) +
  geom_smooth(aes(color = day_night), method = "lm") +
  ggforce::geom_autodensity(
    aes(color = day_night, fill = after_scale(color)), alpha = .7
  ) +
  scale_color_brewer(palette = "Set2", name = NULL) +
  ggforce::facet_matrix(
    vars(count, temp, temp_feel, humidity, wind_speed), 
    layer.lower = 2, layer.diag = 3
  )

g2 <- 
  ggplot(bikes, aes(x = temp, y = count, color = day_night)) +
  geom_point_interactive(aes(tooltip = date, data_id = date), size = 3, alpha = .7) +
  ggforce::geom_mark_hull(
    aes(label = "Tube Network Strikes 2015", filter = count > 40000),
    description = "Commuters had to deal with severe disruptions in public transport on July 9 and August 6",
    color = "black", label.family = "Asap SemiCondensed", label.fontsize = c(18, 14)
  ) +
  coord_cartesian(clip = "off") +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), guide = "none") +
  labs(x = "Feels-like temperature (°C)", y = "Reported bike shares") +
  ggtitle("TfL bike sharing trends by *<b style='color:#B48200;'>day</b>* and *<b style='color:#663399;'>night</b>*") +
  theme(plot.title = ggtext::element_markdown(), plot.title.position = "plot") 

girafe(
  ggobj = g2, width_svg = 9, height_svg = 5.5,
  options = list(
    opts_tooltip(use_fill = TRUE, css = "font-size:18pt;font-weight:600;color:white;padding:7px;font-family:asap;"), 
    opts_hover(css = "fill:black;stroke:black;stroke-width:8px;opacity:1;"),
    opts_hover_inv(css = "opacity:0.3;"),
    opts_toolbar(position = "bottomleft"),
    opts_zoom(min = 1, max = 4)
  )
)

g1 <- 
  ggplot(bikes, aes(x = temp_feel, y = count, color = season)) +
  ## point outline
  geom_point_interactive(
    aes(data_id = date),
    color = "black", fill = "white",
    shape = 21, size = 2.8, stroke = .8
  ) +
  ## opaque point background
  geom_point_interactive(
    aes(data_id = date),
    color = "white", size = 2.2
  ) +
  ## colored, semi-transparent points
  geom_point_interactive(
    aes(data_id = date, 
        tooltip = paste0(format(date, format = "%B %d, %Y"), "<br><b style='font-size:18pt;font-weight:900;'>", scales::comma(count), " bikes | ", sprintf("%1.1f", temp_feel), "°C</b>")),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night), method = "lm", color = "black"
  ) +
  ## add call-out
  ggforce::geom_mark_hull(
    aes(label = "Tube Network Strikes 2015",
        filter = count > 40000),
    description = "Severe disruptions in public transport on July 9 and August 6",
    color = "black", label.fontsize = c(16, 13),
    label.family = "Asap SemiCondensed"
  )  +
  ## create small multiples
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y", 
    space = "free_y",
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = c(
        `TRUE` = "Workday",
        `FALSE` = "Weekend or Holiday"
      )
    )
  )

g1

library(ggiraph)

girafe(
  ggobj = g1,
  width_svg = 14,
  height_svg = 8.3
)

register_variant(
  name = "Asap SemiCondensed Black",
  family = "Asap SemiCondensed",
  weight = "heavy"
)

g2 <- g1 +
  ## style axes
  scale_x_continuous(
    expand = expansion(mult = .02),              ## adjust horizontal padding
    breaks = 0:6*5,                              ## adjust x axis breaks
    labels = scales::label_number(suffix = "°C") ## adjust x axis labels
  ) +
  scale_y_continuous(
    expand = expansion(mult = 0, add = c(0, 5000)),  ## adjust vertical padding
    limits = c(0, NA),                               ## include zero in all panels
    breaks = 0:5*10000,                              ## ensure equal y axis breaks
    labels = scales::label_comma()                   ## add commas as big marks
  ) +
  ## custom colors + legend sizes
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), ## custom colors
    guide = guide_legend(override.aes = list(size = 5)),    ## larger legend symbols
    labels = stringr::str_to_title                          ## upper-case key labels
  ) +
  ## titles + caption
  labs(
    x = "Feels-Like Temperature", y = NULL, ## remove y axis title
    caption = "Data: Transport for London (TfL), Jan 2015–Dec 2016",
    title = "Reported TfL bike rents versus feels-like temperature in London, 2015–2016",
    color = NULL ## remove legend title
  )  +
  ## theme adjustments
  theme_light(
    base_size = 18, ## increase sizes of all text elements and widths of lines
    base_family = "Asap SemiCondensed" ## overwrite default typeface
  ) +
  ## more theme adjustments
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.title = ggtext::element_textbox_simple(
      family = "Asap SemiCondensed Black", 
      margin = margin(t = 12, b = 12),
      padding = margin(rep(12, 4)),
      fill = "grey90",
      r = unit(9, "pt"),
      halign = .5,
      size = rel(1.6),
      lineheight = .95
    ),
    axis.title.x = element_text(hjust = 0, color = "grey30", margin = margin(t = 12)),
    strip.text = element_text(face = "bold", size = rel(1.15)),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.spacing = unit(1.2, "lines"),
    legend.position = "top",
    legend.text = element_text(size = rel(1)),
    ## for fitting my slide background
    legend.key = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    legend.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    plot.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8")
  )

girafe(
  ggobj = g2,
  width_svg = 14,
  height_svg = 8.3,
  options = list(
    opts_hover(css = "stroke-width:5"),
    opts_hover_inv(css = "opacity:0.1;"),
    opts_tooltip(use_fill = TRUE, css = "stroke-width:5;opacity:1;font-size:28pt;font-weight:400;color:black;border-radius:4px;padding:7px;font-family:Asap SemiCondensed;"),
    opts_toolbar(position = "bottomleft")
  )
)


## Template for Exercise 2

library(gapminder)

gm2007 <- filter(gapminder, year == 2007)

ggplot(gm2007, aes(x = gdpPercap, y = lifeExp)) +
  geom_point(
    aes(size = pop), alpha = .5
  ) +
  scale_x_log10(
    breaks = c(500, 2000, 8000, 32000),
    labels = scales::label_dollar(accuracy = 1)
  ) +
  scale_size(
    range = c(1, 12), name = "Population:", 
    breaks = c(10, 100, 1000)*1000000, 
    labels = scales::label_comma(scale = 1 / 10^6, suffix = "M")
  ) +
  labs(x = "GDP per capita", y = "Life expectancy") +
  theme_minimal(base_family = "Asap SemiCondensed", base_size = 15) +
  theme(panel.grid.minor = element_blank())