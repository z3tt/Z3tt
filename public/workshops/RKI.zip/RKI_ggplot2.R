#------------------------------------------------------------------------------#
#                                                                              #
#                           Data Visualization in R:                           # 
#                 A Hands-On Overview of Plotting with ggplot2                 #
#                                                                              #
#                     Dr. Cédric Scherer |  June  28, 2022                     #
#                                                                              #
#------------------------------------------------------------------------------#


## PACKAGES ####################################################################

# install.packages("ggplot2")
# library(ggplot2)

# install.packages("tidyverse")
library(tidyverse)

# install.packages("colorBlindness")
# install.packages("colorspace")
# install.packages("ggdist")
# install.packages("ggforce")
# install.packages("ggpointdensity")
# install.packages("ggrepel")
# install.packages("ggtext")
# install.packages("magick")
# install.packages("patchwork")
# install.packages("scico")
# install.packages("systemfonts")



## DATA ########################################################################

chic <- read_csv(
  "https://raw.githubusercontent.com/z3tt/ggplot-courses/master/data/chicago-nmmaps-custom.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

glimpse(chic)




#------------------------------------------------------------------------------#
# CONCEPTS OF GGPLOT2 ----------------------------------------------------------
#------------------------------------------------------------------------------#


## GGPLOT(DATA) ################################################################

?ggplot

ggplot(data = chic)

ggplot(data = chic)



## AESTHETICS ##################################################################

ggplot(
  data = chic,
  mapping = aes(x = date, y = temp)
)

ggplot(
  data = chic,
  mapping = aes(x = date, y = temp)
)

ggplot(chic, aes(x = date, y = temp))

ggplot(chic, aes(x = date, y = temp))



## GEOMETRICAL LAYERS ##########################################################

ggplot(chic, aes(x = date, y = temp)) +
  geom_point()

ggplot(chic, aes(x = date, y = temp)) +
  geom_area()



## THEMES ######################################################################

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_classic()

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_minimal()

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_bw() 

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_dark()

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_light()

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_light()

theme_set(theme_light())

ggplot(chic, aes(x = date, y = temp)) +
  geom_point()

## note that the font needs to be installed locally and the agg device needs to 
## be activated in the Rstudio settings to see the changes in the plots pane:
## Tools -> Global Options -> General -> Graphics -> Backend
ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  theme_light(
    base_size = 35,
    base_family = "Consolas"
  )

## or via (but applies the changes to all following plots)
# theme_set(
#   theme_light(
#     base_size = 35,
#     base_family = "Consolas"
#   )
# )


## GEOMETRICAL LAYERS (CONTINUED) ##############################################


## EXERCISE 1

# Turn our scatter plot into a line chart and into a bar chart!

# What’s the difference between `geom_path()` and `geom_line()`?

# Create a box plot of temperature per date.

# What is the problem? How could you find out why this is happening?



ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  geom_line() +
  geom_rug(sides = "r")



## LABELS ######################################################################

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  xlab("Day of the Year") +
  ylab("Temperature (°F)")

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  xlab("Day of the Year") +
  ylab("Temperature (°F)") +
  ggtitle("Seasonal Change of Temperatures in Chicago")

ggplot(chic, aes(x = date, y = temp)) +
  geom_point() +
  labs(
    x = "Day of the Year",
    y = "Temperature (°F)",
    title = "Seasonal Change of Temperatures in Chicago",
    subtitle = "Daily temperatures (°F) in the city of Chicago, IL,\nmeasured between 1997 and 2001",
    caption = "Data: NMMAPS",
    tag = "Fig. 1"
  )



## ASSIGNING TO AN OBJECT ######################################################

g <-
  ggplot(chic, aes(x = date, y = temp)) +
  geom_point()

g

g <-
  ggplot(chic, aes(x = date, y = temp)) +
  geom_point()

g +
  geom_line() +
  geom_rug(sides = "r")

g <- ggplot(chic, aes(x = date, y = temp)) +
  geom_point()

g +
  geom_smooth()



## SAVING PLOTS ################################################################

ggsave(filename = "my_ggplot.png",
       width = 10, height = 7,
       dpi = 700)

ggsave(filename = "my_ggplot.pdf",
       width = 10, height = 7,
       device = cairo_pdf)



## STATISTICAL LAYERS ##########################################################

## You can go both ways — `stat_x(geom = "y") == geom_y(stat = "x")`

ggplot(chic, aes(x = date, y = temp)) +
  stat_smooth(geom = "smooth")

ggplot(chic, aes(x = date, y = temp)) +
  geom_smooth(stat = "smooth")

ggplot(chic, aes(x = temp)) +
  stat_count(geom = "bar")

ggplot(chic, aes(x = temp)) +
  geom_bar(stat = "count")

ggplot(chic, aes(x = date, y = temp)) +
  stat_identity(geom = "point")

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(stat = "identity")

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary()

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "pointrange" ## the default
  )

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "errorbar",
    width = .3
  )

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary(
    fun = mean,
    fun.max = function(y) mean(y) + sd(y),
    fun.min = function(y) mean(y) - sd(y)
  )

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )

ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot() +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary(
    geom = "errorbar",
    fun.max = function(y) mean(y) + sd(y),
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )

ggplot(chic, aes(x = season, y = temp)) +
  stat_summary(
    geom = "errorbar",
    fun.max = function(y) mean(y) + sd(y),
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "text",
    fun = mean,
    aes(label = paste0(sprintf("%2.1f", ..y..), "°F")),
    hjust = -.25,
    size = 5
  ) +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )



## AESTHETICS (AGAIN) ##########################################################

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(
    size = 4,
    alpha = .3
  )

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(
    aes(color = season,
        shape = year),
    size = 4,
    alpha = .3
  )

ggplot(chic, aes(x = date, y = temp,
                 color = season,
                 shape = year)) +
  geom_point(
    size = 4,
    alpha = .3
  )

ggplot(chic, aes(x = date, y = temp)) +
  geom_line(aes(color = season))

ggplot(chic, aes(x = date, y = temp)) +
  geom_line(aes(color = season, group = year))

ggplot(chic, aes(x = date, y = temp)) +
  geom_line(aes(color = season, group = year)) +
  stat_smooth(color = "black")

ggplot(chic, aes(x = date, y = temp, group = year)) +
  geom_line(aes(color = season)) +
  stat_smooth(color = "black")

ggplot(chic, aes(x = date, y = temp, group = year)) +
  geom_boxplot()



## SCALES ######################################################################

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_x_date() +
  scale_y_continuous() +
  scale_color_discrete()

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_x_date() +
  scale_y_continuous(
    breaks = seq(-10, 90, by = 10),  
    labels = function(y) paste0(y, "°F"),  
    name = "Temperature" 
  ) +
  scale_color_discrete()

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0),
    date_breaks = "6 months",
    date_labels = "%m/%y",
    name = NULL 
  ) +
  scale_y_continuous(
    breaks = seq(-10, 90, by = 10),
    labels = function(y) paste0(y, "°F"),
    name = "Temperature"
  ) +
  scale_color_discrete()

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0),
    date_breaks = "6 months",
    date_labels = "%m/%y",
    name = NULL
  ) +
  scale_y_continuous(
    breaks = seq(-10, 90, by = 10),
    labels = function(y) paste0(y, "°F"),
    name = "Temperature"
  ) +
  scale_color_discrete(
    type = c("#91A3E1", "#83B692", "#F9ADA0", "#CD6FD5"),
    name = "Season:" 
  )


### COLOR-SCALES

### qualitative (`discrete`)

ggplot(chic, aes(x = date, y = temp, color = season)) + 
  geom_point() +
  scale_color_discrete(
    type = c("#91A3E1", "#83B692", "#F9ADA0", "#CD6FD5")
  )

ggplot(chic, aes(x = date, y = temp, color = season)) + 
  geom_point() +
  scale_color_manual(
    values = c("#91A3E1", "#83B692", "#F9ADA0", "#CD6FD5")
  )

colors <- tibble(
  season = levels(chic$season),
  hex_code = c("#91A3E1", "#83B692", "#F9ADA0", "#CD6FD5")
)

chic %>%
  left_join(colors) %>%
  ggplot(aes(x = date, y = temp, color = hex_code)) +
  geom_point() +
  scale_color_identity()

chic %>%
  left_join(colors) %>%
  ggplot(aes(x = date, y = temp, color = hex_code)) +
  geom_point() +
  scale_color_identity(guide = "legend")

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_color_viridis_d(
    option = "mako"
  )

ggplot(chic, aes(x = date, y = temp, color = season)) + 
  geom_point() +
  scale_color_viridis_d(
    option = "turbo"
  )

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_color_brewer(
    palette = "Set1"
  )

ggplot(chic, aes(x = date, y = temp, color = season)) +
  geom_point() +
  scale_color_brewer(
    palette = "Set2"
  )


### quantitative (`continuous`)

ggplot(chic, aes(x = date, y = temp, color = o3)) + 
  geom_point() +
  scale_color_continuous(
    type = "viridis"
  )

ggplot(chic, aes(x = date, y = temp, color = o3)) +  
  geom_point() +
  scale_color_gradient(
    low = "#e8d8c3", high = "#1e4511"
  )

ggplot(chic, aes(x = date, y = temp, color = o3)) +
  geom_point() +
  scale_color_viridis_c(
    option = "viridis", direction = -1
  )

ggplot(chic, aes(x = date, y = temp, color = o3)) + 
  geom_point() +
  scale_color_viridis_c( 
    option = "inferno", end = .9
  ) 

ggplot(chic, aes(x = date, y = temp, color = o3)) +
  geom_point() +
  scale_color_distiller(
    palette = "PuRd"
  )

ggplot(chic, aes(x = date, y = temp, color = o3)) +
  geom_point() +
  scale_color_distiller(
    palette = "Spectral"
  )


### OTHER SCALES

ggplot(chic, aes(x = date, y = temp, shape = year)) + 
  geom_point(fill = "red") +
  scale_shape_manual(
    values = 21:24
  )

ggplot(chic, aes(x = date, y = temp, linetype = year)) + 
  geom_line() +
  scale_linetype_manual(
    values = 3:6
  )

ggplot(chic, aes(x = date, y = temp, size = o3)) + 
  geom_point(alpha = .5) +
  scale_size(
    range = c(.5, 3.5)
  )

ggplot(chic, aes(x = date, y = temp, alpha = o3)) + 
  geom_point() +
  scale_alpha(
    range = c(.2, .8)
  )



## EXERCISE 2

# Create one of the following two visualizations:

# 1. Scatter Plot with Smoothing + Highlights: exercise-2-1-scatter-smoothing
#    Hint: The plot uses a training data set called `mpg` that comes with `ggplot2`.

# 2. Hexagon-Heatmap with Custom Labels + Colors: exercise-2-2-hex-heatmap
#    Hint: The second plot uses the `"vikO"` palette from the `{scico}` package.



library(colorspace)

g <-
  ggplot(chic, aes(x = temp, y = o3)) +
  geom_hex(
    color = "grey85",
    stroke = 1 
  ) +
  scale_x_continuous(
    breaks = seq(-10, 90, by = 10), 
    labels = function(x) paste0(x, "°F"),
    limits = c(-10, NA)
  ) +
  scale_y_continuous(
    breaks = c(5, 30, 55),
    labels = c("low", "medium", "high") 
  ) +
  scico::scale_fill_scico( 
    palette = "vikO",
    name = "Count:",  
    direction = -1 
  ) +
  labs( 
    x = "Temperature", 
    y = "Ozone Level" 
  ) 

g

colorBlindness::cvdPlot(g)



## COORDINATE SYSTEMS ##########################################################

ggplot(chic, aes(x = date, y = temp)) +
  geom_line() +
  coord_cartesian(
    ylim = c(50, 70)
  )

ggplot(chic, aes(x = date, y = temp)) +
  geom_line() +
  coord_cartesian(
    ylim = c(50, 70)
  )

ggplot(chic, aes(x = date, y = temp)) +
  geom_line() +
  coord_cartesian(ylim = c(50, 70))

ggplot(chic, aes(x = date, y = temp)) +
  geom_line() +
  scale_y_continuous(limits = c(50, 70))

ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot() +
  coord_cartesian(ylim = c(50, 70))

ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot() +
  scale_y_continuous(limits = c(50, 70))

ggplot(chic, aes(x = o3, y = dewpoint)) +
  geom_point() +
  coord_cartesian()


ggplot(chic, aes(x = o3, y = dewpoint)) +
  geom_point() +
  coord_fixed()

ggplot(chic, aes(x = o3, y = dewpoint)) +
  geom_point() +
  coord_cartesian()

ggplot(chic, aes(x = o3, y = dewpoint)) +
  geom_point() +
  coord_fixed(ratio = .25)


ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot() +
  coord_cartesian()

ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot() +
  coord_flip()

ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot() +
  coord_cartesian()

ggplot(chic, aes(x = temp, y = season)) +
  geom_boxplot() +
  coord_cartesian()

ggplot(chic, aes(x = month, y = o3)) +
  stat_summary() +
  coord_flip()

ggplot(chic, aes(x = forcats::fct_rev(month), y = o3)) +
  stat_summary() +
  coord_flip()

ggplot(chic, aes(x = forcats::fct_reorder(month, -yday), y = o3)) +
  stat_summary() +
  coord_flip()

ggplot(chic, aes(x = forcats::fct_reorder(month, o3), y = o3)) +
  stat_summary() +
  coord_flip()


ggplot(chic, aes(x = season, y = temp, fill = season)) +
  stat_summary(fun = mean, geom = "col") +
  coord_cartesian()

ggplot(chic, aes(x = season, y = temp, fill = season)) +
  stat_summary(fun = mean, geom = "col") +
  coord_polar()

ggplot(chic, aes(x = 1, fill = season)) +
  stat_count() + 
  coord_cartesian()

ggplot(chic, aes(x = 1, fill = season)) +
  stat_count() + 
  coord_polar(theta = "y")



### FACETTING ##################################################################

g <-
  ggplot(chic, aes(x = temp, y = o3)) +
  geom_point(
    aes(color = year),
    alpha = .5
  )

g

g +
  facet_wrap(vars(year))

g +
  facet_wrap(~ year)

g +
  facet_wrap(
    vars(year),
    scales = "free"
  )

g +
  facet_wrap(
    vars(year),
    scales = "free_x"
  )

g +
  facet_wrap(
    vars(year),
    scales = "free_x",
    nrow = 4
  )

g +
  facet_grid(
    vars(season),
    vars(year)
  )

g +
  facet_grid(
    season ~ year
  )

g +
  facet_grid(
    year ~ season
  )

g +
  facet_grid(
    year ~ season,
    scales = "free"
  )

g +
  facet_grid(
    year ~ season,
    scales = "free",
    space = "free"
  )


## EXERCISE 3

# A famous statistical data set is the “Datasaurus Dozen”, which is based on “Anscome's Quartet”
#
# More about the Datasaurus Dozen: http://www.thefunctionalart.com/2016/08/download-datasaurus-never-trust-summary.html
# More about Anscombe's Quartett: https://en.wikipedia.org/wiki/Anscombe%27s_quartet
#
# Import the according data into R and inspect it:
# https://raw.githubusercontent.com/z3tt/ggplot-courses/main/data/datasaurus.csv
# 
# Visualize all 13 sets as small multiples of scatter plots.
# 
# Also, add to each facet a linear fitting in the back.
# 
# Remove all axis labels.
#   
# Use a built-in theme and add a title and explanation of the visual.



## THEMING #####################################################################

g +
  theme(
    plot.background = element_rect(
      color = "orange",
      fill = "black",
      size = 2,
      linetype = "dotted"
    ),
    axis.text = element_text(
      family = "Consolas",
      color = "blue",
      angle = 15,
      size = 40
    )
  )

library(systemfonts)

register_variant(
  "Roboto Black",
  "Roboto",
  weight = "heavy"
)

g +
  labs(x = "Temperature (°F)", y = "Ozone Level") +
  theme(axis.title = element_text(
    family = "Roboto Black"
  ))

g +
  theme(
    axis.ticks = element_blank(),
    legend.title = element_blank()
  )

g +
  ggtitle("My Title") +
  theme(
    plot.title.position = "panel",
    legend.position = "top"
  )

g +
  ggtitle("My Title") +
  theme(
    plot.title.position = "plot",
    legend.position = c(.1, .8)
  )

theme_grey

theme_minimal

theme_custom <- function(base_size = 14, base_family = "Cabinet Grotesk", ...) {
  theme_bw(base_size = base_size, base_family = base_family, ...) %+replace%
  theme(
    axis.ticks = element_blank(), 
    axis.text = element_text(family = "Tabular", size = base_size * .8),
    legend.text = element_text(family = "Tabular", size = base_size * .8),
    legend.background = element_blank(), 
    legend.key = element_blank(), 
    legend.position = "top", 
    panel.background = element_rect(fill = "grey96", color = NA), 
    panel.border = element_blank(), 
    panel.grid.major = element_line(color = "grey88"), 
    panel.grid.minor = element_blank(), 
    strip.background = element_blank(), 
    plot.background = element_blank(), 
    plot.title = ggtext::element_textbox_simple( 
      face = "bold", fill = "grey92", size = base_size * 1.4, r = unit(.5, "lines"), 
      margin = margin(25, 0, 25, 0), padding = margin(rep(8, 4)) 
    ), 
    plot.title.position = "plot", 
    complete = TRUE
  )
}

ggplot(chic, aes(x = date, y = temp, color = o3)) +
  geom_point() +
  coord_polar() +
  scale_color_viridis_c(
    option = "turbo", 
    name = "Ozone level:"
  ) +
  labs(
    title = "I went to <b style='color:#3f9afa;'>Cédric's ggplot2 course</b> and all I got is this ridiculous chart that looks like a *butterfly*.",
    x = NULL, 
    y = "Temperature (°F)"
  ) +
  theme_custom()

ggplot(chic, aes(x = date, y = temp, color = o3)) +
  geom_point() +
  coord_polar() +
  scale_color_viridis_c(
    option = "turbo", 
    name = "Ozone level:"
  ) +
  labs(
    title = "I went to <b style='color:#3f9afa;'>Cédric's ggplot2 course</b> and all I got is this ridiculous chart that looks like a *butterfly*.",
    x = NULL, 
    y = "Temperature (°F)"
  ) +
  theme_custom(base_size = 20, base_family = "Chubbo") +
  theme(legend.position = "right")



## ANNOTATION ##################################################################

ggplot(chic, aes(x = temp, y = o3)) +
  annotate(
    geom = "rect",
    xmin = 50,
    xmax = 70,
    ymin = 10,
    ymax = 30,
    color = "firebrick",
    size = 1,
    fill = NA
  ) +
  geom_point(alpha = .4)

ggplot(chic, aes(x = temp, y = o3)) +
  annotate(
    geom = "rect",
    xmin = 70,
    xmax = Inf,
    ymin = -Inf,
    ymax = 25,
    fill = "red",
    color = "firebrick"
  ) +
  geom_point(alpha = .4)

ggplot(chic, aes(x = dewpoint, y = temp)) +
  geom_point(size = 2) +
  annotate(
    geom = "text",
    x = 65, y = 10,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  )

ggplot(chic, aes(x = dewpoint, y = temp)) +
  geom_point(size = 2) +
  annotate(
    geom = "text",
    x = 65, y = 10,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "segment",
    x = 65, y = 18,
    xend = 52, yend = 48
  )

ggplot(chic, aes(x = dewpoint, y = temp)) +
  geom_point(size = 2) +
  annotate(
    geom = "text",
    x = 65, y = 10,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "curve",
    x = 65, y = 18,
    xend = 52, yend = 48,
    arrow = arrow(length = unit(.5, "cm"))
  )

library(magick)

url <- "https://seeklogo.com/images/C/Chicago-logo-949A99BB67-seeklogo.com.png"
img <- image_read(url)

ggplot(chic, aes(x = date, y = temp)) +
  annotation_custom(
    grid::rasterGrob(
      image = img,
      width = .7
    )
  ) +
  geom_point(color = "red")




#------------------------------------------------------------------------------#
# EXCITNG EXTENSION PACKAGES ---------------------------------------------------
#------------------------------------------------------------------------------#


## {GGREPEL} ###################################################################

crypto <- readr::read_csv(
  "https://raw.githubusercontent.com/z3tt/hands-on-ggplot2/main/data/crypto_cleaned.csv"
)

crypto

outliers <-
  crypto %>%
  mutate(dist = abs(close - open) / sqrt(2)) %>%
  filter(dist > 20)

outliers

ggplot(outliers, aes(close, open)) +
  geom_point(data = crypto, color = "grey80") +
  geom_point(size = 2) +
  geom_text(
    aes(label = currency),
    size = 5
  )

ggplot(outliers, aes(close, open)) +
  geom_point(data = crypto, color = "grey80") +
  geom_point(size = 2) +
  geom_text(
    aes(label = currency),
    size = 5,
    hjust = 0,
    nudge_x = 5,
    nudge_y = -5
  ) +
  coord_cartesian(
    xlim = c(NA, 320)
  )

ggplot(outliers, aes(close, open)) +
  geom_point(data = crypto, color = "grey80") +
  geom_point(size = 2) +
  ggrepel::geom_text_repel(
    aes(label = currency),
    size = 5,
    hjust = 0
  )

ggplot(outliers, aes(close, open)) + 
  geom_point(data = crypto, color = "grey80") +
  geom_point(size = 2) +
  geom_text(
    aes(label = currency),
    size = 5,
    hjust = 0
  ) +
  ggtitle("geom_text()") +
  theme(plot.title = element_text(face = "bold", size = 32, hjust = .5))

ggplot(outliers, aes(close, open)) +
  geom_point(data = crypto, color = "grey80") +
  geom_point(size = 2) +
  ggrepel::geom_label_repel(
    aes(label = currency),
    size = 5,
    ## space between points + labels
    box.padding = .5,
    ## always draw segments
    min.segment.length = 0
  )



## {GGDIST} ####################################################################

ggplot(chic, aes(x = season, y = temp, fill = season)) +
  ggdist::stat_eye()

ggplot(chic, aes(x = season, y = temp, fill = season)) +
  ggdist::stat_halfeye()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_dots()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_dotsinterval()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_interval()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_interval(
    .width = c(.25, .5, .75, 1)
  ) +
  scale_color_viridis_d(
    option = "mako",
    end = .9, direction = -1
  )



## {GGFORCE} ###################################################################

ggplot(chic, aes(x = temp, y = yday, color = season)) +
  geom_point() +
  ggforce::geom_mark_ellipse(
    aes(label = season)
  )

ggplot(chic, aes(x = temp, y = yday,
                 color = season)) +
  geom_point() +
  ggforce::geom_mark_hull(
    aes(label = season,
        filter = season == "Summer")
  )

ggplot(chic, aes(x = temp, y = yday,
                 color = season)) +
  geom_point() +
  ggforce::geom_mark_hull(
    aes(label = season,
        filter = season == "Summer",
        description = "This is the season of interest.")
  )


ggplot(chic, aes(x = temp, y = dewpoint,
                 color = season)) +
  geom_point() +
  ggforce::facet_zoom(
    x = season == "Summer"
  )

ggplot(chic, aes(x = temp, y = dewpoint,
                 color = season)) +
  geom_point() +
  ggforce::facet_zoom(
    x = temp > 55,
    y = dewpoint > 60,
    zoom.size = .5
  )

ggplot(chic, aes(x = .panel_x, y = .panel_y)) +
  geom_point(
    alpha = .2
  ) +
  ggforce::facet_matrix(
    vars(temp, o3, dewpoint, yday)
  )



ggplot(chic, aes(x = .panel_x, y = .panel_y)) +
  ## upper
  geom_point(
    aes(fill = season), alpha = .5, shape = 21
  ) +
  geom_rug(
    alpha = .2
  ) +
  ## diagonal
  ggforce::geom_autodensity(
    aes(fill = season), alpha = .7, position = "identity"
  ) +
  ## lower
  geom_density2d(
    color = "black"
  ) +
  ## span matrix
  ggforce::facet_matrix(
    vars(temp, o3, dewpoint, yday),
    layer.upper = 1:2, layer.diag = 3
  ) +
  theme(legend.position = "bottom")



## {GGPOINTDENSITY} ############################################################

ggplot(diamonds, aes(depth, carat)) +
  geom_point(size = 1.5, alpha = .2) +
  ggtitle("geom_point(alpha = .2)")

ggplot(diamonds, aes(depth, carat)) +
  geom_point(size = 1.5, alpha = .005) +
  ggtitle("geom_point(alpha = .005)") 

ggplot(diamonds, aes(depth, carat)) +
  geom_hex(aes(color = after_scale(fill))) +
  scico::scale_fill_scico(palette = "bamako", direction = -1) +
  ggtitle("geom_hex()")

ggplot(diamonds, aes(depth, carat)) +
  geom_bin2d(aes(color = after_scale(fill))) +
  scico::scale_fill_scico(palette = "bamako", direction = -1) +
  ggtitle("geom_bin2d()")


ggplot(diamonds, aes(depth, carat)) +
  ggpointdensity::geom_pointdensity() +
  scico::scale_color_scico(
    palette = "bamako", direction = -1
  ) +
  theme(legend.position = "bottom")

ggplot(diamonds, aes(depth, carat)) +
  ggpointdensity::geom_pointdensity(
    size = 3,
    adjust = 1.5
  ) +
  scico::scale_color_scico(
    palette = "bamako", direction = -1
  ) +
  theme(legend.position = "bottom")


ggplot(chic, aes(x = .panel_x, y = .panel_y)) +
  ## upper
  geom_point(
    aes(fill = season), alpha = .5, shape = 21
  ) +
  geom_rug(
    alpha = .2
  ) +
  ## diagonal
  ggforce::geom_autodensity(
    aes(fill = season), alpha = .7, position = "identity"
  ) +
  ## lower
  ggpointdensity::geom_pointdensity() +
  ## span matrix
  ggforce::facet_matrix(
    vars(temp, o3, dewpoint, yday),
    layer.upper = 1:2, layer.diag = 3
  ) +
  theme(
    legend.position = "bottom",
    legend.box = "vertical"
  )



## {GGTEXT} ####################################################################

library(ggtext)

g +
  labs(
    title = "*My* **Title**",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  )

g +
  labs(
    title = "*My* **Title**",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  ) +
  theme(
    plot.title = element_markdown(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown()
  )

g +
  labs(
    title = "*Integer malesuada nunc __vel risus commodo__ viverra maecenas accumsan lacus*.",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  ) +
  theme(
    plot.title = element_textbox_simple(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown()
  )

g +
  labs(
    title = "*Integer malesuada nunc __vel risus commodo__ viverra maecenas accumsan lacus*.",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  ) +
  theme(
    plot.title = element_textbox_simple(
      fill = "#EDCBA0",
      r = unit(5, "pt"),
      halign = .5,
      padding = margin(5, 1, 3, 1),
      margin = margin(0, 1, 3, 1)
    ),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown()
  )



## {PATCHWORK} #################################################################

(time <- 
    ggplot(chic, aes(x = date, y = temp)) +
    geom_point())

(summary <- 
    ggplot(chic, aes(x = season, y = temp)) +
    geom_boxplot())


library(patchwork)

time + summary

time / summary

time + summary +
  plot_layout(widths = c(1, 2))

time + summary + 
  plot_layout(design = "A#BB")

my_layout <- "
A#BB#
ACC##
DDDDD
"

time + summary + time + summary +
  plot_layout(design = my_layout)


(time + summary) *
  theme_minimal()

(time + summary) *
  theme(axis.title = element_text(color = "red"))

time + summary +
  plot_annotation(
    title = "My very veeeeery long title spanning both plots",
    tag_levels = "A",
    tag_suffix = ")"
  )



## EXERCISE 4

# Using the “Datasaurus Dozen” data set and the previous codes, create the following multipanel 
# visualization with the help of `facet_wrap()` and the `{patchwork}` and `{ggtext}` packages:
# exercise-4-patchwork-datasaurus.png



# -----------------------------------------------------------------------------#
# END --------------------------------------------------------------------------
# -----------------------------------------------------------------------------#
