#------------------------------------------------------------------------------#
#                                                                              #
#                           Data Visualization in R:                           # 
#                 A Hands-On Overview of Plotting with ggplot2                 #
#                                — Exercises —                                 #
#                                                                              #
#                     Dr. Cédric Scherer |  June  28, 2022                     #
#                                                                              #
#------------------------------------------------------------------------------#


library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/z3tt/ggplot-courses/master/data/chicago-nmmaps-custom.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

glimpse(chic)

ggplot(chic, aes(x = date, y = temp)) +
  geom_point()
  
  

## EXERCISE 1

# Turn our scatter plot into a line chart and into a bar chart!

# What’s the difference between `geom_path()` and `geom_line()`?

# Create a box plot of temperature per date.

# What is the problem? How could you find out why this is happening?






## EXERCISE 2

# Create one of the following two visualizations:

# 1. Scatter Plot with Smoothing + Highlights: exercise-2-1-scatter-smoothing
#    Hint: The plot uses a training data set called `mpg` that comes with `ggplot2`.

# 2. Hexagon-Heatmap with Custom Labels + Colors: exercise-2-2-hex-heatmap
#    Hint: The second plot uses the `"vikO"` palette from the `{scico}` package.






## EXERCISE 3

# A famous statistical data set is the “Datasaurus Dozen”, which is based on “Anscome's Quartet”
#
# More about the Datasaurus Dozen: http://www.thefunctionalart.com/2016/08/download-datasaurus-never-trust-summary.html
# More about Anscombe's Quartett: https://en.wikipedia.org/wiki/Anscombe%27s_quartet
#
# Import the according data into R and inspect it:
# https://raw.githubusercontent.com/z3tt/ggplot-courses/main/data/datasaurus.csv
# 
# Visualize all 13 sets as small multiples of scatter plots.
# 
# Also, add to each facet a linear fitting in the back.
# 
# Remove all axis labels.
#   
# Use a built-in theme and add a title and explanation of the visual.






## EXERCISE 4

# Using the “Datasaurus Dozen” data set and the previous codes, create the following multipanel 
# visualization with the help of `facet_wrap()` and the `{patchwork}` and `{ggtext}` packages:
# exercise-4-patchwork-datasaurus.png




