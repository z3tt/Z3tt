################################################################################
#                              BSIO Winter School                              #
# "Data Visualization with {ggplot2}: Fundamentals of the Grammar of Graphics" #
#                       Cédric Scherer | December 6, 2022                      #
################################################################################




## SETUP #######################################################################

## to run all codes, install the following typefaces and restart RStudio:
## Roboto Condensed, Cabinet Grotesk, Tabular (all located in the `fonts` folder) 

## also, make sure to install the following packages 
## (to 'uncomment' the code below, highlight lines 13-20 and press CMD+SHIFT+C)
# packages <- c(
#   "ggplot2", "readr", "tibble", "tidyr", "dplyr", "stringr", "forcats",
#   "scales", "grid", "here", "systemfonts", "RColorBrewer", "rcartocolor",
#   "scico", "ggrepel", "sf", "rnaturalearth", "rmapshaper", "ggtext", "ggrepel",
#   "colorspace", "magick", "palmerpenguins"
# )
# 
# install.packages(setdiff(packages, rownames(installed.packages())))

library(ggplot2)




## DATA ########################################################################

bikes <- readr::read_csv(
  "./data/london-bikes-custom.csv",
  ## or: here::here("data", "london-bikes-custom.csv"),
  ## or: "https://cedricscherer.com/data/london-bikes-custom.csv"
  col_types = "Dcfffilllddddc"
)

bikes$season <- forcats::fct_inorder(bikes$season)

?ggplot

ggplot(data = bikes)



## AESTHETICS ##################################################################

ggplot(data = bikes) +
  aes(x = temp_feel, y = count)

ggplot(
  data = bikes,
  mapping = aes(x = temp_feel, y = count)
)

ggplot(
  bikes,
  aes(x = temp_feel, y = count)
)



## GEOMETRICAL LAYERS ##########################################################

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point()

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    color = "#28a87d",
    alpha = .5,
    shape = "X",
    stroke = 1,
    size = 4
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    color = "#28a87d",
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    aes(color = temp_feel > 20),
    alpha = .5
  )



## EXERCISE --------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = count))
  # add your codes here




ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm"
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )

g <-
  ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )

class(g)

g +
  geom_rug(
    alpha = .2
  )

g +
  geom_rug(
    alpha = .2,
    show.legend = FALSE
  )


## LABELS ######################################################################

g +
  labs(
    x = "Feels-like temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends"
  )

g <- g +
  labs(
    x = "Feels-like temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    color = NULL
  )

g

g +
  labs(
    subtitle = "Reported bike rents versus feels-like temperature in London",
    caption = "Data: TfL",
    tag = "Fig. 1",
    color = "Season:"
  )

g +
  labs(
    x = "",
    caption = "Data: TfL"
  )

g +
  labs(
    x = NULL,
    caption = "Data: TfL"
  )


## VISUAL THEMES ###############################################################

g + theme_light()

g + theme_minimal()

g + theme_light(
  base_size = 14,
  base_family = "Roboto Condensed"
)

theme_set(theme_light())

g

theme_set(theme_light(
  base_size = 14,
  base_family = "Roboto Condensed"
))

g

g +
  theme(
    panel.grid.minor = element_blank()
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold")
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "top"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "none"
  )

g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "top",
    plot.title.position = "plot"
  )

theme_update(
  panel.grid.minor = element_blank(),
  plot.title = element_text(face = "bold"),
  legend.position = "top",
  plot.title.position = "plot"
)

g


## EXPORT ######################################################################

# ggsave(g, filename = "my_plot.png")

# ggsave("my_plot.png")

# ggsave("my_plot.png", width = 8, height = 5, dpi = 600)

# ggsave("my_plot.pdf", width = 20, height = 12, unit = "cm", device = cairo_pdf)



## EXERCISE --------------------------------------------------------------------
ggplot(bikes, aes(x = weather_type, y = count))
  # add your codes here




## FACETS ######################################################################

g +
  facet_wrap(
    vars(day_night)
  )

g +
  facet_wrap(
    ~ day_night
  )

g +
  facet_wrap(
    ~ is_workday + day_night
  )

g +
  facet_grid(
    rows = vars(day_night),
    cols = vars(is_workday)
  )

g +
  facet_grid(
    day_night ~ is_workday
  )

g +
  facet_grid(
    day_night ~ is_workday + season
  )

g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free"
  )

g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free",
    space = "free"
  )

g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y",
    space = "free_y"
  )



## SCALES ######################################################################

ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season)
  ) +
  geom_point() +
  scale_x_continuous() +
  scale_y_continuous() +
  scale_color_discrete()

ggplot(
    bikes,
    aes(x = season, y = temp_feel)
  ) +
  geom_boxplot() +
  scale_x_discrete() +
  scale_y_continuous()

g +
  scale_x_continuous() +
  scale_y_continuous() +
  scale_color_discrete()

g +
  scale_x_binned() +
  scale_y_log10() +
  scale_color_viridis_d()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0)
  ) +
  scale_y_continuous() +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5)
  ) +
  scale_y_continuous() +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C")
  ) +
  scale_y_continuous() +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous() +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500)
  ) +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    limits = c(0, NA)
  ) +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    limits = c(5000, 20000)
  ) +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000
  ) +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_discrete()

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_discrete(
    type = c("#3c89d9", "#1ec99b", "#f7b01b", "#a26e7c")
  )

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#f7b01b", "#a26e7c")
  )

colors_sorted <- c(
  `autumn` = "#a26e7c",
  `spring` = "#1ec99b",
  `summer` = "#f7b01b",
  `winter` = "#3c89d9"
)

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500),
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = colors_sorted
  )

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_brewer(
    palette = "Dark2"
  )

RColorBrewer::display.brewer.all()

RColorBrewer::display.brewer.all(colorblindFriendly = TRUE)

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = colors_sorted,
    name = NULL
  )

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = colors_sorted,
    name = NULL,
    labels = stringr::str_to_title
  )

g +
  scale_x_continuous(
    expand = c(mult = .2, add = 0),
    breaks = seq(0, 30, by = 5), 
    labels = function(x) paste0(x, "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500), 
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = colors_sorted,
    name = NULL,
    labels = stringr::str_to_title,
    guide = guide_legend(
      override.aes = list(size = 5)
    )
  )



## COORDINATE SYSTEMS ##########################################################

ggplot(
    bikes,
    aes(x = season, y = count)
  ) +
  geom_boxplot() +
  coord_cartesian()

ggplot(
    bikes,
    aes(x = season, y = count)
  ) +
  geom_boxplot() +
  coord_cartesian(
    ylim = c(NA, 15000)
  )

ggplot(
    bikes,
    aes(x = season, y = count)
  ) +
  geom_boxplot() +
  coord_cartesian(
    ylim = c(NA, 15000)
  )

ggplot(
    bikes,
    aes(x = season, y = count)
  ) +
  geom_boxplot() +
  scale_y_continuous(
    limits = c(NA, 15000)
  )

ggplot(
    bikes,
    aes(x = season, y = count)
  ) +
  geom_boxplot() +
  coord_cartesian(
    ylim = c(NA, 15000),
    clip = "off"
  ) +
  theme(
    plot.margin = margin(rep(15, 4))
  )

library(dplyr)

ggplot(
    filter(bikes, is_holiday == TRUE),
    aes(x = temp_feel, y = count)
  ) +
  geom_point() +
  geom_text(
    aes(label = season),
    nudge_x = .3,
    hjust = 0
  ) +
  coord_cartesian(
    clip = "off"
  ) +
  theme(
    plot.margin = margin(r = 35)
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = count)
  ) +
  geom_point() +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  )

ggplot(
    bikes,
    aes(x = temp_feel, y = temp)
  ) +
  geom_point() +
  coord_fixed()

ggplot(
    bikes,
    aes(x = temp_feel, y = temp)
  ) +
  geom_point() +
  coord_fixed(ratio = 4)

ggplot(
    bikes,
    aes(x = weather_type)
  ) +
  geom_bar() +
  coord_cartesian()

ggplot(
    bikes,
    aes(x = weather_type)
  ) +
  geom_bar() +
  coord_flip()

ggplot(
    bikes,
    aes(y = weather_type)
  ) +
  geom_bar() +
  coord_cartesian()

ggplot(
    bikes,
    aes(x = weather_type)
  ) +
  geom_bar() +
  coord_flip()

library(forcats)

ggplot(
    filter(bikes, !is.na(weather_type)),
    aes(y = fct_infreq(weather_type))
  ) +
  geom_bar()

ggplot(
    filter(bikes, !is.na(weather_type)),
    aes(y = fct_rev(
      fct_infreq(weather_type)
    ))
  ) +
  geom_bar()



## EXERCISE --------------------------------------------------------------------
ggplot(bikes, aes(x = temp))
  # add your codes here




## WRAP-UP #####################################################################

library(tidyverse)

bikes_adj <-
  readr::read_csv(
    here::here("data", "london-bikes-custom.csv"),
    col_types = "Dcfffilllddddc"
  ) %>%
  mutate(
    season = factor(season, levels = c("spring", "summer", "autumn", "winter")),
    day_night = stringr::str_to_title(day_night),
    is_workday = factor(is_workday, level = c(TRUE, FALSE),
                        labels = c("Workday", "Weekend or Holiday"))
  )

bikes_adj

g1 <- 
  ggplot(bikes_adj, aes(x = temp_feel, y = count)) +
  ## point outline
  geom_point(
    color = "black", fill = "white",
    shape = 21, size = 2.8, stroke = 1.5
  ) +
  ## opaque point background
  geom_point(
    color = "white", size = 2.2
  ) +
  ## colored, semi-transparent points
  geom_point(
    aes(color = forcats::fct_relabel(season, stringr::str_to_title)),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night), method = "lm", color = "black"
  ) +
  ## create small multiples
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y", 
    space = "free_y"
  )

g1

g2 <- g1 +
  ## style axes
  scale_x_continuous(
    expand = c(mult = .02, add = 0),
    breaks = 0:6*5, 
    labels = function(x) paste0(x, "°C")
  ) +
  scale_y_continuous(
    expand = c(mult = .2, add = 0500),
    limits = c(0, NA),
    breaks = 0:5*10000, 
    labels = scales::label_comma()
  ) +
  ## custom colors + legend sizes
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), 
    guide = guide_legend(override.aes = list(size = 5))
  ) +
  ## titles + caption
  labs(
    x = "Feels-Like Temperature", y = NULL,
    caption = "Data: Transport for London (TfL), Jan 2015–Dec 2016",
    title = "Reported TfL bike rents versus feels-like temperature in London, 2015–2016",
    color = NULL
  )  +
  ## themme adjustments
  theme_light(
    base_size = 18, base_family = "Cabinet Grotesk"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold"),
    legend.position = "top",
    plot.title.position = "plot"
  )

g2

