library(tidyverse)

## import data
data_raw <- readr::read_csv(
  "./data/cropland-extent-over-the-long-run.csv"
)


## inspect data
tibble::glimpse(data_raw)


## have a look at code column
unique(data_raw$Code)



## DATA WRANGLING --------------------------------------------------------------


## change year to be integer not double (top illustrate class adjustments)

#> base R way of changing class of 1 column
# data_raw$Year <- as.integer(data_raw$Year)

#> tidy way of changing class of 1 column
# data_raw <- mutate(data_raw, Year = as.integer(Year))

## -> we will do it in one combined data wrangling step below


## adjust data in a "pipeline"
data_cleaned <-
  ## work with data...
  data_raw %>%
  ## ... change column names (turn into lower case + remove white space and other symbols)
  janitor::clean_names() %>% 
  ## rename long cropland column name
  rename("cropland" = cropland_hyde_2017) %>% 
  ## overwrite year as integer + add column for century information
  mutate(
    year = as.integer(year),
    century = year %/% 100 * 100
  ) %>% 
  ## keep only data from 1700 onwards + remove World and Greenland areas
  filter(year >= 1700, !entity %in% c("World", "Greenland")) %>% 
  ## order table by amount of cropland (in decreasing order)
  arrange(-cropland) %>% 
  ## remove the code column
  select(-code)

glimpse(data_cleaned)


## use summarize() to retrieve overall summary metrics
summarize(data_cleaned, cropland_avg = mean(cropland))
data_cleaned %>% summarize(cropland_avg = mean(cropland))


## summarize() is way more exciting when combined with group_by()
data_cleaned %>% 
  group_by(entity, century) %>% 
  summarize(cropland_avg = mean(cropland)) %>% 
  arrange(-cropland_avg)



## DATA VISUALIZATION ----------------------------------------------------------

## visualize the data
ggplot(data_cleaned, aes(x = year, y = cropland, color = entity)) +
  geom_line()


## label last data point, direct labels, basic theming
ggplot(
    data_cleaned, 
    aes(x = year, y = cropland, color = entity)
  ) +
  geom_line() +
  geom_point(
    data = filter(data_cleaned, year == max(year))
  ) +
  geom_text(
    data = filter(data_cleaned, year == max(year)),
    aes(label = entity),
    hjust = 0, lineheight = .8, nudge_x = 2
  ) +
  scale_y_continuous(labels = scales::label_comma()) +
  scale_color_discrete(guide = "none") +
  coord_cartesian(clip = "off", expand = FALSE) +
  labs(x = NULL, y = "Area of cropland (billion ha)") +
  theme_minimal() +
  theme(plot.margin = margin(10, 250, 10, 10))


## avoid overlaping labels, custom colors + fonts, scale adjustments
ggplot(
    data_cleaned, 
    aes(x = year, y = cropland, color = entity)
  ) +
  geom_line() +
  geom_point(
    data = filter(data_cleaned, year == max(year))
  ) +
  ggrepel::geom_text_repel(
    data = filter(data_cleaned, year == max(year)),
    aes(label = stringr::str_wrap(entity, 25)),
    hjust = 0, xlim = 2024, family = "Cabinet Grotesk", 
    lineheight = .8, segment.linetype = "14", segment.size = .3
  ) +
  scale_x_continuous(breaks = c(seq(1700, 2000, by = 50), 2016)) +
  scale_y_continuous(
    labels = scales::label_comma(scale = 10^-6), breaks = 0:7*5*10^7,
    limits = c(0, 3*10^8)
  ) +
  rcartocolor::scale_color_carto_d(palette = "Bold", guide = "none") +
  coord_cartesian(clip = "off", expand = FALSE) +
  labs(x = NULL, y = "Area of cropland (billion ha)") +
  theme_minimal(base_family = "Cabinet Grotesk") +
  theme(
    axis.text = element_text(family = "Tabular"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 130, 10, 10)
  )

ggsave("./plots/owid_cropland_line.png", width = 9, height = 5, bg = "white", dpi = 600)


## stacked area plot
ggplot(
    data_cleaned, 
    aes(x = year, y = cropland, fill = entity, color = entity)
  ) +
  geom_area(position = "stack") +
  ggrepel::geom_text_repel(
    data = filter(data_cleaned, year == max(year)),
    aes(label = stringr::str_wrap(entity, 25)), position = "stack",
    hjust = 0, xlim = 2024, family = "Cabinet Grotesk",
    lineheight = .8, segment.linetype = "14", segment.size = .3
  ) +
  scale_x_continuous(breaks = c(seq(1700, 2000, by = 50), 2016)) +
  scale_y_continuous(
    labels = scales::label_comma(scale = 10^-6), breaks = 0:8*20*10^7,
    limits = c(0, 1.6*10^9)
  ) +
  rcartocolor::scale_color_carto_d(palette = "Bold", guide = "none") +
  rcartocolor::scale_fill_carto_d(palette = "Bold", guide = "none") +
  coord_cartesian(clip = "off", expand = FALSE) +
  labs(x = NULL, y = "Area of cropland (billion ha)") +
  theme_minimal(base_family = "Cabinet Grotesk") +
  theme(
    axis.text = element_text(family = "Tabular"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 130, 10, 10)
  )

ggsave("./plots/owid_cropland_area.png", width = 9, height = 5, bg = "white", dpi = 600)
