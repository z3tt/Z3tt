ggplot(bikes, aes(x = date, y = count, color = temp_feel)) +
  geom_point(size = .6) +
  # scale_color_viridis_c(option = "cividis")
  # scale_color_gradient(
  #   low = "grey90", high = "firebrick" 
  # )
  # scale_color_gradient2(
  #   low = "firebrick", mid = "grey90", high = "dodgerblue3",
  #   midpoint = 12
  # )
  scico::scale_color_scico(
    palette = "batlow", end = .8, direction = -1
  )





ggplot(bikes, aes(x = weather_type)) +
  geom_bar() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1)
  )


ggplot(bikes, aes(x = weather_type, y = temp)) +
  geom_col()



ggplot(bikes, aes(x = date, y = temp_feel)) +
  geom_point() +
  scale_y_continuous(
    labels = scales::label_number(suffix = "°C"),
    name = "Celsius",
    sec.axis = sec_axis(
      trans = ~ (. * 9/5) + 32,
      labels = scales::label_number(suffix = "°F"),
      name = "Fahrenheit"
    )
  )



data <- readr::read_csv(
  "./data/cropland-extent-over-the-long-run.csv"
)

tibble::glimpse(data)

unique(data$Code)

## base R way of changing class of 1 column
data$Year <- as.integer(data$Year)


## tidy way of changing class of 1 column
data <- mutate(data, Year = as.integer(Year))


data_custom <- 
  data %>% 
  janitor::clean_names() %>% 
  rename("cropland" = cropland_hyde_2017) %>% 
  mutate(
    year = as.integer(year),
    century = year %/% 100 * 100
  ) %>% 
  filter(year >= 1700, entity != "World") %>% 
  arrange(-cropland) %>% 
  select(-code)


data_custom %>% 
  summarize(cropland = mean(cropland))


ggplot(data_custom, aes(x = year, y = cropland, color = entity)) +
  geom_line()

data_custom %>% 
  group_by(entity, century) %>% 
  summarize(cropland = max(cropland)) 

ggplot(data_custom, aes(x = year, y = cropland, color = entity)) +
  geom_line()

ggplot(data_custom, 
       aes(x = year, y = cropland, color = entity)) +
  geom_line() +
  geom_point(
    data = filter(data_custom, year == max(year))
  ) +
  geom_text(
    data = filter(data_custom, year == max(year)),
    aes(label = entity),
    vjust = 0, hjust = 0
  )















