#------------------------------------------------------------------------------#
#                                                                              #
#                          Data Visualization Workshop:                        # 
#                 Plotting with ggplot2 and Exciting Extensions                #
#                                                                              #
#                         Dr. Cédric Scherer |  May 2022                       #
#                                                                              #
#------------------------------------------------------------------------------#


## SETUP -----------------------------------------------------------------------

#install.packages("ggplot2")
#library(ggplot2)

#install.packages("tidyverse")
library(tidyverse)

chic <- readr::read_csv(
  "https://raw.githubusercontent.com/z3tt/ggplot-courses/master/data/chicago-nmmaps-custom.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

# chic <- readr::read_csv(
#   here::here("chicago-nmmaps-custom.csv"),
#   col_types = cols(season = col_factor(), year = col_factor())
# )

glimpse(chic)


## DATA + AESTHETICS -----------------------------------------------------------

?ggplot

ggplot(data = chic)

ggplot(data = chic, aes(x = yday, y = temp))

ggplot(chic, aes(yday, temp))

ggplot(chic, aes(x = yday, y = temp))


## LAYERS ----------------------------------------------------------------------

ggplot(chic, aes(x = yday, y = temp)) +
  geom_point()

ggplot(chic, aes(x = yday, y = temp)) +
  geom_point(
    shape = 4, size = 3
  )

ggplot(chic, aes(x = yday, y = temp)) +
  geom_point(
    aes(color = season),
    shape = 4, size = 3
  )


ggplot(chic, aes(x = yday, y = temp)) +
  geom_area(
    aes(color = year, fill = year),
    alpha = .3
  )

ggplot(chic, aes(x = yday, y = temp)) +
  geom_area(
    aes(color = year, fill = year),
    alpha = .3,
    position = "identity" ## "stack" by default
  )


ggplot(chic, aes(x = yday, y = temp)) +
  geom_point(
    aes(color = season),
    shape = 4, size = 3
  ) +
  geom_smooth()

ggplot(chic, aes(x = yday, y = temp,
                 color = season)) +
  geom_point(
    shape = 4, size = 3
  ) +
  geom_smooth()


ggplot(chic, aes(x = yday, y = temp,
                 color = season)) +
  geom_point(
    shape = 4, size = 3
  ) +
  geom_smooth(
    color = "black"
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = season)) +
  geom_smooth(
    color = "black"
  ) +
  geom_point(
    shape = 4, size = 3
  )


## MISCELLANEOUS ----------------------------------------------------------------

g <-
  ggplot(chic, aes(x = yday, y = temp,
                   color = season)) +
  geom_point(
    size = 2, alpha = .5
  )

g

g +
  geom_smooth(
    color = "black"
  ) +
  geom_rug(
    sides = "r"
  )


ggsave(filename = "my_ggplot.png",
       width = 10, height = 7,
       dpi = 700)

ggsave(filename = "my_ggplot.pdf",
       width = 10, height = 7,
       device = cairo_pdf)


## VISUAL THEMES ---------------------------------------------------------------

g + 
  theme_classic()

g + 
  theme_minimal()

g + 
  theme_bw()

g + 
  theme_dark()

g + 
  theme_light()


theme_set(theme_light())

g


g +
  theme_light(
    base_size = 32,
    base_family = "Consolas"
  )


theme_set(
  theme_light(
    base_size = 32,
    base_family = "Consolas"
  )
)

g


g +
  labs(title = "Seasons in Chicago") +
  theme_light(base_size = 20) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title.position = "plot",
    legend.position = "top",
    axis.text = element_text(
      family = "Roboto Mono"
    )
  )


theme_set(theme_light(base_size = 20))

theme_update(
  panel.grid.minor = element_blank(),
  plot.title.position = "plot", 
  legend.position = "top",
  axis.text = element_text(
    family = "Roboto Mono"
  )
)

g +
  labs(title = "Seasons in Chicago")


## LABELS ----------------------------------------------------------------------

g +
  xlab("Day of the Year") +
  ylab("Temperature (°F)") +
  ggtitle("Seasons in Chicago")

g +
  labs(
    x = "Day of the Year",
    y = "Temperature (°F)",
    title = "Seasons in Chicago"
  )

g +
  labs(
    x = "Day of the Year",
    y = "Temperature (°F)",
    title = "Seasons in Chicago",
    subtitle = "Daily temperatures (°F) in the city of Chicago, IL,\nmeasured between 1997 and 2001",
    caption = "Data: NMMAPS",
    tag = "a)",
    color = NULL
  )


## FACETS ----------------------------------------------------------------------

g +
  facet_wrap(~year)

g +
  facet_wrap(~season)

g +
  facet_wrap(
    ~season,
    scales = "free_x"
  )


g +
  facet_grid(
    year ~ season
  )

g +
  facet_grid(
    year ~ season,
    scales = "free",
    space = "free"
  )


## SCALES ----------------------------------------------------------------------

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(size = 2) +
  scale_x_date() +
  scale_y_continuous()

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(size = 2) +
  scale_x_date(
    name = NULL
  ) +
  scale_y_continuous(
    name = "Temperature (°F)"
  )

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(size = 2) +
  scale_x_date(
    name = NULL
  ) +
  scale_y_continuous(
    name = "Temperature",
    breaks = seq(-10, 100, by = 10),
    labels = function(y) paste0(y, "°F")
  )

ggplot(chic, aes(x = date, y = temp)) +
  geom_point(size = 2) +
  scale_x_date(
    name = NULL,
    date_breaks = "7 months",
    date_labels = "%y/%m"
  ) +
  scale_y_continuous(
    name = "Temperature",
    breaks = seq(-10, 100, by = 10),
    labels = function(y) paste0(y, "°F")
  )


ggplot(chic, aes(x = yday, y = temp,
                 color = season)) +
  geom_point(size = 2) +
  scale_color_manual(
    values = c("#91A3E1", "#83B692", "#F9ADA0", "#CD6FD5")
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = season)) +
  geom_point(size = 2) +
  scale_color_brewer(palette = "Dark2")

ggplot(chic, aes(x = yday, y = temp,
                 fill = year)) +
  geom_area() +
  scale_fill_brewer(palette = "Set3")

ggplot(chic, aes(x = yday, y = temp,
                 color = dewpoint)) +
  geom_point() +
  scale_color_distiller(palette = "Spectral")

ggplot(chic, aes(x = yday, y = temp,
                 color = dewpoint)) +
  geom_point() +
  scale_color_viridis_c(
    option = "magma"
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = dewpoint)) +
  geom_point() +
  scale_color_viridis_c(
    option = "magma",
    begin = .25,
    direction = -1
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = dewpoint)) +
  geom_point() +
  rcartocolor::scale_color_carto_c()

ggplot(chic, aes(x = yday, y = temp,
                 color = temp)) +
  geom_point() +
  rcartocolor::scale_color_carto_c(
    palette = "Sunset",
    guide = "none"
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = temp)) +
  geom_point() +
  rcartocolor::scale_color_carto_c(
    palette = "Sunset",
    guide = "colorsteps"
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = temp)) +
  geom_point() +
  rcartocolor::scale_color_carto_c(
    palette = "Sunset",
    guide = guide_colorsteps()
  )

ggplot(chic, aes(x = yday, y = temp,
                 color = temp)) +
  geom_point() +
  rcartocolor::scale_color_carto_c(
    palette = "Sunset",
    guide = guide_colorsteps(
      barwidth = unit(12, "lines"),
      show.limits = TRUE,
      plot.title.position = "top"
    )
  )



## COORDINATE SYSTEMS ----------------------------------------------------------

g +
  coord_cartesian()

g +
  coord_cartesian(
    ylim = c(35, NA)
  )

g +
  coord_cartesian(
    ylim = c(35, NA),
    expand = FALSE
  )

g +
  coord_cartesian(
    ylim = c(35, NA),
    expand = FALSE,
    clip = "off"
  )

g +
  scale_y_continuous(
    limits = c(35, NA)
  ) +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  )


g + coord_fixed()

g + coord_fixed(ratio = 2)


g + coord_polar()

g + coord_polar(theta = "y", direction = -1)


## ANNOTATIONS -----------------------------------------------------------------

ggplot(chic, aes(x = dewpoint, y = temp)) +
    annotate(
        geom = "rect",
        xmin = 45,
        xmax = Inf,
        ymin = 60,
        ymax = Inf,
        fill = "#EDCBA0",
        color = "firebrick",
        size = 1
    ) +
    geom_point(alpha = .4)

ggplot(chic, aes(x = dewpoint, y = temp)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "text",
    x = 65, y = 10,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  )

ggplot(chic, aes(x = dewpoint, y = temp)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "text",
    x = 65, y = 10,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "curve",
    x = 65, y = 18,
    xend = 51, yend = 49,
    arrow = arrow(length = unit(.5, "cm"))
  )

library(magick)

url <- "https://seeklogo.com/images/C/Chicago-logo-949A99BB67-seeklogo.com.png"
img <- image_read(url)

ggplot(chic, aes(yday, temp)) +
  annotation_custom(
    grid::rasterGrob(
      image = img,
      width = .7
    )
  ) +
  geom_point(color = "red")


## EXTENSION PACKAGES ----------------------------------------------------------

## {ggrepel}

ggplot(filter(chic, temp > 80, dewpoint > 70),
       aes(x = yday, y = temp)) +
  geom_point() +
  geom_text(
    aes(label = year),
    size = 4, fontface = "bold"
  )

ggplot(filter(chic, temp > 80, dewpoint > 70),
       aes(x = yday, y = temp)) +
  geom_point() +
  ggrepel::geom_text_repel(
    aes(label = year),
    size = 4, fontface = "bold"
  )

ggplot(filter(chic, temp > 80, dewpoint > 70),
       aes(x = yday, y = temp)) +
  geom_point() +
  ggrepel::geom_text_repel(
    aes(label = year),
    size = 4, fontface = "bold",
    box.padding = 1,
    arrow = arrow(length = unit(.02, "npc"))
  )


## {ggdist} 

ggplot(chic, aes(x = season, y = temp,
                 fill = season)) +
  ggdist::stat_eye()

ggplot(chic, aes(x = season, y = temp,
                 fill = season)) +
  ggdist::stat_halfeye()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_dots()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_dotsinterval()

ggplot(chic, aes(x = season, y = temp)) +
  ggdist::stat_interval()

ggplot(chic, aes(x = season, y = temp)) +
    ggdist::stat_interval(
        .width = c(.25, .5, .75, 1)
    ) +
    scale_color_viridis_d(
        option = "mako",
        end = .9, direction = -1
    )


## {ggforce}

ggplot(chic, aes(x = temp, y = yday,
                 color = season)) +
  geom_point() +
  ggforce::geom_mark_ellipse(
    aes(label = season)
  )

ggplot(chic, aes(x = temp, y = yday,
                 color = season)) +
  geom_point() +
  ggforce::geom_mark_hull(
    aes(label = season,
        filter = season == "Summer")
  )


## {ggtext}

g +
  labs(
    title = "*My* **Title**",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  )

g +
  labs(
    title = "*My* **Title**",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  ) +
  theme(
    plot.title = ggtext::element_markdown(),
    axis.title.x = ggtext::element_markdown(),
    axis.title.y = ggtext::element_markdown()
  )

g + 
  labs(
    title = "*Integer malesuada nunc __vel risus commodo__ viverra maecenas accumsan lacus*.",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  ) +
  theme(
    plot.title = element_textbox_simple(),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown() 
  )

g + 
  labs(
    title = "*Integer malesuada nunc __vel risus commodo__ viverra maecenas accumsan lacus*.",
    x = "<i style='color:red;'>Temperature</i> (°F)",
    y = "<b style='font-family:lora;'>Ozone</b> Levels"
  ) +
  theme(
    plot.title = element_textbox_simple(
      fill = "#EDCBA0",
      r = unit(5, "pt"), 
      halign = .5,
      padding = margin(5, 1, 3, 1), 
      margin = margin(0, 1, 3, 1)
    ),
    axis.title.x = element_markdown(),
    axis.title.y = element_markdown() 
  )


## {patchwork}

(time <- 
  ggplot(chic, aes(x = date, y = temp)) +
  geom_point())

(summary <- 
  ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot())

library(patchwork)

time + summary

time / summary

time + summary +
  plot_layout(widths = c(1, 2))

time + summary + 
  plot_layout(design = "A#BB")


my_layout <- "
A#BB#
ACC##
DDDDD
"

time + summary + time + summary + 
  plot_layout(design = my_layout)


(time + summary) *
  theme_minimal()

(time + summary) *
  theme(axis.title = element_text(color = "red"))

time + summary +
  plot_annotation(
    title = "My very veeeeery long title spanning both plots",
    tag_levels = "A",
    tag_suffix = ")"
  )


## END -------------------------------------------------------------------------
