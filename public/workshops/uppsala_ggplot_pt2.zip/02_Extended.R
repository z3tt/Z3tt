################################################################################
#                          LS Uppsala DataViz Course                           #
#  "Data Visualization with ggplot2: Extended Use of the Grammar of Graphics"  #
#                     Cédric Scherer | December 13, 2022                       #
################################################################################



## SETUP -----------------------------------------------------------------------

## to run all codes, install the following typefaces and restart RStudio:
## Roboto Condensed, Cabinet Grotesk, Tabular (files located in the `fonts` folder) 

## also, make sure to install the following packages 
packages <- c(
  "tidyverse", "scales", "here", "systemfonts", "RColorBrewer",
  "ggtext", "ggrepel", "patchwork", "rcartocolor", "colorspace",
  "magick", "grid", "palmerpenguins"
)

install.packages(setdiff(packages, rownames(installed.packages())))

## ---------------------------------------------------------------------------------------------------------------
# install.packages("ggplot2")
# library(ggplot2)


## ---------------------------------------------------------------------------------------------------------------
# install.packages("tidyverse")
library(tidyverse)


## ---------------------------------------------------------------------------------------------------------------
bikes <- readr::read_csv(
  "./data/london-bikes-custom.csv",
  ## or: here::here("data", "london-bikes-custom.csv"),
  ## or: "https://cedricscherer.com/data/london-bikes-custom.csv"
  col_types = "Dcfffilllddddc"
)

bikes$season <- forcats::fct_inorder(bikes$season)


## ---------------------------------------------------------------------------------------------------------------
theme_set(theme_light(
  base_size = 14, base_line_size = .5, base_family = "Roboto Condensed"
))

theme_update(
  panel.grid.minor = element_blank(),
  legend.position = "top",
  plot.title.position = "plot"
)


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(x = temp_feel, y = count)) +
  stat_smooth(geom = "smooth")


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(x = temp_feel, y = count)) +
  geom_smooth(stat = "smooth")


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = temp_feel)) +
  geom_point(stat = "identity")


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = temp_feel)) +
  stat_identity(geom = "point")


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(x = is_weekend)) +
  geom_bar(stat = "count")


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(x = is_weekend)) +
  stat_count(geom = "bar")


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  stat_summary() 


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "pointrange"  ## the default
  ) 


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  geom_boxplot() +
  stat_summary(
    fun = mean,
    geom = "point",
    color = "#28a87d",
    size = 3
  ) 


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  stat_summary() +
  stat_summary(
    fun = mean,
    geom = "text",
    aes(label = after_stat(y))
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  stat_summary() +
  stat_summary(
    fun = mean,
    geom = "text",
    aes(label = after_stat(
      paste0(round(y, 2), "°C"))
    ),
    hjust = -.2,
    family = "Tabular",
    size = 3
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  stat_summary(
    fun = mean, 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y) 
  ) 


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1)
  ) 


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel,
        color = year)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1)
  ) 


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp_feel,
        color = year)
  ) +
  stat_summary(
    fun.data = mean_sdl, 
    fun.args = list(mult = 1),
    position = position_dodge(
      width = .25
    )
  ) 


## ---------------------------------------------------------------------------------------------------------------
g <- 
  ggplot(
    bikes,
    aes(x = temp_feel, y = count,
        color = season)
  ) +
  geom_point(
    alpha = .5
  ) +
  labs(
    x = "Feels Like temperature (°F)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    caption = "Data: TfL",
    color = NULL
  )

g


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle(
    "**TfL bike sharing trends by _season_**"
  )


## ---------------------------------------------------------------------------------------------------------------
library(ggtext)

g +
  ggtitle("**TfL bike sharing trends by _season_**") +
  theme(
    plot.title = element_markdown()
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle("<b style='font-family:tabular;font-size:25pt'>TfL</b> bike sharing trends by <i style='color:#28a87d;'>season</i>") +
  theme(
    plot.title = element_markdown()
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = weather_type,
        y = count)
  ) +
  geom_boxplot()


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = str_wrap(weather_type, 6),
        y = count)
  ) +
  geom_boxplot()


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_text(size = 20),
    plot.title.position = "plot"
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      size = 20
    ),
    plot.title.position = "plot"
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      margin = margin(t = 12, b = 12),
      lineheight = .95
    ),
    plot.title.position = "plot"
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      margin = margin(t = 12, b = 12),
      fill = "grey90",
      lineheight = .95
    ),
    plot.title.position = "plot"
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  ggtitle("TfL bike sharing trends in 2015 and 2016 by season for day and night periods") +
  theme(
    plot.title = element_textbox_simple(
      margin = margin(t = 12, b = 12),
      padding = margin(rep(12, 4)),
      fill = "grey90",
      box.color = "grey40",
      r = unit(9, "pt"),
      halign = .5,
      face = "bold",
      lineheight = .95
    ),
    plot.title.position = "plot"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = 90,
    y = 27.5,
    label = "Some\nadditional\ntext"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = 90,
    y = 27.5,
    label = "Some\nadditional\ntext",
    family = "Tabular",
    size = 6,
    color = "firebrick",
    fontface = "bold",
    lineheight = .9
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = c(90, 50),
    y = c(27.5, 3.5),
    label = c("Text A", "Text B"),
    family = c("Tabular", "Roboto Condensed"),
    color = c("black", "firebrick"),
    size = c(5, 10),
    fontface = c("plain", "bold")
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  ggtext::geom_richtext(
    aes(x = 82, y = 27.5),
    label = "Some<br><b style='color:red;font-size:24pt;'>additional</b><br>text",
    stat = "unique",
    family = "Tabular",
    size = 6,
    color = "grey30",
    fontface = "bold",
    lineheight = .9
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = 90,
    y = 27.5,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "segment",
    x = 90, xend = 82,
    y = 25, yend = 18.5
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = 90,
    y = 27.5,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "curve",
    x = 90, xend = 82,
    y = 25, yend = 18.5
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = 90,
    y = 27.5,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "curve",
    x = 90, xend = 82,
    y = 25, yend = 18.5,
    curvature = -.3,
    arrow = arrow()
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "text",
    x = 90,
    y = 27.5,
    label = "Some\nadditional\ntext",
    size = 6,
    lineheight = .9
  ) +
  annotate(
    geom = "curve",
    x = 90, xend = 82,
    y = 25, yend = 18.5,
    curvature = -.3,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed",
      ends = "both"
    )
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  geom_point(size = 2, color = "grey") +
  annotate(
    geom = "rect",
    xmin = -Inf,
    xmax = 60,
    ymin = 20,
    ymax = Inf,
    fill = "#663399"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(humidity, temp)) +
  annotate(
    geom = "rect",
    xmin = -Inf,
    xmax = 60,
    ymin = 20,
    ymax = Inf,
    fill = "#663399"
  ) +
  geom_point(size = 2, color = "grey")


## ---------------------------------------------------------------------------------------------------------------
url <- "https://i0.wp.com/innovationtoronto.com/wp-content/uploads/2018/10/uppsalalogo.png"
img <- magick::image_read(url)
img


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(date, temp_feel)) +
  annotation_custom(
    grid::rasterGrob(
      image = img
    )
  ) +
  geom_point(color = "#BF1F32")


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(date, temp_feel)) +
  annotation_custom(
    grid::rasterGrob(
      image = img,
      x = .5,
      y = .8,
      width = .9
    )
  ) +
  geom_point(color = "#BF1F32") +
  ylim(NA, 50) 


## ---------------------------------------------------------------------------------------------------------------
ggplot(bikes, aes(date, temp_feel)) +
  annotation_custom(
    grid::rasterGrob(
      image = img,
      x = .47,
      y = 1.25,
      width = .9
    )
  ) +
  geom_point(color = "#BF1F32") +
  coord_cartesian(clip = "off") +
  theme(
    plot.margin = margin(130, 10, 10, 10)
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5)


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5) +
  geom_text(
    aes(label = season),
    nudge_x = .3,
    hjust = 0
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5) +
  geom_label(
    aes(label = season),
    nudge_x = .3,
    hjust = 0
  )


## ---------------------------------------------------------------------------------------------------------------
set.seed(2022)


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5) +
  ggrepel::geom_text_repel(
    aes(label = season)
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp,
        color = season == "summer")
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5) +
  ggrepel::geom_text_repel(
    aes(label = stringr::str_to_title(season))
  ) +
  scale_color_manual(
    values = c("firebrick", "black"),
    guide = "none"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp,
        color = season == "summer")
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5) +
  ggrepel::geom_text_repel(
    aes(label = stringr::str_to_title(season)),
    ## space between points + labels
    box.padding = .4,
    ## always draw segments
    min.segment.length = 0
  ) +
  scale_color_manual(
    values = c("firebrick", "black"),
    guide = "none"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp >= 27),
    aes(x = humidity, y = temp,
        color = season == "summer")
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point(size = 2.5) +
  ggrepel::geom_text_repel(
    aes(label = stringr::str_to_title(season)),
    ## force to the right
    xlim = c(NA, 35),
    ## style segment
    segment.curvature = .001,
    segment.inflect = TRUE
  ) +
  scale_color_manual(
    values = c("firebrick", "black"),
    guide = "none"
  ) +
  xlim(25, NA)


## ---------------------------------------------------------------------------------------------------------------
g + 
  theme(
    plot.background = element_rect(
      color = "orange",
      fill = "black",
      size = 2,
      linetype = "dotted"
    ),
    axis.text = element_text( 
      family = "Tabular",
      color = "blue",
      angle = 15,
      size = 30
    )
  )


## ---------------------------------------------------------------------------------------------------------------
library(systemfonts)

register_variant(
  name = "Cabinet Grotesk Black",
  family = "Cabinet Grotesk", 
  weight = "heavy",
  features = font_feature(letters = "stylistic")
)

g +
  theme(
    plot.title = element_text(
      family = "Cabinet Grotesk Black"
    ),
    axis.title = element_text(
      family = "Cabinet Grotesk",
      face = "bold"
    )
  )


## ---------------------------------------------------------------------------------------------------------------
theme_grey


## ---------------------------------------------------------------------------------------------------------------
theme_minimal


## ---------------------------------------------------------------------------------------------------------------
theme_custom <- function(base_size = 15, base_family = "Cabinet Grotesk", ...) { 
  theme_bw(base_size = base_size, base_family = base_family, 
           base_line_size = base_size / 30, ...) %+replace%
  theme(
    axis.ticks = element_blank(), 
    axis.text = element_text(size = base_size * .8),
    legend.text = element_text(size = base_size * .8),
    legend.background = element_blank(), 
    legend.key = element_blank(), 
    legend.position = "top", 
    panel.background = element_rect(fill = "grey97", color = NA), 
    panel.border = element_blank(), 
    panel.grid.major = element_line(color = "grey88"), 
    panel.grid.minor = element_blank(), 
    strip.background = element_blank(), 
    plot.background = element_blank(), 
    plot.title = ggtext::element_textbox_simple( 
      face = "bold", color = "black", fill = "grey97", 
      size = base_size * 1.4, r = unit(.5, "lines"), 
      margin = margin(25, 0, 25, 0), padding = margin(rep(8, 4)) 
    ), 
    plot.title.position = "plot", 
    complete = TRUE
  )
}


## ---------------------------------------------------------------------------------------------------------------
g + theme_custom()


## ---------------------------------------------------------------------------------------------------------------
g +
  labs(
    title = "I went to <b style='color:#28a87d;'>Cédric's ggplot2 course</b> and now I know how to build my own special <span style=font-family:tabular;>ggplot2</span> theme!"
  ) +
  theme_custom()


## ---------------------------------------------------------------------------------------------------------------
g +
  labs(
    title = "I went to <b style='color:#28a87d;'>Cédric's ggplot2 course</b> and now I know how to build my own <span style=font-family:tabular;>ggplot2</span> theme!"
  ) +
  theme_custom(
    base_size = 11, base_family = "Chubbo"
  ) +
  theme(legend.position = "right")


## ---------------------------------------------------------------------------------------------------------------
(time <- ggplot(bikes, aes(date, temp_feel)) +
  geom_point(aes(color = season)) +
  scale_color_brewer(palette = "Set1", 
                     guide = "none"))


## ---------------------------------------------------------------------------------------------------------------
(box <- ggplot(bikes, aes(temp_feel, season)) +
  geom_boxplot(aes(color = season)) +
  scale_color_brewer(palette = "Set1", 
                     guide = "none"))


## ---------------------------------------------------------------------------------------------------------------
library(patchwork)
time + box


## ---------------------------------------------------------------------------------------------------------------
time / box


## ---------------------------------------------------------------------------------------------------------------
time + box + plot_layout(widths = c(2, 1))


## ---------------------------------------------------------------------------------------------------------------
time + plot_spacer() + box + plot_layout(widths = c(2, .5, 1))


## ---------------------------------------------------------------------------------------------------------------
scatter <- 
  ggplot(
    bikes, 
    aes(temp_feel, humidity)
  ) +
  geom_point(aes(color = season)) +
  scale_color_brewer(
    palette = "Set1", 
    guide = "none"
  )

(scatter + box) / time + 
  plot_layout(heights = c(2, 1))


## ---------------------------------------------------------------------------------------------------------------
layout <- "
  AAAAA#
  BB####
  BB#CCC
  BB#CCC
"

time + scatter + box + 
  plot_layout(design = layout)


## ---------------------------------------------------------------------------------------------------------------
scatter <- 
  ggplot(
    bikes, 
    aes(temp_feel, humidity)
  ) +
  geom_point(aes(color = season)) +
  scale_color_brewer(
    palette = "Set1"#, 
    #guide = "none"
  )

theme_update(legend.position = "right")

(scatter + box) / time + 
  plot_layout(heights = c(2, 1))


## ---------------------------------------------------------------------------------------------------------------
(scatter + box) / time + 
  plot_layout(
    heights = c(2, 1),
    guides = "collect"
  )


## ---------------------------------------------------------------------------------------------------------------
(scatter + box) / time + 
  plot_layout(
    heights = c(2, 1),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL"
  )


## ---------------------------------------------------------------------------------------------------------------
scatter_t <- scatter + ggtitle("Title A that is pretty long")
box_t <- box + ggtitle("Title B")

(scatter_t + box_t) / time + 
  plot_layout(
    heights = c(2, 1),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL"
  )


## ---------------------------------------------------------------------------------------------------------------
(scatter + box) / time +
  plot_layout(
    heights = c(2, 1),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A"
  )


## ---------------------------------------------------------------------------------------------------------------
time / (scatter + box) + 
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A",
    tag_suffix = ")",
  )


## ---------------------------------------------------------------------------------------------------------------
time / (scatter + box) + 
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "A",
    tag_prefix = "(",
    tag_suffix = ")"
  )


## ---------------------------------------------------------------------------------------------------------------
time / (scatter + box) + 
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Temperature & Ozone in Chicago, IL",
    tag_levels = "a",
    tag_prefix = "Fig. 1"
  )


## ---------------------------------------------------------------------------------------------------------------
scatter + inset_element(box, left = .01, bottom = .6, right = .25, top = .99) 


## ---------------------------------------------------------------------------------------------------------------
scatter + inset_element(box + labs(x = NULL, y = NULL), .01, .6, .25, .99) 


## ---------------------------------------------------------------------------------------------------------------
library(rcartocolor)

ggplot(
    bikes, 
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  rcartocolor::scale_fill_carto_d(
    name = "Vivid" 
  )


## ---------------------------------------------------------------------------------------------------------------
library(rcartocolor)

ggplot(
    bikes, 
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = carto_pal(
      name = "Vivid", n = 4
    )
  )


## ---------------------------------------------------------------------------------------------------------------
library(rcartocolor)

ggplot(
    bikes, 
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = carto_pal(
      name = "Vivid", n = 5
    )[1:4]
  )


## ---------------------------------------------------------------------------------------------------------------
library(rcartocolor)

ggplot(
    bikes, 
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = carto_pal(
      name = "Vivid", n = 6
    )[c(1, 3:5)]
  )


## ---------------------------------------------------------------------------------------------------------------
carto_custom <- 
  carto_pal(
    name = "Vivid", n = 6
  )[c(1, 3:5)]

ggplot(
    bikes, 
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = carto_custom
  )


## ---------------------------------------------------------------------------------------------------------------
library(colorspace)

carto_light <- lighten(carto_custom, .8)

ggplot(
    bikes, 
    aes(x = day_night, y = count, 
        fill = season)
  ) +
  geom_boxplot() +
  scale_fill_manual(
    values = carto_light
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(fill = season,
        fill = after_scale(
          lighten(fill, .8)
    ))
  ) +
  scale_fill_manual(
    values = carto_custom
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(
      fill = stage(
        season,
        after_scale =
          lighten(fill, .8)
      )
    )
  ) +
  scale_fill_manual(
    values = carto_custom
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .8)
    ))
  ) +
  scale_color_manual(
    values = carto_custom
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .8)
    )),
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season), 
    position = position_jitterdodge(
      dodge.width = .75, 
      jitter.width = .2
    ),
    alpha = .4
  ) +
  scale_color_manual(
    values = carto_custom
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .8)
        )),
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season,
        color = after_scale(
          darken(color, .3)
    )), 
    position = position_jitterdodge(
      dodge.width = .75, 
      jitter.width = .2
    ),
    alpha = .4
  ) +
  scale_color_manual(
    values = carto_custom
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = day_night, y = count)
  ) +
  geom_boxplot(
    aes(color = season,
        fill = after_scale(
          lighten(color, .8)
        )),
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season,
        color = after_scale(
          darken(color, .3)
        )), 
    position = position_jitterdodge(
      dodge.width = .75, 
      jitter.width = .2
    ),
    alpha = .4
  ) +
  scale_color_manual(
    values = carto_custom
  )




## ---------------------------------------------------------------------------------------------------------------
# install.packages("palmerpenguins")
library(palmerpenguins)
penguins


## ---------------------------------------------------------------------------------------------------------------
## ggplot(
##     penguins,
##     aes(x = bill_length_mm, y = bill_depth_mm,
##         color = species, size = body_mass_g)
##   ) +
##   geom_point(alpha = .2) +
##   labs(
##     x = "Bill length (mm)",
##     y = "Bill depth (mm)",
##     title = "Bill dimensions of brush-tailed penguins Pygoscelis spec.",
##     caption = "Horst AM, Hill AP, Gorman KB (2020). palmerpenguins R package version 0.1.0"
##   )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    penguins,
    aes(x = bill_length_mm, y = bill_depth_mm,
        color = species, size = body_mass_g)
  ) +
  geom_point(alpha = .2) +
  labs(
    x = "Bill length (mm)",
    y = "Bill depth (mm)",
    title = "Bill dimensions of brush-tailed penguins Pygoscelis spec.",
    caption = "Horst AM, Hill AP, Gorman KB (2020). palmerpenguins R package version 0.1.0"
  )


## ---------------------------------------------------------------------------------------------------------------
## ggplot(
##     penguins,
##     aes(x = bill_length_mm, y = bill_depth_mm,
##         color = species, size = body_mass_g)
##   ) +
##   geom_point(alpha = .2) +
##   labs(
##     x = "Bill length (mm)",
##     y = "Bill depth (mm)",
##     title = "Bill dimensions of brush-tailed penguins Pygoscelis spec.",
##     caption = "Horst AM, Hill AP, Gorman KB (2020). palmerpenguins R package version 0.1.0"
##   ) +
##   theme_minimal(base_size = 10, base_family = "Roboto Condensed") +
##   theme(
##     plot.title.position = "plot",
##     plot.caption.position = "plot",
##     panel.grid.minor = element_blank()
##   )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    penguins,
    aes(x = bill_length_mm, y = bill_depth_mm,
        color = species, size = body_mass_g)
  ) +
  geom_point(alpha = .2) +
  labs(
    x = "Bill length (mm)",
    y = "Bill depth (mm)",
    title = "Bill dimensions of brush-tailed penguins Pygoscelis spec.",
    caption = "Horst AM, Hill AP, Gorman KB (2020). palmerpenguins R package version 0.1.0"
  ) +
  theme_minimal(base_size = 10, base_family = "Roboto Condensed") +
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    panel.grid.minor = element_blank()
  )


## ---------------------------------------------------------------------------------------------------------------
## p1 <-
##   ggplot(
##     penguins,
##     aes(x = bill_length_mm, y = bill_depth_mm,
##         color = species, size = body_mass_g)
##   ) +
##   geom_point(alpha = .2, stroke = .3) +
##   geom_point(shape = 1, stroke = .3) +
##   labs(
##     x = "Bill length (mm)",
##     y = "Bill depth (mm)",
##     title = "Bill dimensions of brush-tailed penguins Pygoscelis spec.",
##     caption = "Horst AM, Hill AP, Gorman KB (2020). palmerpenguins R package version 0.1.0"
##   ) +
##   theme_minimal(base_size = 10, base_family = "Roboto Condensed") +
##   theme(
##     plot.title.position = "plot",
##     plot.caption.position = "plot",
##     panel.grid.minor = element_blank()
##   )
## p1


## ---------------------------------------------------------------------------------------------------------------
p1 <-
  ggplot(
    penguins,
    aes(x = bill_length_mm, y = bill_depth_mm,
        color = species, size = body_mass_g)
  ) +
  geom_point(alpha = .2, stroke = .3) +
  geom_point(shape = 1, stroke = .3) +
  labs(
    x = "Bill length (mm)",
    y = "Bill depth (mm)",
    title = "Bill dimensions of brush-tailed penguins Pygoscelis spec.",
    caption = "Horst AM, Hill AP, Gorman KB (2020). palmerpenguins R package version 0.1.0"
  ) +
  theme_minimal(base_size = 10, base_family = "Roboto Condensed") +
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    panel.grid.minor = element_blank()
  )
p1


## ---------------------------------------------------------------------------------------------------------------
## p1 +
##   scale_color_manual(
##     name = "Species:",
##     values = c("#FF8C00", "#A034F0", "#159090")
##   )


## ---------------------------------------------------------------------------------------------------------------
p1 +
  scale_color_manual(
    name = "Species:",
    values = c("#FF8C00", "#A034F0", "#159090")
  )


## ---------------------------------------------------------------------------------------------------------------
## p2 <- p1 +
##   scale_color_manual(
##     name = "Species:",
##     values = c("#FF8C00", "#A034F0", "#159090")
##   ) +
##   scale_size(
##     name = "Body mass:",
##     breaks = 3:6 * 1000,
##     labels = function(x) paste(x / 1000, "kg"),
##     range = c(.5, 5)
##   )
## p2


## ---------------------------------------------------------------------------------------------------------------
p2 <- p1 +
  scale_color_manual(
    name = "Species:",
    values = c("#FF8C00", "#A034F0", "#159090")
  ) +
  scale_size(
    name = "Body mass:",
    breaks = 3:6 * 1000,
    labels = function(x) paste(x / 1000, "kg"),
    range = c(.5, 5)
  )
p2


## ---------------------------------------------------------------------------------------------------------------
## p2 +
##   scale_x_continuous(
##     limits = c(30, 60),
##     breaks = 6:12*5,
##     expand = c(0, 0)
##   ) +
##   scale_y_continuous(
##     limits = c(12.5, 22.5),
##     breaks = seq(12.5, 22.5, by = 2.5),
##     expand = c(0, 0)
##   )


## ---------------------------------------------------------------------------------------------------------------
p2 +
  scale_x_continuous(
    limits = c(30, 60),
    breaks = 6:12*5,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(12.5, 22.5),
    breaks = seq(12.5, 22.5, by = 2.5),
    expand = c(0, 0)
  )


## ---------------------------------------------------------------------------------------------------------------
## p3 <- p2 +
##   coord_cartesian(
##     expand = FALSE,
##     clip = "off"
##   ) +
##   scale_x_continuous(
##     limits = c(30, 60),
##     breaks = 6:12*5
##   ) +
##   scale_y_continuous(
##     limits = c(12.5, 22.5),
##     breaks = seq(12.5, 22.5, by = 2.5)
##   )
## p3


## ---------------------------------------------------------------------------------------------------------------
p3 <- p2 +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  ) +
  scale_x_continuous(
    limits = c(30, 60),
    breaks = 6:12*5
  ) +
  scale_y_continuous(
    limits = c(12.5, 22.5),
    breaks = seq(12.5, 22.5, by = 2.5)
  )
p3


## ---------------------------------------------------------------------------------------------------------------
## p2 +
##   coord_fixed(
##     expand = FALSE,
##     clip = "off"
##   ) +
##   scale_x_continuous(
##     limits = c(30, 60),
##     breaks = 6:12*5
##   ) +
##   scale_y_continuous(
##     limits = c(12.5, 22.5),
##     breaks = seq(12.5, 22.5, by = 2.5)
##   )


## ---------------------------------------------------------------------------------------------------------------
p2 +
  coord_fixed(
    expand = FALSE,
    clip = "off"
  ) +
  scale_x_continuous(
    limits = c(30, 60),
    breaks = 6:12*5
  ) +
  scale_y_continuous(
    limits = c(12.5, 22.5),
    breaks = seq(12.5, 22.5, by = 2.5)
  )


## ---------------------------------------------------------------------------------------------------------------
## p3 +
##   labs(
##     x = "Bill length *(mm)*",
##     y = "Bill depth *(mm)*",
##     title = "Bill dimensions of brush-tailed penguins *Pygoscelis spec.*",
##     caption = "Horst AM, Hill AP, Gorman KB (2020). <span style='font-family:tabular;'>palmerpenguins</span> R package version 0.1.0"
##   )


## ---------------------------------------------------------------------------------------------------------------
p3 +
  labs(
    x = "Bill length *(mm)*",
    y = "Bill depth *(mm)*",
    title = "Bill dimensions of brush-tailed penguins *Pygoscelis spec.*",
    caption = "Horst AM, Hill AP, Gorman KB (2020). <span style='font-family:tabular;'>palmerpenguins</span> R package version 0.1.0"
  )


## ---------------------------------------------------------------------------------------------------------------
## library(ggtext)
## p4 <- p3 +
##   labs(
##     x = "Bill length *(mm)*",
##     y = "Bill depth *(mm)*",
##     title = "Bill dimensions of brush-tailed penguins *Pygoscelis spec.*",
##     caption = "Horst AM, Hill AP, Gorman KB (2020). <span style='font-family:tabular;'>palmerpenguins</span> R package version 0.1.0"
##   ) +
##   theme(
##     plot.title = element_markdown(
##       face = "bold", size = 16, margin = margin(12, 0, 12, 0)
##     ),
##     plot.caption = element_markdown(
##       size = 7, color = "grey50", margin = margin(12, 0, 6, 0)
##     ),
##     axis.title.x = element_markdown(margin = margin(t = 8)),
##     axis.title.y = element_markdown(margin = margin(r = 8))
##   )
## p4


## ---------------------------------------------------------------------------------------------------------------
library(ggtext)
p4 <- p3 +
  labs(
    x = "Bill length *(mm)*",
    y = "Bill depth *(mm)*",
    title = "Bill dimensions of brush-tailed penguins *Pygoscelis spec.*",
    caption = "Horst AM, Hill AP, Gorman KB (2020). <span style='font-family:tabular;'>palmerpenguins</span> R package version 0.1.0"
  ) +
  theme(
    plot.title = element_markdown(
      face = "bold", size = 16, margin = margin(12, 0, 12, 0)
    ),
    plot.caption = element_markdown(
      size = 7, color = "grey50", margin = margin(12, 0, 6, 0)
    ),
    axis.title.x = element_markdown(margin = margin(t = 8)),
    axis.title.y = element_markdown(margin = margin(r = 8))
  )
p4


## ---------------------------------------------------------------------------------------------------------------
## p5 <- p4 +
##   theme(
##     axis.text = element_text(family = "Tabular"),
##     legend.text = element_text(color = "grey50"),
##     plot.margin = margin(0, 14, 0, 12),
##     plot.background = element_rect(fill = NA, color = "grey50", size = 1)
##   )
## p5


## ---------------------------------------------------------------------------------------------------------------
p5 <- p4 +
  theme(
    axis.text = element_text(family = "Tabular"),
    legend.text = element_text(color = "grey50"),
    plot.margin = margin(0, 14, 0, 12),
    plot.background = element_rect(fill = NA, color = "grey50", size = 1)
  )
p5


## ---------------------------------------------------------------------------------------------------------------
library(dplyr)

penguins_labs <-
  penguins %>%
  group_by(species) %>%
  summarize(across(starts_with("bill"), ~ mean(.x, na.rm = TRUE))) %>%
  mutate(
    species_lab = case_when(
      species == "Adelie" ~ "<b style='font-size:15pt;'>*P. adéliae*</b><br>(Adélie penguin)",
      species == "Chinstrap" ~ "<b style='font-size:15pt;'>*P. antarctica*</b><br>(Chinstrap penguin)",
      species == "Gentoo" ~ "<b style='font-size:15pt;'>*P. papua*</b><br>(Gentoo penguin)"
    )
  )

penguins_labs


## ---------------------------------------------------------------------------------------------------------------
## p5 +
##   geom_richtext(
##     data = penguins_labs,
##     aes(label = species_lab),
##     color = "black", size = 3
##   )


## ---------------------------------------------------------------------------------------------------------------
p5 +
  geom_richtext(
    data = penguins_labs,
    aes(label = species_lab),
    color = "black", size = 3
  )


## ---------------------------------------------------------------------------------------------------------------
## p5 +
##   geom_richtext(
##     data = penguins_labs,
##     aes(label = species_lab),
##     color = "black", size = 3,
##     family = "Roboto Condensed",
##     lineheight = .8,
##     fill = "#ffffffab", ## hex-alpha code
##     show.legend = FALSE
##   )


## ---------------------------------------------------------------------------------------------------------------
p5 +
  geom_richtext(
    data = penguins_labs,
    aes(label = species_lab),
    color = "black", size = 3,
    family = "Roboto Condensed",
    lineheight = .8,
    fill = "#ffffffab", ## hex-alpha code
    show.legend = FALSE
  )


## ---------------------------------------------------------------------------------------------------------------
## p5 +
##   geom_richtext(
##     data = penguins_labs,
##     aes(label = species_lab,
##         color = species,
##         color = after_scale(colorspace::darken(color, .4))),
##     family = "Roboto Condensed",
##     size = 3, lineheight = .8,
##     fill = "#ffffffab",
##     show.legend = FALSE
##   )


## ---------------------------------------------------------------------------------------------------------------
p5 +
  geom_richtext(
    data = penguins_labs,
    aes(label = species_lab,
        color = species,
        color = after_scale(colorspace::darken(color, .4))),
    family = "Roboto Condensed",
    size = 3, lineheight = .8,
    fill = "#ffffffab",
    show.legend = FALSE
  )


## ---------------------------------------------------------------------------------------------------------------
## p5 +
##   geom_richtext(
##     data = penguins_labs,
##     aes(label = species_lab,
##         color = species,
##         color = after_scale(colorspace::darken(color, .4))),
##     family = "Roboto Condensed",
##     size = 3, lineheight = .8,
##     fill = "#ffffffab", ## hex-alpha code
##     show.legend = FALSE
##   ) +
##   scale_color_manual(
##     guide = "none",
##     values = c("#FF8C00", "#A034F0", "#159090")
##   )


## ---------------------------------------------------------------------------------------------------------------
p5 +
  geom_richtext(
    data = penguins_labs,
    aes(label = species_lab,
        color = species,
        color = after_scale(colorspace::darken(color, .4))),
    family = "Roboto Condensed",
    size = 3, lineheight = .8,
    fill = "#ffffffab", ## hex-alpha code
    show.legend = FALSE
  ) +
  scale_color_manual(
    guide = "none",
    values = c("#FF8C00", "#A034F0", "#159090")
  )


## ---------------------------------------------------------------------------------------------------------------
## library(tidyverse)
## library(palmerpenguins)
## library(ggtext)
## 
## penguins_labs <-
##   penguins %>%
##   group_by(species) %>%
##   summarize(across(starts_with("bill"), ~ mean(.x, na.rm = TRUE))) %>%
##   mutate(
##     species_lab = case_when(
##       species == "Adelie" ~ "<b style='font-size:15pt;'>*P. adéliae*</b><br>(Adélie penguin)",
##       species == "Chinstrap" ~ "<b style='font-size:15pt;'>*P. antarctica*</b><br>(Chinstrap penguin)",
##       species == "Gentoo" ~ "<b style='font-size:15pt;'>*P. papua*</b><br>(Gentoo penguin)"
##     )
##   )
## 
## ggplot(
##     penguins,
##     aes(x = bill_length_mm, y = bill_depth_mm,
##         color = species, size = body_mass_g)
##   ) +
##   geom_point(alpha = .2, stroke = .3) +
##   geom_point(shape = 1, stroke = .3) +
##   geom_richtext(
##     data = penguins_labs,
##     aes(label = species_lab,
##         color = species,
##         color = after_scale(colorspace::darken(color, .4))),
##     family = "Roboto Condensed",
##     size = 3, lineheight = .8,
##     fill = "#ffffffab", ## hex-alpha code
##     show.legend = FALSE
##   ) +
##   coord_cartesian(
##     expand = FALSE,
##     clip = "off"
##   )  +
##   scale_x_continuous(
##     limits = c(30, 60),
##     breaks = 6:12*5
##   ) +
##   scale_y_continuous(
##     limits = c(12.5, 22.5),
##     breaks = seq(12.5, 22.5, by = 2.5)
##   ) +
##   scale_color_manual(
##     guide = "none",
##     values = c("#FF8C00", "#A034F0", "#159090")
##   ) +
##   scale_size(
##     name = "Body mass:",
##     breaks = 3:6 * 1000,
##     labels = function(x) paste(x / 1000, "kg"),
##     range = c(.25, 4.5)
##   ) +
##   labs(
##     x = "Bill length *(mm)*",
##     y = "Bill depth *(mm)*",
##     title = "Bill dimensions of brush-tailed penguins *Pygoscelis spec.*",
##     caption = "Horst AM, Hill AP, Gorman KB (2020). <span style='font-family:tabular;'>palmerpenguins</span> R package version 0.1.0"
##   ) +
##   theme_minimal(
##     base_size = 10, base_family = "Roboto Condensed"
##   ) +
##   theme(
##     plot.title = element_markdown(
##       face = "bold", size = 16, margin = margin(12, 0, 12, 0)
##     ),
##     plot.title.position = "plot",
##     plot.caption = element_markdown(
##       size = 7, color = "grey50",
##       margin = margin(12, 0, 6, 0)
##     ),
##     plot.caption.position = "plot",
##     axis.text = element_text(family = "Tabular"),
##     axis.title.x = element_markdown(margin = margin(t = 8)),
##     axis.title.y = element_markdown(margin = margin(r = 8)),
##     panel.grid.minor = element_blank(),
##     legend.text = element_text(color = "grey50"),
##     plot.margin = margin(0, 14, 0, 12),
##     plot.background = element_rect(fill = NA, color = "grey50", size = 1)
##   )




## ---------------------------------------------------------------------------------------------------------------
## register_variant(
##   name = "Cabinet Grotesk Regular S01",
##   family = "Cabinet Grotesk",
##   weight = "normal",
##   features = font_feature(letters = "stylistic")
## )
## 
## register_variant(
##   name = "Cabinet Grotesk Bold S01",
##   family = "Cabinet Grotesk",
##   weight = "bold",
##   features = font_feature(letters = "stylistic")
## )
## 
## register_variant(
##   name = "Cabinet Grotesk Black S01",
##   family = "Cabinet Grotesk",
##   weight = "heavy",
##   features = font_feature(letters = "stylistic")
## )
## 
## codes <- c(
##   `FALSE` = "Workday",
##   `TRUE` = "Weekend or Holiday"
## )
## 
## ggplot(bikes, aes(temp_feel, count)) +
##   ## point outline
##   geom_point(
##     color = "black", fill = "white",
##     shape = 21, size = 2.8, stroke = .8
##   ) +
##   ## opaque point background
##   geom_point(
##     color = "white", size = 2.2
##   ) +
##   ## colored, semi-transparent points
##   geom_point(
##     aes(color = forcats::fct_relabel(season, stringr::str_to_title)),
##     size = 2.2, alpha = .55
##   ) +
##   geom_smooth(
##     aes(group = day_night), method = "lm", color = "black"
##   ) +
##   facet_grid(
##     day_night ~ is_workday,
##     scales = "free_y", space = "free_y",
##     labeller = labeller(
##       day_night = stringr::str_to_title,
##       is_workday = codes
##     )
##   ) +
##   scale_x_continuous(
##     expand = c(mult = .02, add = 0),
##     breaks = 0:6*5,
##     labels = function(x) paste0(x, "°C")
##   ) +
##   scale_y_continuous(
##     expand = c(mult = 0, add = 1500),
##     limits = c(0, NA),
##     breaks = 0:5*10000,
##     labels = scales::label_comma()
##   ) +
##   scale_color_manual(
##     values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), name = NULL,
##     guide = guide_legend(override.aes = list(size = 5))
##   ) +
##   labs(
##     x = "Feels-Like Temperature", y = NULL,
##     caption = "Data: Transport for London (TfL), Jan 2015—Dec 2016",
##     title = "Reported TfL bike rents versus feels-like temperature in London, 2015–2016"
##   ) +
##   theme_light(
##     base_size = 18, base_family = "Cabinet Grotesk Regular S01"
##   ) +
##   ## more theme adjustments
##   theme(
##     plot.title.position = "plot",
##     plot.caption.position = "plot",
##     plot.title = element_text(family = "Cabinet Grotesk Black S01", size = rel(1.6)),
##     axis.text = element_text(family = "Tabular"),
##     axis.title.x = element_text(hjust = 0, color = "grey30", margin = margin(t = 12)),
##     strip.text = element_text(family = "Cabinet Grotesk Bold S01", size = rel(1.15)),
##     panel.grid.major.x = element_blank(),
##     panel.grid.minor = element_blank(),
##     panel.spacing = unit(1.2, "lines"),
##     legend.position = "top",
##     legend.text = element_text(size = rel(1)),
##     ## for fitting my slide background
##     legend.key = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
##     legend.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
##     plot.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8")
##   )


## ---------------------------------------------------------------------------------------------------------------
g +
  facet_wrap(
    ~ day_night,
    labeller = label_both
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  facet_wrap(
    ~ is_workday + day_night,
    labeller = label_both
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  facet_wrap(
    ~ is_workday + day_night,
    labeller = labeller(
      day_night = stringr::str_to_title
    )
  )


## ---------------------------------------------------------------------------------------------------------------
g +
  facet_wrap(
    ~ is_workday + day_night,
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = label_both
    )
  )


## ---------------------------------------------------------------------------------------------------------------
codes <- c(
  `TRUE` = "Workday",
  `FALSE` = "Weekend or Holiday"
)

g +
  facet_wrap(
    ~ is_workday + day_night,
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = codes
    )
  )


## ---------------------------------------------------------------------------------------------------------------
codes <- c(
  `TRUE` = "Workday",
  `FALSE` = "Weekend or Holiday"
)

g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y",
    space = "free_y",
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = codes
    )
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp > 20 & 
                    season != "summer"),
    aes(x = humidity, y = temp,
        color = season)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point() +
  scale_color_brewer(
    palette = "Dark2",
    guide = "none"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp > 20 & 
                    season != "summer"),
    aes(x = humidity, y = temp,
        color = season)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point() +
  ggforce::geom_mark_rect(
    aes(label = stringr::str_to_title(season))
  ) +
  scale_color_brewer(
    palette = "Dark2",
    guide = "none"
  )


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    dplyr::filter(bikes, temp > 20 & 
                    season != "summer"),
    aes(x = humidity, y = temp,
        color = season)
  ) +
  geom_point(
    data = bikes,
    color = "grey65", alpha = .3
  ) +
  geom_point() +
  ggforce::geom_mark_rect(
    aes(label = stringr::str_to_title(season)),
    expand = unit(5, "pt"),
    radius = unit(0, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  ) +
  scale_color_brewer(
    palette = "Dark2",
    guide = "none"
  ) +
  ylim(NA, 35)


## ---------------------------------------------------------------------------------------------------------------
ggplot(
    bikes,
    aes(x = humidity, y = temp,
        color = season == "summer")
  ) +
  geom_point(alpha = .4) +
  ggforce::geom_mark_hull(
    aes(label = stringr::str_to_title(season),
        filter = season == "summer",
        description = "June to August"),
    expand = unit(10, "pt")
  ) +
  scale_color_manual(
    values = c("grey65", "firebrick"),
    guide = "none"
  )

