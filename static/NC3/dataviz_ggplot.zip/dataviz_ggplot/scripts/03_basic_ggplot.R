#########################################################################
#          NC3 2-Day Workshop "Data Visualization with ggplot2"         #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 23-24 2020 #
#########################################################################

#### A BASIC GGPLOT #####################################################
#------------------------------------------------------------------------

##install.packages("ggplot2")
##library(ggplot2)

##install.packages("tidyverse")
library(tidyverse)

graham <- readr::read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/caribous_graham.csv",
  col_types = cols(season = col_factor(), sex = col_character())
)

tibble::glimpse(graham)

graham_agg <- graham %>% 
  dplyr::filter(year < 2004, sex == "female") %>% 
  dplyr::group_by(date, yday, year, month, season) %>% 
  dplyr::summarize(tree_cover = mean(tree_cover))

tibble::glimpse(graham_agg)

ggplot

ggplot(data = graham_agg) 

ggplot(data = graham_agg,
       mapping = aes( 
          x = date, 
          y = tree_cover 
      )) 

ggplot(graham_agg, aes(date, tree_cover)) 

ggplot(graham_agg) + 
  aes(date, tree_cover) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_area() 

theme_set(theme_light())

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point()

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line() 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_path() 

graham_agg %>%
  arrange(tree_cover) %>% 
  ggplot(aes(date, tree_cover)) +
    geom_path()

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_bar(stat = "identity") 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_col() 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_boxplot() 

ggplot(graham_agg, aes(factor(date), tree_cover)) + 
    geom_boxplot()

ggplot(graham_agg, aes(factor(year), tree_cover)) + 
    geom_boxplot()

ggplot(graham, aes(season, tree_cover)) + 
    geom_boxplot()

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  geom_line() + 
  geom_rug(sides = "r") 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  xlab("Day of the Year") + 
  ylab("Tree Cover") 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  xlab("Day of the Year") +
  ylab("Tree Cover") +
  ggtitle("Patterns in Tree Cover Usage by Female Caribous") 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  labs( 
    x = "Day of the Year", 
    y = "Tree Cover", 
    title = "Patterns in Tree Cover Usage by Female Caribous", 
    subtitle = "Tree cover was extracted for each of the ~79.000 locations recorded between 2001\nand 2003, averaged per day of the year across 22 females tracked in Graham, Canada",
    caption = "Data: B.C. Ministry of Environment & Climate Change", 
    tag = "Fig. 1" 
  ) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  labs(
    x = "Day of the Year",
    y = "Tree Cover",
    title = "Patterns in Tree Cover Usage by Female Caribous",
    subtitle = "Tree cover was extracted for each of the ~79.000 locations recorded between 2001\nand 2003, averaged per day of the year across 22 females tracked in Graham, Canada",
    caption = "\nData: B.C. Ministry of Environment & Climate Change", 
    tag = "Fig. 1"
  )

g <- ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point()

g

g <- ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point()

g +
  geom_line() +
  geom_rug(sides = "r")

ggsave(filename = "my_ggplot.pdf",
       width = 10, height = 7,
       device = cairo_pdf)

ggsave(filename = "my_ggplot.png",
       width = 10, height = 7,
       dpi = 700)

## Exercise data
passwords <- read_csv("https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2020/2020-01-14/passwords.csv")

ggplot(graham_agg,
       aes(season, tree_cover)) +
  stat_summary() 

ggplot(graham_agg,
       aes(season, tree_cover)) +
  stat_summary(
    fun.data = mean_se, 
    geom = "pointrange" 
  )

ggplot(graham_agg,
       aes(season, tree_cover)) +
  stat_summary(
    geom = "errorbar", 
    width = .3 
  )

ggplot(graham_agg,
       aes(season, tree_cover)) +
  stat_summary(
    fun = mean, ## fun.y in old ggplot versions
    size = 1 
  )

ggplot(graham_agg,
       aes(season, tree_cover)) +
  geom_boxplot() + 
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d" 
  )

ggplot(graham_agg,
       aes(season, tree_cover)) +
  stat_summary(fun = mean) + 
  stat_summary( 
    geom = "errorbar", 
    width = .3 
  ) 

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year))) + 
  stat_summary()

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year))) +
  stat_summary(
    position = position_dodge(width = .3)  
  )

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year))) +
  stat_summary(
    fun = mean, 
    fun.min = function(x) mean(x) - sd(x),  
    fun.max = function(x) mean(x) + sd(x),  
    position = position_dodge(width = .3)
  )

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year))) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    geom = "errorbar", 
    width = .2 
  )

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year))) + 
  stat_summary(
    fun = mean, 
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    geom = "errorbar",
    width = .2
  ) +
  stat_summary( 
    fun = mean, 
    geom = "point" 
  ) 

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year),
           group = factor(year))) + 
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    geom = "errorbar",
    width = .2
  ) +
  stat_summary(
    fun = mean,
    geom = "point"
  ) +
  stat_summary( 
    fun = mean, 
    geom = "line" 
  ) 

ggplot(graham_agg,
       aes(season, tree_cover,
           color = factor(year),
           group = factor(year))) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    geom = "errorbar",
    width = .3,
    position = position_dodge(width = .2) 
  ) +
  stat_summary(
    fun = mean,
    geom = "point",
    position = position_dodge(width = .2) 
  ) +
  stat_summary(
    fun = mean,
    geom = "line",
    position = position_dodge(width = .2) 
  )

ggplot(passwords, aes(rank, category)) +
  stat_summary(fun = min)

ggplot(passwords, aes(rank, category)) +
  stat_summary(fun = max)

ggplot(tibble(x = c(-8, 8)), aes(x)) +
  stat_function(fun = dnorm) + 
  stat_function( 
    fun = dcauchy, 
    color = "red", 
    n = 75 
  )  

ggplot(graham_agg, aes(tree_cover)) +
  stat_ecdf() 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  stat_smooth() 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  stat_smooth( 
    method = "lm", 
    formula = y ~ x + I(x^2) +  
                  I(x^3) + I(x^4), 
    se = FALSE 
  ) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  geom_smooth( 
    method = "lm",
    formula = y ~ x + I(x^2) +
                  I(x^3) + I(x^4),
    se = FALSE
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(
    size = 4, 
    alpha = .2 
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(
    size = 4, 
    alpha = .2 
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(
    aes( 
      color = factor(year), 
      shape = season 
    ), 
    size = 4,
    alpha = .2
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(
    aes( 
      color = factor(year), 
      shape = season 
    ), 
    size = 4,
    alpha = .2
  )

ggplot(
  graham_agg,
  aes(date, tree_cover,
      color = factor(year), 
      shape = season) 
  ) +
  geom_point(
    size = 4,
    alpha = .2
  )

ggplot(
  graham_agg,
  aes(date, tree_cover,
      color = factor(year), 
      shape = season) 
  ) +
  geom_line() + 
  geom_point(
    size = 4,
    alpha = .2
  )

ggplot(
  graham_agg,
  aes(date, tree_cover,
      color = factor(year),
      shape = season)
  ) +
  geom_line(show.legend = FALSE) + 
  geom_point(
    size = 4,
    alpha = .2
  )

ggplot(graham_agg, aes(tree_cover)) +
  stat_ecdf(aes(group = year)) 

ggplot(
  graham_agg,
  aes(date, tree_cover,
      group = factor(year), 
      color = factor(year),
      shape = season)
  ) +
  geom_line(show.legend = FALSE) +
  geom_point(
    size = 4,
    alpha = .2
  )

ggplot(graham, aes(longitude, latitude)) + 
  geom_point(alpha = .2) 

ggplot(graham, aes(longitude, latitude)) +
  geom_density2d() 

ggplot(graham, aes(longitude, latitude)) +
  geom_density2d(
    aes(color = season) 
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_hex() 

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(
    aes(fill = ..density..) 
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(
    aes(fill = ..density..),
    color = "white" 
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(
    aes(fill = ..density..,
        color = ..density..)
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(
    aes(fill = ..density..,
        color = ..density..),
    bins = 50 ## default is 30 
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_bin2d() 

ggplot(graham, aes(tree_cover)) +
  geom_histogram() 

ggplot(graham, aes(tree_cover)) +
  geom_histogram(bins = 60)

ggplot(graham, aes(tree_cover)) +
  geom_histogram(binwidth = 1)

ggplot(graham, aes(tree_cover)) +
  geom_density() 

ggplot(graham_agg, aes(year, season)) +
  geom_tile() 

ggplot(graham_agg, aes(year, season)) +
  geom_tile(
    aes(color = tree_cover), 
    size = 2
  )

ggplot(graham_agg, aes(year, season)) +
  geom_tile(
    aes(fill = tree_cover) 
  )

ggplot(graham_agg, aes(year, season)) +
  geom_tile(
    aes(fill = tree_cover),
    color = "white", 
    size = 2 
  )

ggplot(graham_agg, aes(year, factor(month))) +
  geom_tile(
    aes(fill = tree_cover),
    color = "white", 
    size = 2 
  )

ggplot(faithfuld,aes(waiting, eruptions)) +
  geom_raster( 
    aes(fill = density) 
  ) 

ggplot(faithfuld, aes(waiting, eruptions)) +
  geom_contour( 
    aes(z = density) 
  ) 

ggplot(faithfuld, aes(waiting, eruptions)) +
  geom_contour_filled( 
    aes(z = density)
  )

points <- tibble(
  var1 = c(2, 25),
  var1_end = c(23, 3.5),
  var2 = c(21, 2.5),
  var2_end = c(15, 5),
  id = c("A", "B")
)

ggplot(points, aes(x = var1, y = var2)) +
  geom_point() +
  geom_segment( 
    aes(xend = var1_end,  
        yend = var2_end, 
        color = id) 
  )  

ggplot(points, aes(var1, id)) + 
  geom_point() +
  geom_segment(
    aes(xend = 0,  
        yend = id, 
        color = id) 
  ) 

ggplot(points, aes(var1, id)) + 
  geom_point(
    aes(color = id),
    size = 6
  ) + 
  geom_segment(
    aes(xend = 0,
        yend = id,
        color = id), 
    size = 2 
  ) 

ggplot(points, aes(var1, id, color = id)) + 
  geom_point(size = 6) + 
  geom_segment(
    aes(xend = 0,
        yend = id), 
    size = 2 
  ) 

ggplot(points, aes(var1, var2)) +
  geom_point() +
  geom_curve( 
    aes(xend = var1_end,
        yend = var2_end,
        color = id),
    curvature = .4, 
    arrow = arrow(length = unit(0.1, "pt")) 
  )

ggplot(points, aes(var1, var2)) +
  geom_point() +
  geom_abline(slope = .5, intercept = 2) 

ggplot(points, aes(var1, var2)) +
  geom_point() +
  geom_hline( yintercept = 15,  color = "blue") + 
  geom_vline(xintercept = 10, color = "red") 

ggplot(points, aes(var1, var2)) +
  geom_point() +
  geom_rect( 
    aes(xmin = var1, 
        xmax = var1_end, 
        ymin = var2, 
        ymax = var2_end, 
        fill = id), 
    color = "black" 
  )  

(graham_surv <- 
  graham %>% 
  filter(year < 2005) %>% 
  group_by(animal_id) %>% 
  summarize(last = max(date)) %>% 
  arrange(last) %>% 
  mutate(n = 1, cumsum = cumsum(n), diff = (max(cumsum) - cumsum) / max(cumsum)) %>% 
  add_row(last = lubridate::as_date("2002-01-01"), cumsum = 0, diff = 1))

ggplot(graham_surv, aes(last, diff)) +
  geom_step() 

ggplot(graham_surv, aes(last, diff)) +
  geom_step() +
  labs(x = "Time (Days)", 
       y = expression(hat(S)(t))) 

ggplot(graham_surv, aes(last, diff)) +
  geom_step() +
  geom_point( 
    data = filter(graham_surv, diff < 1), 
    shape = 3, 
    color = "red", 
    stroke = 1.5 
  ) +  
  labs(x = "Time (Days)",
       y = expression(hat(S)(t)))

ggplot(graham_surv, aes(last, diff)) +
  geom_step() +
  geom_text( 
    data = filter(graham_surv, diff < 1), 
    aes(label = round(diff, 2)), 
    nudge_x = 5, 
    nudge_y = .02, 
    hjust = 0 
  ) +
  geom_point(
    data = filter(graham_surv, diff < 1),
    shape = 3,
    color = "red",
    stroke = 1.5
  ) +
  labs(x = "Time (Days)",
       y = expression(hat(S)(t)))
