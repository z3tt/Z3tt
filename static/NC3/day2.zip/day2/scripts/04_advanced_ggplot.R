#########################################################################
#          NC3 2-Day Workshop "Data Visualization with ggplot2"         #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 23-24 2020 #
#########################################################################

#### AN ADVANCED GGPLOT #################################################
#------------------------------------------------------------------------

library(tidyverse)
theme_set(theme_light())

graham <- readr::read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/caribous_graham.csv",
  col_types = cols(season = col_factor(), sex = col_character())
)

graham_agg <- graham %>%
  dplyr::filter(year < 2004, sex == "female") %>%
  dplyr::group_by(date, yday, year, month, season) %>%
  dplyr::summarize(tree_cover = mean(tree_cover), n = n())

(g <-
  ggplot(graham_agg, aes(factor(year), tree_cover)) +
    geom_jitter(
      alpha = .7,
      size = 2,
      position = position_jitter(
        width = .4,
        seed = 2020
      )
    )
)

g +
  scale_y_continuous(
    limits = c(0, 50) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA),
    expand = c(0, 0) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA),
    expand = c(1, 1) 
  )

g +
  scale_y_continuous(
    limits = c(0, NA),
    expand = c(.02, .02) 
  )

g +
  scale_y_continuous(
    name = "Tree Cover", 
    limits = c(0, NA),
    expand = c(.02, .02)
  )

g +
  scale_y_continuous(
    name = "Tree Cover",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 90, by = 10) 
  )

g +
  scale_y_continuous(
    name = "Tree Cover", 
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 90, by = 10),
    labels = glue::glue(
        "{seq(0, 90, by = 10)}%" 
      )
  )

g +
  scale_y_continuous(
    name = "Tree Cover",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 90, by = 10),
    labels = glue::glue(
        "{seq(0, 90, by = 10)}%"
    ),
    position = "right" 
  )

g +
  scale_y_continuous(
    name = "Tree Cover",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 90, by = 10),
    labels = glue::glue(
        "{seq(0, 90, by = 10)}%"
    ),
    sec.axis = dup_axis(name = "") 
  )

g +
  scale_y_continuous(
    name = "Tree Cover",
    limits = c(0, NA),
    expand = c(.02, .02),
    breaks = seq(0, 90, by = 10),
    labels = glue::glue(
        "{seq(0, 90, by = 10)}%"
    ),
    sec.axis = sec_axis(~ . + 10) 
  )

g +
  scale_x_discrete(
    name = "Year", 
    expand = c(.5, .5) 
  )

g +
  scale_x_discrete(
    name = "Year",
    expand = c(.1, .1),
    breaks = c(2001, 2003) 
  )

g +
  scale_x_discrete(
    name = "Year",
    expand = c(.1, .1),
    breaks = c(2001, 2003),
    labels = as.roman(c(2001, 2003)) 
  )

g +
  #scale_x_reverse() +
  ## doesn't work with factors
  scale_y_reverse() 

g +
  #scale_x_log10() +
  ## doesn't work with factors
  scale_y_log10() 

g +
  #scale_x_sqrt() +
  ## doesn't work with factors
  scale_y_sqrt() 

ggplot(graham_agg,
       aes(tree_cover, date)) +
  geom_point() +
    scale_y_date( 
      name = NULL, 
      date_breaks = "1 month", 
      date_labels = "%Y-%m-%d", 
      expand = c(.01, .01) 
    ) 

ggplot(graham_agg,
       aes(tree_cover, date)) +
  geom_point() +
    scale_y_date( 
      name = NULL, 
      date_breaks = "3 months", 
      date_labels = "%m/%Y", 
      expand = c(.01, .01) 
    ) 

g_cont <-
  ggplot(graham_agg, aes(factor(year), tree_cover)) +
    geom_jitter(
      aes(color = yday), 
      alpha = .7,
      size = 2,
      position = position_jitter(
        width = .4,
        seed = 2020
      )
    )

g_cont

g_cont +
  scale_color_continuous( 
    guide = "none" 
  ) 

g_cont +
  scale_color_continuous(
    name = "Julian\nDay" 
  )

g_cont +
  scale_color_continuous(
    name = "Julian\nDay",
    type = "viridis" 
  )

g_cont +
  scale_color_continuous(
    name = "Julian\nDay",
    type = "viridis",
    breaks = seq(1, 365, length.out = 5) 
  )

g_cont +
  scale_color_continuous(
    name = "Julian\nDay",
    type = "viridis",
    breaks = seq(1, 365, length.out = 5),
    limits = c(0, 274) 
  )

g_cont +
  scale_color_continuous(
    name = "Julian\nDay",
    type = "viridis",
    breaks = seq(1, 365, length.out = 5),
    labels = c("very early", "early", 
               "halfway", "late", "very late") 
  )

g_disc <-
  ggplot(graham_agg, aes(factor(year), tree_cover)) +
    geom_jitter(
      aes(color = season), 
      alpha = .7,
      size = 2,
      position = position_jitter(
        width = .4,
        seed = 2020
      )
    )

g

g_disc +
  scale_color_discrete( 
    h = c(0, 260), ## hue: [0,360] 
    c = 500, ## chroma: [0,x] 
    l = 90 ## luminance: [0,100] 
  ) 

g_disc +
  scale_color_discrete(
    h = c(0, 260),  ## hue: [0,360]
    c = 500, ## chroma: [0,x]
    l = 90, ## luminance: [0,100]
    name = NULL, 
    labels = c("November–February", 
               "February–November") 
  )

g_disc +
  scale_color_manual( 
    values = c("grey40", "seagreen") 
  ) 

g_cont +
  scale_color_gradient( 
    low = "dodgerblue", 
    high = "firebrick" 
  ) 

g_cont +
  scale_color_gradient2( 
    low = "dodgerblue",
    mid = "grey70", 
    high = "firebrick"
  )

g_cont +
  scale_color_gradient2(
    low = "dodgerblue",
    mid = "grey70",
    high = "firebrick",
    midpoint = median(graham_agg$yday) 
  )

g_disc +
  scale_color_brewer() 

g_disc +
  scale_color_brewer(
    palette = "YlGnBu" 
  )

RColorBrewer::display.brewer.all()

g_disc +
  scale_color_brewer(
    type = "seq", the default  
    palette = "YlGnBu"
  )

g_disc +
  scale_color_brewer(
    type = "qual" 
 )

g_disc +
  scale_color_brewer(
    type = "qual",
    palette = "Dark2" 
 )

g_cont +
  scale_color_distiller() 

g_cont +
  scale_color_distiller(
    palette = "PuRd" 
  )

g_cont +
  scale_color_distiller(
    palette = "PuRd",
    direction = 1 
    note that -1 is the default
  )

g_cont +
  scale_color_distiller(
    type = "div" 
 )

g_cont +
  scale_color_distiller(
    type = "div",
    palette = "Spectral" 
 )

g_cont +
  scale_color_distiller(
    type = "qual" 
 )

g_cont +
  scale_color_viridis_c( 
    option = "magma" 
  ) 

g_cont +
  scale_color_viridis_c(
    option = "magma",
    end = .8 
  )

g_cont +
  scale_color_viridis_c(
    option = "cividis", 
    direction = -1 
  )

g_disc +
  scale_color_viridis_d( 
    option = "plasma", 
    end = .8 
  ) 

g_size <-
  ggplot(graham_agg,
         aes(date, tree_cover)) +
    geom_point(
      aes(size = n),
      alpha = .4
    )

g_size

g_size +
  scale_size( 
    range = c(.1, 3) 
  ) 

g_size +
  scale_size(
    range = c(.1, 3),
    breaks = seq(25, 175, by = 50) 
  )

g_size +
  scale_size(
    range = c(.1, 3),
    breaks = seq(25, 175, by = 50),
    trans = "reverse" 
  )

g_size +
  scale_size(
    range = c(.1, 3),
    breaks = seq(25, 175, by = 50),
    trans = "exp" 
  )

g_size +
  scale_size_binned( 
    n.breaks = 4, 
    range = c(.1, 3) 
  ) 

g_size +
  scale_radius() 

g_shape <-
  ggplot(graham_agg, aes(date, tree_cover)) +
    geom_point(
      aes(shape = factor(year)),
      size = 2.5
    )

g_shape

g_shape +
  scale_shape( 
    name = "Year:" 
  ) 

g_shape +
  scale_shape_manual( 
    name = "Year:", 
    values = 10:12 
  ) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(
    aes(
      shape = factor(year),
      fill = factor(year) 
    ),
    size = 2.5
  ) +
  scale_shape_manual(
    name = "Year:",
    values = 22:24 
  ) +
  scale_fill_brewer( 
    palette = "Dark2" 
  ) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(
    aes(
      shape = factor(year),
      fill = factor(year)
    ),
    size = 2.5
  ) +
  scale_shape_manual(
    name = "Year:",
    values = 22:24
  ) +
  scale_fill_brewer(
    palette = "Dark2",
    name = "Year:" 
  )

ggplot(graham_agg, aes(date, n)) +
  geom_line(
    aes(linetype = factor(year)), 
    size = .7
    )

ggplot(graham_agg, aes(date, n)) +
  geom_line(
    aes(linetype = factor(year)),
    size = .7
  ) +
  scale_linetype_manual( 
    name = "Year:", 
    values = c("longdash", 
               "dotted", 
               "dotdash") 
  ) 

ggplot(graham_agg, aes(date, n)) +
  geom_line(
    aes(
      linetype = factor(year),
      color = factor(year), 
    ),
    size = .7
  ) +
  scale_linetype_manual(
    name = "Year:",
    values = c("longdash",
               "dotted",
               "dotdash")
  ) +
  scale_color_brewer( 
    name = "Year:", 
    palette = "Set1", 
  ) 

g_trans <-
  ggplot(graham_agg, aes(yday, tree_cover)) +
    geom_point(
      aes(alpha = n), 
      size = 3,
      color = "purple"
    )

g_trans

g_trans +
  scale_alpha( 
    range = c(.3, 1) 
  ) 

g_trans +
  scale_alpha(
    range = c(.3, 1),
    breaks = c( 
      min(graham_agg$n), 
      floor(median(graham_agg$n)), 
      max(graham_agg$n) 
    ) 
  )

g_trans +
  scale_alpha(
    name = "Observations:", 
    range = c(.3, 1),
    breaks = c(
      min(graham_agg$n),
      floor(median(graham_agg$n)),
      max(graham_agg$n)
    ),
    labels = c( 
      glue::glue("Minimum ({min(graham_agg$n)})"), 
      glue::glue("Average ({median(graham_agg$n)})"), 
      glue::glue("Maximum ({max(graham_agg$n)})") 
    ) 
  )

g_trans +
  scale_alpha_continuous(  
    name = "Observations:",
    range = c(.3, 1),
    breaks = c(
      min(graham_agg$n),
      floor(median(graham_agg$n)),
      max(graham_agg$n)
    ),
    labels = c(
      glue::glue("Minimum ({min(graham_agg$n)})"),
      glue::glue("Average ({median(graham_agg$n)})"),
      glue::glue("Maximum ({max(graham_agg$n)})")
    )
  )

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(
    aes(alpha = as.factor(n)), 
    size = 3,
    color = "purple"
  ) +
  scale_alpha_discrete(  
    name = "Observations:",
    range = c(.3, 1)
  )

## Exercise data
chic <- readr::read_csv("https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/chicago-nmmaps.csv",
                        col_types = cols(season = col_factor(), year = col_factor()))

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(aes(color = ..count..)) +
  scale_color_viridis_c(
    guide = "none" 
  ) +
  viridis::scale_fill_viridis(
    guide = "none" 
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(aes(color = ..count..)) +
  scale_color_viridis_c(
    guide = "colorbar" 
  ) +
  viridis::scale_fill_viridis(
    guide = "legend" 
  )

ggplot(graham, aes(longitude, latitude)) +
  geom_hex(aes(color = ..count..)) +
  scale_color_viridis_c(
    guide = "colorsteps" 
  ) +
  viridis::scale_fill_viridis(
    guide = "bins" 
  )

ggplot(filter(graham, year < 2005),
       aes(longitude, latitude)) +
  geom_point(
    aes(
      color = tree_cover,
      shape = season
    )
  ) +
  scale_color_viridis_c() +
  guides( 
    color = "legend" 
  ) 

ggplot(filter(graham, year < 2005),
       aes(longitude, latitude)) +
  geom_point(
    aes(
      color = tree_cover,
      shape = season
    )
  ) +
  scale_color_viridis_c() +
  guides(
    color = guide_legend( 
      override.aes = list(size = 5)
    ) 
  )

ggplot(filter(graham, year < 2005),
       aes(longitude, latitude)) +
  geom_point(
    aes(
      color = tree_cover,
      shape = season
    )
  ) +
  scale_color_viridis_c() +
  guides(
    size = guide_legend(order = 1), 
    color = guide_colorbar(order = 2) 
  )

ggplot(filter(graham, year < 2005),
       aes(longitude, latitude)) +
  geom_point(
    aes(
      color = tree_cover,
      shape = season
    )
  ) +
  scale_color_viridis_c() +
  guides(
    color = guide_colorbar(
      direction = "vertical", 
      barwidth = unit(0.3, "lines") 
    ),
    size = guide_legend(
      nrow = 2, 
      bins = 6, 
      title.position = "top", 
      label.position = "bottom" 
    )
  ) +
  theme(legend.position = "bottom") 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line() +
  coord_cartesian( 
    ylim = c(40, 60) 
  ) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line() +
  coord_cartesian( 
    ylim = c(40, 60) 
  ) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line() +
  coord_cartesian(ylim = c(40, 60)) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line() +
  scale_y_continuous(limits = c(40, 60)) 

ggplot(graham, aes(season, tree_cover)) +
  geom_boxplot()  +
  coord_cartesian(ylim = c(40, 60)) 

ggplot(graham, aes(season, tree_cover)) +
  geom_boxplot()  +
  scale_y_continuous(limits = c(40, 60)) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  scale_y_continuous(expand = c(0, 0)) 

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  scale_x_date(
    expand = c(0, 0)
  ) +
  coord_cartesian(ylim = c(40, 60))

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  coord_cartesian(
    ylim = c(40, 60)
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  coord_cartesian(
    ylim = c(40, 60),
    clip = "off" 
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  coord_cartesian(
    ylim = c(40, 60)
  )

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point() +
  coord_cartesian(
    ylim = c(40, 60),
    clip = "off" 
  )

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point() +
  coord_fixed() 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point() +
  coord_fixed() +
  scale_x_continuous( 
    breaks = seq(0, 350, by = 25) 
  ) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point() +
  coord_fixed(
    ratio = 3 
  ) +
  scale_x_continuous(
    breaks = seq(0, 350, by = 25)
  )

graham_agg %>% 
  group_by(month) %>% 
  mutate( 
    month = lubridate::month(date, label = TRUE, abbr = FALSE) 
  ) %>%  
  summarize(n = sum(n)) %>%  
  ggplot(aes(month, n)) +
  geom_col() +
  coord_cartesian()

graham_agg %>% 
  group_by(month) %>% 
  mutate( 
    month = lubridate::month(date, label = TRUE, abbr = FALSE) 
  ) %>%  
  summarize(n = sum(n)) %>%  
  ggplot(aes(month, n)) +
  geom_col() +
  coord_flip() 

graham_agg %>%
  group_by(month) %>%
  mutate(
    month = lubridate::month(date, label = TRUE, abbr = FALSE)
  ) %>%
  summarize(n = sum(n)) %>%
  ggplot(aes(fct_rev(month), n)) +  
  geom_col() +
  coord_flip()

graham_agg %>%
  group_by(month) %>%
  mutate(
    month = lubridate::month(date, label = TRUE, abbr = FALSE)
  ) %>%
  summarize(n = sum(n)) %>%
  ggplot(aes(fct_reorder(month, n), n)) +  
  geom_col() +
  coord_flip()

ggplot(graham_agg, aes(factor(year))) +
  geom_bar() +
  coord_cartesian()

ggplot(graham_agg, aes(factor(year))) +
  geom_bar() +
  coord_polar() 

graham_agg %>%
  count(year) %>% 
  ggplot(aes(factor(1), n, 
             fill = factor(year))) + 
    geom_col() +
    coord_polar() + 
    scale_x_discrete(
      name = NULL,
      expand = c(0, 0)
    ) +
    scale_y_continuous(
      name = NULL,
      expand = c(0, 0)
    )

graham_agg %>%
  count(year) %>%
  ggplot(aes(factor(1), n,
             fill = factor(year))) +
    geom_col() +
    coord_polar(theta = "y") + 
    scale_x_discrete(
      name = NULL,
      expand = c(0, 0)
    ) +
    scale_y_continuous(
      name = NULL,
      expand = c(0, 0)
    )

graham_agg %>%
  count(year) %>%
  ggplot(aes(factor(1), n,
             fill = factor(year))) +
    geom_col() +
    #coord_polar(theta = "y") + 
    scale_x_discrete(
      name = NULL,
      expand = c(0, 0)
    ) +
    scale_y_continuous(
      name = NULL,
      expand = c(0, 0)
    )

ggplot(mpg, aes(hwy, displ)) +
  geom_smooth(method = "lm") +
  geom_point()

ggplot(mpg, aes(hwy, displ)) +
  geom_smooth(method = "lm") +
  geom_point() +
  coord_fixed()

g <-
  ggplot(graham_agg,
         aes(yday, tree_cover)) +
    geom_point(
      aes(color = factor(year)),
      alpha = .5
    ) +
    scale_color_brewer(
      palette = "Dark2",
      guide = "none"
    )

g

g +
  facet_wrap(~ factor(year)) 

g +
  facet_wrap(~ season) 

g +
  facet_wrap(
    ~ factor(year),
    scales = "free" 
  )

g +
  facet_wrap(
    ~ factor(year),
    scales = "free_y" 
  )

g +
  facet_wrap(
    ~ factor(year),
    nrow = 3 
  )

g +
  facet_wrap(
    ~ factor(year),
    ncol = 2 
  )

g +
  facet_grid( 
    factor(year) ~ season 
  ) 

g +
  facet_grid( 
    season ~ factor(year) 
  ) 

g +
  facet_grid(
    factor(year) ~ season,
    scales = "free" 
  )

g +
  lemon::facet_rep_grid( 
    factor(year) ~ season
  )

(time <- ggplot(graham_agg, aes(date, tree_cover)) +
  geom_point(aes(color = factor(year))) +
  scale_color_brewer(palette = "Set1",
                     guide = "none"))

(box <- ggplot(graham_agg, aes(tree_cover, season)) +
  geom_boxplot(aes(color = factor(year))) +
  scale_color_brewer(palette = "Set1",
                     guide = "none"))

library(patchwork)

time + box

time / box

time + box + plot_layout(widths = c(2, 1))

time + plot_spacer() + box + plot_layout(widths = c(2, .5, 1))

scatter <-
  ggplot(
    filter(graham, year < 2005),
    aes(longitude, latitude)
  ) +
  geom_point(
    aes(color = factor(year)),
    alpha = .25
  ) +
  scale_color_brewer(
    palette = "Set1",
    guide = "none"
  )

time / (box + scatter) +
  plot_layout(heights = c(1, 2))

scatter <-
  ggplot(
    filter(graham, year < 2005),
    aes(longitude, latitude)
  ) +
  geom_point(
    aes(color = factor(year)),
    alpha = .25
  ) +
  scale_color_brewer(
    palette = "Set1",
    #guide = "none" 
  )

time / (box + scatter) +
  plot_layout(heights = c(1, 2))

time / (box + scatter) +
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  )

time / (box + scatter) +
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation( 
    title = "Fig 1: Caribou Tracking in Graham (Canada) by Year" 
  ) 

time / (box + scatter) +
  plot_layout(
    heights = c(1, 2),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Fig 1: Caribou Tracking in Graham (Canada) by Year",
    tag_levels = "A" 
  )

scatter +
  inset_element( 
    box,  
    top = 1, 
    right = 1,  
    bottom = .55, 
    left = .65 
  ) 

scatter +
  inset_element(
    box,
    top = .8,
    right = .8,
    bottom = .2,
    left = .2
  )

scatter +
  inset_element(
    box,
    top = 1,
    right = .65,
    bottom = .55,
    left = 0,
    align_to = "full" 
  )

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(aes(color = factor(year))) +
  theme_bw() 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(aes(color = factor(year))) +
  theme_dark() 

theme_set(theme_light()) 

(g <- ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(aes(color = factor(year))))

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_line(color = "grey60") +
  geom_point(aes(color = tree_cover)) +
  scale_color_distiller(palette = 8)

old_theme <- theme_set(theme_dark()) 

g +
  scale_color_brewer(palette = 8)

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line(color = "grey60") +
  geom_point(aes(color = tree_cover)) +
  scale_color_distiller(palette = 8)

theme_set(old_theme) 

g +
  scale_color_brewer(palette = 8)

ggplot(graham_agg, aes(date, tree_cover)) +
  geom_line(color = "grey60") +
  geom_point(aes(color = tree_cover)) +
  scale_color_distiller(palette = 8)

theme_set(theme_light(base_size = 32))

g

theme_set(theme_light(base_size = 16))

g

g +
  theme_bw(base_size = 5) 

g +
  theme_dark(base_size = 50) 

theme_set(theme_light(
    base_size = 20,
    base_family = "Roboto Mono"
  ))
g

theme_set(theme_light(
    base_size = 20,
    base_family = "Alfa Slab One"
  ))
g

theme_set(theme_light(base_size = 16, base_family = "Open Sans"))

#install.packages("showtext")
library(showtext)

## Loading Google fonts (https://fonts.google.com/) installed on your system
font_add_google("Roboto", "Roboto")
font_add_google("Roboto Mono", "Roboto Mono")

#install.packages("systemfonts")
library(systemfonts)

system_fonts()

#install.packages("systemfonts")
library(systemfonts)

font_info("Oswald")

#install.packages("extrafont")
library(extrafont)

## import your system fonts (run only once)
#font_import() ## press "y"
loadfonts()

fonts()

g +
  theme_bw(
    base_size = 20,
    base_line_size = 2 
  )

g +
  theme_bw(
    base_size = 20,
    base_line_size = 2,
    base_rect_size = 5 
  )

theme_grey

element_text(
  family = "Roboto",
  face = "bold", ## plain, italic, bold.italic
  size = 18,
  color = "red",
  lineheight = .7,
  angle = 180,
  hjust = .5,
  vjust = .0,
  margin = margin(
    t = 10, ## top
    r = 0,  ## right
    b = 30, ## bottom
    l = 0   ## left
  )
)

g +
  ggtitle("My New\nTitle") +
  theme(
    plot.title = element_text(
      family = "Roboto",
      face = "bold",
      size = 18,
      color = "red",
      lineheight = .7,
      angle = 180,
      hjust = .5,
      vjust = .0,
      margin = margin(
        10,
        0,
        30,
        0
      )
    )
  )

element_line(
  color = "red",
  size = 10,
  linetype = "dashed",
  lineend = "square", # round, butt
  arrow = arrow(
    angle = 30,
    length = unit(0.25, "inches")
  )
)

g +
  theme(
    panel.grid = element_line(
      color = "red",
      size = 10,
      linetype = "dashed",
      lineend = "square", # round, butt
      arrow = arrow(
        angle = 30,
        length = unit(0.25, "inches")
      )
    )
  )

element_rect(
  color = "orange",
  fill = "black",
  size = 2,
  linetype = "dotted"
)

g +
  theme(
    plot.background = element_rect(
      color = "orange",
      fill = "black",
      size = 2,
      linetype = "dotted"
    )
  )

legend.position = "top"  ## bottom, right, left
legend.position = "none"
legend.position = c(.2, .8)  ## x, y

plot.title.position = "plot"  ## panel
plot.caption.position = "plot"

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = "top",
    plot.title.position = "plot"
  )

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = "none",
    plot.title.position = "panel"
  )

g +
  ggtitle("A very short title.") +
  theme(
    legend.position = c(.2, .8),
    plot.title.position = "plot"
  )

?grid::unit
unit(50, "pt")
unit(10, "mm")
unit(2.5, "lines")
unit(.15, "npc")  ## Normalised Parent Coordinates

g +
  theme(
    axis.ticks.length =
      unit(2.5, "lines"),
    legend.key.size =
      unit(.15, "npc")
  )

g +
  theme(
    axis.ticks.x = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.y = element_blank(),
    legend.title = element_blank()
  )

g +
  labs(
    title = "A very short title"
  ) +
  theme_minimal() +
  theme(
    plot.title =
      element_text(
        family = "Alfa Slab One"
      ),
    axis.text =
      element_text(
        family = "Roboto Mono"
      )
  )

theme_set(theme_bw(base_size = 20))

g

theme_update(
  panel.grid.major = element_line(color = "red")
)

g

theme_set(theme_light())

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(alpha = .4) +
  annotate( 
    geom = "rect", 
    xmin = 125, 
    xmax = 210, 
    ymin = 15, 
    ymax = 50, 
    fill = NA, 
    color = "red" 
  ) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "rect",
    xmin = 150,
    xmax = Inf, 
    ymin = -Inf, 
    ymax = Inf, 
    fill = "red",
    alpha = .5
  )

ggplot(graham_agg, aes(yday, tree_cover)) +
  annotate(
    geom = "rect",
    xmin = 150,
    xmax = Inf,
    ymin = -Inf,
    ymax = Inf,
    fill = "red",
    alpha = .5
  )  +
  geom_point(alpha = .4) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  annotate(
    geom = "rect",
    xmin = 150,
    xmax = Inf,
    ymin = -Inf,
    ymax = Inf,
    fill = "red",
    alpha = .5
  )  +
  geom_point(alpha = .4) +
  facet_wrap(~ year) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(alpha = .4) +
  annotate( 
    geom = "text", 
    x = 190, 
    y = 75, 
    label = "Some\nadditional\ntext", 
    size = 5, 
    color = "blue", 
    fontface = "bold" 
  ) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_point(alpha = .4) +
  annotate(
    geom = "text",
    x = 190,
    y = 75,
    label = "Some\nadditional\ntext",
    size = 5,
    color = "blue",
    fontface = "bold"
  ) +
  facet_wrap(~ year) 

library(png) 

## download image and put in your current working directory
## https://www.uni-bielefeld.de/biologie/crc212/images/logo_einr.png

ggplot(graham_agg, aes(yday, tree_cover)) +
  annotation_custom(
    grid::rasterGrob( 
      image = readPNG(
        "logo.png" 
      ) 
    ) 
  ) +
  geom_point(alpha = .4)

ggplot(graham_agg, aes(yday, tree_cover)) +
  annotation_custom(
    grid::rasterGrob(
      image = readPNG(
        "logo.png"
      ),
      width = unit(.8, "npc"), 
      height = unit(.5, "npc") 
    )
  ) +
  geom_point(alpha = .4)

ggplot(graham_agg, aes(yday, tree_cover)) +
  annotation_custom(
    grid::rasterGrob(
      image = readPNG(
        "logo.png"
      ),
      x = .85, 
      y = .85, 
      width = .25 
    )
  ) +
  geom_point(alpha = .4)

graham_sum <-
  graham_agg %>%
  mutate(year = factor(year)) %>%
  group_by(year) %>%
  summarize(
    avg = mean(tree_cover)
  )

graham_sum

(g <-
  ggplot(graham_sum,
    aes(year, avg,
        fill = year)) +
    geom_col() +
    scale_fill_brewer(
      palette = "Dark2",
      guide = "none"
    ) +
   labs(x = NULL, y = NULL)
)

g +
  geom_text(aes(label = round(avg, 1)))

g +
  geom_label(aes(label = round(avg, 1)))

g +
  geom_label(
    aes(label = round(avg, 1)),
    fill = "white" 
  )

g +
  geom_label(
    aes(label = round(avg, 1),
        color = year),
    fill = "white"
  )

g <-
  g +
  scale_color_brewer( 
    palette = "Dark2", 
    guide = "none" 
  ) 

g +
  geom_label(
    aes(label = round(avg, 1),
        color = year),
    fill = "white"
  )

g +
  geom_label(
    aes(label = round(avg, 1),
        color = year),
    fill = "white",
    nudge_y = 5 
  )

g +
  geom_label(
    aes(label = round(avg, 1), 
        color = year),
    fill = "white",
    nudge_y = -10 
  )

g +
  geom_label(
    aes(y = 5, 
        label = round(avg, 1),
        color = year),
    fill = "white"
  )

g +
  geom_label(
    aes(y = avg / 2, 
        label = round(avg, 1),
        color = year),
    fill = "white"
  )

g +
  geom_label(
    aes(y = avg / 2,
        label = round(avg, 1)),
    fill = "white",
    size = 6, 
    family = "Roboto Mono", 
    fontface = "bold", 
    vjust = .7 
  )

g +
  geom_label(
    aes(y = avg / 2,
        label = round(avg, 1)),
    fill = "white",
    size = 6,
    family = "Roboto Mono",
    fontface = "bold",
    label.padding = unit(1.1, "lines"),
    label.r = unit(1.5, "lines"), 
    label.size = 2 
  )

g +
  geom_label(
    aes(y = avg / 2,
        label = round(avg, 1)),
    fill = "white",
    size = 6,
    family = "Roboto Mono",
    fontface = "bold",
    label.padding = unit(1.1, "lines"), 
    label.r = unit(0, "lines"), 
    label.size = 0 
  )

#install.packages("ggtext") 
library(ggtext) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_jitter(
    aes(color = factor(year)),
    width = 0.3
  ) +
  ggtitle("**Tree Cover Used** per *Julian Day* and *Year*") + 
  theme(plot.title = element_markdown()) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_jitter(
    aes(color = factor(year)),
    width = 0.3
  ) +
  ggtitle("<b style='color:red;font-size:25pt;'>Tree Cover Used</b> per <i style='color:blue;'>Julian Day</i> and <i style='color:blue;'>Year</i>") + 
  theme(plot.title = element_markdown()) 

ggplot(graham_agg, aes(yday, tree_cover)) +
  geom_jitter(
    aes(color = factor(year)),
    width = 0.3
  ) +
  ggtitle("<b style='color:red;font-size:15pt;'>Tree Cover Used</b> per <i style='color:blue;'>Julian Day</i> and <i style='color:blue;'>Year</i>") +
  theme(
    plot.title = element_textbox_simple( 
      size = 10, 
      fill = "grey70", 
      hjust = .5, 
      padding = margin(10, 10, 10, 10), 
      margin = margin(0, 0, 10, 0), 
      r = unit(8, "pt") 
    ) 
  )
