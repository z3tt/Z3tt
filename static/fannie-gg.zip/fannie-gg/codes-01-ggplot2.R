#------------------------------------------------------------------------------#
#                                                                              #
#           Engaging Data Visualizations for Graphical Storytelling            #
#                      From Theory to Practice with ggplot2                    #
#                                                                              #
#                              Dr. Cedric Scherer                              #
#                   Fannie Mae Workshop // September 2024                      #
#                                                                              #
#------------------------------------------------------------------------------#

library(dplyr)
library(lubridate)

fannie_raw <- 
  readr::read_csv(
    here::here("data", "fannie-mae-data-18-23.csv"),
    col_types = "Dddddfccfd"
  ) |>
  filter(purpose %in% c("R", "P")) |> 
  mutate(purpose = if_else(purpose == "R", "Refinance", "Purchase"))

set.seed(2024)
fannie_sub <- slice_sample(fannie_raw, n = 2000)

fannie_agg <-
  fannie_raw |> 
  summarize(
    loans = n(),
    avg_rate = mean(orig_rate, na.rm = TRUE),
    avg_score = mean(cscore_b, na.rm = TRUE),
    avg_upb_dti = sum(dti * orig_upb, na.rm = TRUE) / sum(orig_upb, na.rm = TRUE),
    .by = c(orig_date, year, purpose)
  )

library(ggplot2)

theme_set(
  theme_minimal(
    base_size = 13,
    base_family = "Asap SemiCondensed"
  )
)

theme_update(
  panel.grid.minor = element_blank(),
  plot.title.position = "plot",
  legend.position = "top",
  legend.justification = "left"
)

g <-
  ggplot(
    fannie_agg,
    aes(x = orig_date, y = avg_score,
        color = purpose)
  ) +
  geom_line() +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    name = NULL
  ) +
  labs(x = NULL, y = "Average FICO Score")

g

library(systemfonts)

match_font("Asap", bold = TRUE)

system_fonts()

system_fonts() |>
  filter(stringr::str_detect(family, "Asap")) |>
  select(family) |>
  unique() |> 
  arrange(family)

g +
  theme(
    text = element_text(
      family = "Asap Expanded"
    )
  )

system_fonts() |>
  filter(family == "Asap SemiCondensed") |>
  select(name) |>
  arrange(name)

register_variant(
  name = "Asap SemiCondensed Semibold S1",
  family = "Asap SemiCondensed",
  weight = "semibold",
  features = font_feature(letters = "stylistic")
)

g +
  theme(
    text = element_text(
      family = "Asap SemiCondensed Semibold S1"
    )
  )

register_variant(
  name = "Spline Sans Tabular",
  family = "Spline Sans",
  weight = "normal",
  features = font_feature(numbers = "tabular")
)

## ggsave("my_plot.png", width = 5, height = 6, dpi = 600, device = ragg::agg_png)

## ggsave("my_plot.pdf", width = 5, height = 6, device = cairo_pdf)

ggplot(fannie_agg, aes(x = avg_rate, y = loans)) +
  geom_point(stat = "identity") # default

ggplot(fannie_agg, aes(x = avg_rate, y = loans)) +
  stat_identity(geom = "point") # default

ggplot(fannie_raw, aes(x = purpose)) +
  geom_bar(stat = "count") # default

ggplot(fannie_raw, aes(x = purpose)) +
  stat_count(geom = "bar") # default

ggplot(fannie_agg, aes(x = avg_score, y = loans)) +
  geom_smooth(stat = "smooth") # default

ggplot(fannie_agg, aes(x = avg_score, y = loans)) +
  stat_smooth(geom = "smooth") # default

ggplot(fannie_agg, aes(x = avg_score, y = loans)) +
  stat_smooth(geom = "pointrange")

ggplot(fannie_agg, aes(x = avg_score, y = loans)) +
  stat_smooth(geom = "col")

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary() 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    fun.data = "mean_se", # default
    geom = "pointrange" # default
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    fun.data = "mean_cl_boot",
    geom = "pointrange" # default
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  geom_boxplot() +
  stat_summary(
    fun = "mean",
    geom = "point",
    color = "#28a87d",
    size = 3
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    fun = "mean", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y) 
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    fun = "mean", 
    fun.max = function(foo) mean(foo) + sd(foo), 
    fun.min = function(foo) mean(foo) - sd(foo)
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    fun.data = "mean_sdl", 
    fun.args = list(mult = 1)
  )

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = "mean",
    size = 2
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = "mean",
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = "mean",
    aes(label = after_stat(y))
  ) 

ggplot(
  fannie_sub, 
  aes(x = channel, y = orig_rate)
) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = "mean",
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = "mean",
    aes(label = after_stat(
      sprintf("%2.1f", y)
    )),
    hjust = -.5
  ) 

ggplot(
  fannie_agg, 
  aes(x = purpose,  
      y = year, 
      fill = loans)
) +
  geom_tile() 

ggplot(
  fannie_agg, 
  aes(x = purpose,  
      y = year, 
      z = loans)
) +
  stat_summary_2d() 

ggplot(
  fannie_agg, 
  aes(x = purpose,  
      y = year, 
      z = loans)
) +
  stat_summary_2d(
    geom = "tile", 
    fun = "sum", 
    color = "white", 
    linewidth = .7
  ) 

ga <- 
  ggplot(fannie_agg, 
         aes(x = avg_score, y = loans)) +
  geom_point(
    aes(color = loans > 190000, 
        shape = purpose),
    size = 2
  ) +
  scale_color_manual(
    values = c("grey", "firebrick"),
    guide = "none"
  ) + 
  scale_shape_manual(
    values = c(21, 16),
    name = NULL
  ) +
  coord_cartesian(
    clip = "off"
  )

ga

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "What happened here?"
  )

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "What happened here?",
    color = "firebrick",
    size = 6,
    family = "Asap SemiCondensed",
    fontface = "bold",
    lineheight =  .8
  )

ga +
  annotate(
    geom = "text",
    x = c(760, max(fannie_agg$avg_score)),
    y = c(250000, 10000),
    label = c("What happened here?", "Data: 2018-2023"),
    color = c("firebrick", "black"),
    size = c(6, 3),
    family = c("Asap SemiCondensed", "Spline Sans Mono"),
    fontface = c("bold", "plain"),
    hjust = c(.5, 1)
  )

## ggannotate::ggannotate(g)

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "segment",
    x = 765, 
    xend = 772.7,
    y = 250000, 
    yend = 289435
  )

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 765, 
    xend = 772.7,
    y = 250000, 
    yend = 289435
  )

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 765, 
    xend = 772.7,
    y = 250000, 
    yend = 289435,
    curvature = -.25,
    arrow = arrow()
  )

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 765, 
    xend = 772.7,
    y = 250000, 
    yend = 289435,
    curvature = -.25,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed",
      ends = "both"
    )
  )

ga +
  annotate(
    geom = "text",
    x = 760,
    y = 250000,
    label = "The\nhighest\ncount",
    family = "Asap SemiCondensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 765, 
    xend = 772.7,
    y = 250000, 
    yend = 289435,
    curvature = -1,
    angle = -145,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed"
    )
  )

ga +
  ggforce::geom_mark_rect(
    aes(label = "First Year of COVID",
        filter = loans > 190000)
  )

ga +
  ggforce::geom_mark_rect(
    aes(label = "First Year of COVID",
        filter = loans > 190000),
    color = "firebrick",
    label.family = "Asap SemiCondensed"
  )

ga +
  ggforce::geom_mark_rect(
    aes(label = "First Year of COVID",
        filter = loans > 190000),
    description = "Refinance mortgage loans between April '20 and April '21",
    color = "firebrick",
    label.family = "Asap SemiCondensed"
  )

ga +
  ggforce::geom_mark_rect(
    aes(label = "First Year of COVID",
        filter = loans > 190000),
    description = "Refinance mortgage loans between April '20 and April '21",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    radius = unit(12, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )

ga +
  ggforce::geom_mark_circle(
    aes(label = "First Year of COVID",
        filter = loans > 190000),
    description = "Refinance mortgage loans between April '20 and April '21",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )

ga +
  ggforce::geom_mark_hull(
    aes(label = "First Year of COVID",
        filter = loans > 190000),
    description = "Refinance mortgage loans between April '20 and April '21",
    color = "black",
    label.family = "Asap SemiCondensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )

ggplot(
  fannie_agg,
  aes(x = orig_date, y = avg_upb_dti, 
      color = purpose,
      group = purpose)
) +
  geom_line(linewidth = 1) +
  coord_cartesian(expand = FALSE) +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    name = NULL
  ) +
  labs(x = NULL)

ggplot(
  fannie_agg,
  aes(x = orig_date, y = avg_upb_dti, 
      color = purpose,
      group = purpose)
) +
  geom_line(linewidth = 1) +
  geom_text(
    data = filter(fannie_agg, orig_date == as_date("2020-04-01")),
    aes(label = purpose),
    family = "Asap SemiCondensed",
    fontface = "bold",
    vjust = -1.5,
    hjust = 0
  ) +
  coord_cartesian(expand = FALSE) +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    guide = "none"
  ) +
  labs(x = NULL)

ggplot(
  fannie_agg,
  aes(x = orig_date, y = avg_upb_dti, 
      color = purpose,
      group = purpose)
) +
  geomtextpath::geom_textline(
    aes(label = purpose),
    linewidth = 1,
    family = "Asap SemiCondensed",
    fontface = "bold"
  ) +
  coord_cartesian(expand = FALSE) +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    guide = "none"
  ) +
  labs(x = NULL)

ggplot(
  fannie_agg,
  aes(x = orig_date, y = avg_upb_dti, 
      color = purpose,
      group = purpose)
) +
  geomtextpath::geom_textline(
    aes(label = purpose),
    linewidth = 1,
    family = "Asap SemiCondensed",
    fontface = "bold",
    vjust = -.3, 
    hjust = .63
  ) +
  coord_cartesian(expand = FALSE) +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    guide = "none"
  ) +
  labs(x = NULL)

ggplot(
  fannie_agg,
  aes(x = orig_date, y = avg_upb_dti, 
      color = purpose,
      group = purpose)
) +
  geomtextpath::geom_textline(
    aes(label = purpose),
    linewidth = 1,
    family = "Asap SemiCondensed",
    fontface = "bold",
    vjust = -.3, 
    hjust = .63,
    straight = TRUE
  ) +
  coord_cartesian(expand = FALSE) +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    guide = "none"
  ) +
  labs(x = NULL)

g +
  ggtitle("**Single-family mortgage loans by *purpose***")

g +
  ggtitle("**Fannie Mae mortgage loans by *purpose***") +
  theme(
    plot.title = ggtext::element_markdown()
  )

g +
  ggtitle("Mortgages for <b style='color:#FFA200;'>purchase money</b> and <b style='color:#757BC7;'>refinance</b> owned or guaranteed by <i style='font-family:times;font-size:26pt;'>Fannie Mae</i>") +
  theme(
    plot.title = ggtext::element_markdown(),
    legend.position = "none"
  )

g +
  ggtitle("Mortgages for <b style='color:#FFA200;'>purchase money</b> and <b style='color:#757BC7;'>refinance</b> owned or guaranteed by <i style='font-family:times;font-size:26pt;'>Fannie Mae</i>") +
  theme(
    plot.title = 
      ggtext::element_textbox_simple(
        margin = margin(t = 12, b = 12),
        padding = margin(rep(12, 4)),
        fill = "grey95",
        box.colour = "grey30",
        linetype = "13",
        r = unit(9, "pt"),
        halign = .5,
        lineheight = 1
      ),
    legend.position = "none"
  )

g +
  ggtext::geom_richtext(
    data = data.frame(
      orig_date = as_date(c("2020-09-01", "2023-03-01")),
      avg_score = c(765, 745),
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> *2*")
    ),
    aes(label = lab),
    color = "black"
  )

g +
  ggtext::geom_richtext(
    data = data.frame(
      orig_date = as_date(c("2020-09-01", "2023-03-01")),
      avg_score = c(765, 745),
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> *2*"),
      angle = c(35, 310)
    ),
    aes(label = lab,
        angle = angle),
    color = "black"
  )

g +
  ggtext::geom_textbox(
    data = data.frame(
      orig_date = as_date(c("2018-09-01", "2023-03-01")),
      avg_score = c(765, 745),
      lab = "Lorem ipsum dolor sit amet, **consectetur adipiscing elit**, sed do eiusmod tempor incididunt ut <i style='color:red;'>labore et dolore magna</i> aliqua."
    ),
    aes(label = lab),
    color = "black",
    size = 3,
    halign = c(0, 1),
    hjust = c(.25, .75)
  )

ga +
  marquee::geom_marquee(
    data = filter(fannie_agg, loans == max(loans)),
    aes(label = paste0(
      "Most loans were  
      owned {.firebrick **", format(orig_date, "%Y-%m"), "**}"
    )),
    color = "black",
    hjust = .75,
    vjust = 1
  ) 

md <- 
  "## Mortgage loans owned or guaranteed by {.red Fannie Mae}
The visualization shows the _average FICO score_ from **January 2018 to December 2023**."

g +
  ggtitle(md) + 
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc")
    )
  )

md <- 
  "One can even add code chunks:

    text <- \"markdown **text**\"
    marquee_grob(text)

... and even lists:

1. this
1. is
1. awesome!
"

g +
  ggtitle(md) + 
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc")
    )
  )

logo <- "![](img/logo.jpg)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      width = unit(1.15, "npc")
    )
  )

logo <- "Data by ![](img/logo-wide.png)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      size = 20, margin = margin(20, 0, 0, 0)
    )
  )

logo <- "*![](img/logo-wide.png)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      size = 20, margin = margin(20, 0, 0, 0), 
      color = "white"
    )
  )

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  geom_boxplot()

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  geom_violin()

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  geom_violin() +
  geom_boxplot(width = .1, outlier.color = NA)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggbeeswarm::geom_beeswarm(cex = .65, size = .5)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggbeeswarm::geom_beeswarm(cex = .65, size = .5, priority = "descending")

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggbeeswarm::geom_beeswarm(cex = .65, size = .5, side = -1)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggbeeswarm::geom_quasirandom(size = .5)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggbeeswarm::geom_quasirandom(size = .5, method = "smiley")

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_eye()

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_halfeye() ## default: `.width = c(.66, .95)`

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_halfeye(.width = .5)  +
  ggtitle("stat_halfeye(.width = .5)") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"))

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_halfeye(.width = c(0, 1)) +
  ggtitle("stat_halfeye(.width = c(0, 1))") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"))

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_halfeye(.width = c(0, 1), adjust = .5, shape = 23, point_size = 3)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate, fill = purpose)) +
  ggdist::stat_halfeye(.width = 0, adjust = .5, slab_alpha = .5, shape = 21) +
  scale_fill_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_interval()

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_interval(.width = 1:4*.25, linewidth = 10) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_interval(.width = 1:4*.25) +
  ggdist::stat_dots(position = position_nudge(x = .05), scale = .8) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = year, y = orig_rate)) +
  ggdist::stat_interval(.width = 1:4*.25) +
  ggdist::stat_halfeye(.width = 0, color = "white", position = position_nudge(x = .025)) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = orig_rate, y = year)) +
  ggridges::geom_density_ridges()

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = orig_rate, y = year, fill = purpose)) +
  ggridges::geom_density_ridges(alpha = .4)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = orig_rate, y = year, fill = purpose)) +
  ggridges::geom_density_ridges(alpha = .4, color = "white", scale = 1.4, rel_min_height = .01) +
  scale_fill_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(filter(fannie_sub, first_flag == "N"), aes(x = orig_rate, y = year, fill = stat(x))) +
  ggridges::geom_density_ridges_gradient(color = "white", scale = 1.4, rel_min_height = .01) +
  scale_fill_gradient(low = "#05314D", high = "#FFB306", guide = "none")

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  geom_point(size = 3, alpha = .5)

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  geom_point(size = 3, alpha = .05)

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  ggpointdensity::geom_pointdensity(size = 3)

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  ggpointdensity::geom_pointdensity(size = 3, adjust = 1.5) +
  scale_color_gradient(low = "#FFCE52", high = "#663399")

ggplot(fannie_sub, aes(x = orig_rate, y = dti, color = purpose)) +
  geom_point(size = 3, alpha = .5) +
  scale_color_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(fannie_sub, aes(x = orig_rate, y = dti, color = purpose)) +
  geom_point(size = 3, alpha = .5) |> ggblend::blend("multiply") +
  scale_color_manual(values = c("#FFB306", "#05314D"), name = NULL)

library(ggblend)
ggplot(fannie_sub, aes(x = orig_rate, y = dti, color = purpose, partition = purpose)) +
  geom_point(size = 3, alpha = .5) * (blend("lighten") + blend("multiply", alpha = 0.5)) +
  scale_color_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(fannie_sub, aes(x = orig_rate, y = dti, color = purpose, partition = purpose)) +
  list(geom_point(size = 3, alpha = .5) * (blend("lighten") + blend("multiply", alpha = 0.5)),
       geom_vline(xintercept = mean(fannie_sub$orig_rate), color = "grey", linewidth = 7)) |> blend("hard.light") +
  scale_color_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(fannie_sub, aes(x = orig_rate, y = dti, color = purpose)) +
  geom_point(alpha = .1, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines() +
  scale_color_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(fannie_sub, aes(x = orig_rate, y = dti, color = purpose)) +
  geom_point(alpha = .1, shape = 16, size = 2) +
  ggdensity::geom_hdr_lines(method = "mvnorm", probs = c(.95, .75, .5, .25, .1)) +
  scale_color_manual(values = c("#FFB306", "#05314D"), name = NULL)

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  ggdensity::geom_hdr_points(method = "histogram", probs = c(.95, .5, .1), size = 3, alpha = .7) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  geom_density_2d_filled() +
  coord_cartesian(expand = FALSE) +
  ggtitle("geom_density_2d_filled()") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"), legend.position = "top")

ggplot(fannie_sub, aes(x = orig_rate, y = dti)) +
  ggdensity::geom_hdr(probs = seq(.999, .2, length.out = 5)) +
  coord_cartesian(expand = FALSE) +
  ggtitle("ggdensity::geom_hdr()") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"), legend.position = "top")

fannie_index <-
  fannie_raw |>
  summarize(
    loans = n(), 
    avg_rate = mean(orig_rate), 
    .by = orig_date
  ) |> 
  mutate(
    loans = loans / first(loans) - 1,
    avg_rate = avg_rate / first(avg_rate) - 1
  )

fannie_index_long <- tidyr::pivot_longer(
  fannie_index, cols = -c(orig_date), 
  names_to = "variable", values_to = "index"
)

ggplot(fannie_index, 
       aes(x = orig_date)) +
  ggbraid::geom_braid(
    aes(ymin = loans, 
        ymax = avg_rate, 
        fill = loans > avg_rate)
  ) +
  scale_fill_manual(
    values = c("#FFE8D3", "#A9BDD6"), 
    guide = "none"
  )

ggplot(fannie_index, 
       aes(x = orig_date)) +
  ggbraid::geom_braid(
    aes(ymin = loans, 
        ymax = avg_rate, 
        fill = loans > avg_rate)
  ) +
  geom_line(
    data = fannie_index_long,
    aes(y = index, color = variable),
    linewidth = 1
  ) +
  scale_y_continuous(
    labels = scales::percent
  ) +
  scale_color_manual(
    values = c("#FFB306", "#05314D"),
    name = NULL
  ) +
  scale_fill_manual(
    values = c("#FFE8D3", "#A9BDD6"), 
    guide = "none"
  )

theme_set(theme_minimal(base_size = 18, base_family = "Pally"))
theme_update(
  text = element_text(family = "Pally"),
  panel.grid = element_blank(),
  axis.text = element_text(color = "grey50", size = 12),
  axis.title = element_text(color = "grey40", face = "bold"),
  axis.title.x = element_text(margin = margin(t = 12)),
  axis.title.y = element_text(margin = margin(r = 12)),
  axis.line = element_line(color = "grey80", linewidth = .4),
  legend.text = element_text(color = "grey50", size = 12),
  plot.tag = element_text(size = 40, margin = margin(b = 15)),
  plot.background = element_rect(fill = "white", color = "white")
)

bikes <- readr::read_csv(
  "https://cedricscherer.com/data/london-bikes.csv",
  col_types = "Dcfffilllddddc"
)

bikes_sorted <-
  bikes |>
  filter(!is.na(weather_type)) |>
  group_by(weather_type) |>
  mutate(sum = sum(n)) |>
  ungroup() |>
  mutate(
    weather_type = forcats::fct_reorder(
      stringr::str_to_title(stringr::str_wrap(weather_type, 5)), sum
    )
  )

p1 <- ggplot(
  bikes_sorted,
  aes(x = weather_type, y = n, color = weather_type)
) +
  geom_hline(yintercept = 0, color = "grey80", linewidth = .4) +
  stat_summary(
    geom = "point", fun = "sum", size = 12
  ) +
  stat_summary(
    geom = "linerange", ymin = 0, fun.max = function(y) sum(y),
    size = 2, show.legend = FALSE
  ) +
  coord_flip(ylim = c(0, NA), clip = "off") +
  scale_y_continuous(
    expand = c(0, 0), limits = c(0, 8500000),
    labels = scales::comma_format(scale = .0001, suffix = "K")
  ) +
  scale_color_viridis_d(
    option = "magma", direction = -1, begin = .1, end = .9, name = NULL,
    guide = guide_legend(override.aes = list(size = 7))
  ) +
  labs(
    x = NULL, y = "Sum of reported bike shares", tag = "P1",
  ) +
  theme(
    axis.line.y = element_blank(),
    axis.text.y = element_text(family = "Pally", color = "grey50", face = "bold",
                               margin = margin(r = 15), lineheight = .9)
  )

p1

p2 <- bikes_sorted |>
  filter(season == "winter", is_weekend == TRUE, day_night == "night") |>
  group_by(weather_type, .drop = FALSE) |>
  mutate(id = row_number()) |>
  ggplot(
    aes(x = weather_type, y = id, color = weather_type)
  ) +
  geom_point(size = 4.5) +
  scale_color_viridis_d(
    option = "magma", direction = -1, begin = .1, end = .9, name = NULL,
    guide = guide_legend(override.aes = list(size = 7))
  ) +
  labs(
    x = NULL, y = "Reported bike shares on\nweekend winter nights", tag = "P2",
  ) +
  coord_cartesian(ylim = c(.5, NA), clip = "off")

p2

my_colors <- c("#cc0000", "#000080")

p3 <- bikes |>
  group_by(week = lubridate::week(date), day_night, year) |>
  summarize(n = sum(n)) |>
  group_by(week, day_night) |>
  mutate(avg = mean(n)) |>
  ggplot(aes(x = week, y = n, group = interaction(day_night, year))) +
  geom_line(color = "grey65", linewidth = 1) +
  geom_line(aes(y = avg, color = day_night), stat = "unique", linewidth = 1.7) +
  annotate(
    geom = "text", label = c("Day", "Night"), color = my_colors,
    x = c(5, 18), y = c(125000, 29000), size = 8, fontface = "bold", family = "Pally"
  ) +
  scale_x_continuous(breaks = c(1, 1:10*5)) +
  scale_y_continuous(labels = scales::comma) +
  scale_color_manual(values = my_colors, guide = "none") +
  labs(
    x = "Week of the Year", y = "Reported bike shares\n(cumulative # per week)", tag = "P3",
  )

p3

library(patchwork)

(p1 + p2) / p3

(p1 + p2) / p3 + plot_layout(guides = "collect")

((p1 + p2) / p3 & theme(legend.justification = "top")) + plot_layout(guides = "collect")

((p1 + p2) / p3 & theme(legend.position = "none")) +
  plot_layout(heights = c(.2, .1), widths = c(2, 1))

picasso <- "
AAAAAA#BBBB
CCCCCCCCC##
CCCCCCCCC##"

(p1 + p2 + p3 & theme(legend.position = "none")) + plot_layout(design = picasso)

pl1 <- p1 + labs(tag = NULL, title = "Plot One") + theme(legend.position = "none")
pl2 <- p2 + labs(tag = NULL, title = "Plot Two") + theme(legend.position = "none")
pl3 <- p3 + labs(tag = NULL, title = "Plot Three") + theme(legend.position = "none")

(pl1 + pl2) / pl3 +
  plot_annotation(tag_levels = "1", tag_prefix = "P", title = "An overarching title for all 3 plots, placed on the very top while all other titles are sitting below the tags.")

pl1 + inset_element(pl2, l = .6, b = .1, r = 1, t = .6)

pl1 + inset_element(pl2, l = .6, b = 0, r = 1, t = .5, align_to = 'full')

library(ggplot2)

theme_set(
  theme_minimal(
    base_size = 13,
    base_family = "Asap SemiCondensed"
  )
)

theme_update(
  panel.grid.minor = element_blank(),
  plot.title.position = "plot",
  legend.position = "top",
  legend.justification = "left"
)

smooth <- TRUE

ggplot(fannie_sub, aes(x = cscore_b, y = orig_rate)) +
  geom_point(alpha = .5) +
  { if(smooth) geom_smooth(color = "red") }

smooth <- FALSE

ggplot(fannie_sub, aes(x = cscore_b, y = orig_rate)) +
  geom_point(alpha = .5) +
  { if(smooth) geom_smooth(color = "red") }

draw_scatter <- function(smooth = TRUE) {
  ggplot(fannie_sub, aes(x = cscore_b, y = orig_rate)) +
    geom_point(alpha = .5) +
    { if(smooth) geom_smooth(color = "red") }
}

draw_scatter()

draw_scatter(smooth = FALSE)

geom_scatterfit <- function(pointsize = 1, pointalpha = 1, 
                            method = "lm", linecolor = "red", ...) {
  list(
    geom_point(size = pointsize, alpha = pointalpha, ...),
    geom_smooth(method = method, color = linecolor, ...)
  )
}

ggplot(fannie_sub,
       aes(x = cscore_b, y = orig_rate)) +
  geom_scatterfit()

ggplot(fannie_sub,
       aes(x = cscore_b, y = orig_rate)) +
  geom_scatterfit(
    color = "#FFB306", 
    linewidth = 3
  )

ggplot(diamonds, 
       aes(x = carat, y = price)) +
  geom_scatterfit(
    pointsize = .5, 
    pointalpha = .1,
    method = "gam",
    linecolor = "#FFB306"
  )

scales_log <- function(sides = "xy") {
  list(
    if(stringr::str_detect(sides, "x")) {
      scale_x_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    },
    if(stringr::str_detect(sides, "y")) {
      scale_y_log10(
        breaks = c(10^(1:100)), labels = scales::label_log()
      )
    }
  )
}

ggplot(diamonds, 
       aes(x = carat, y = price)) +
  geom_scatterfit(
    pointsize = .5, 
    pointalpha = .1,
    method = "gam",
    linecolor = "#EFAC00"
  ) +
  scales_log(sides = "y")

trends_monthly <- function(grp = "January") {
  fannie_sub |> 
    mutate(month = lubridate::month(orig_date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = orig_rate, y = dti, color = purpose)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    scale_color_manual(values = c("#FFB306", "#05314D")) +
    labs(title = grp, x = "Interest rate", y = "Debt-to-income ratio", color = NULL)
}

trends_monthly("July")

trends_monthly <- function(grp = "January") {
  fannie_sub |> 
    mutate(month = lubridate::month(orig_date, label = TRUE, abbr = FALSE)) |> 
    filter(month %in% grp) |> 
    ggplot(aes(x = orig_rate, y = dti, color = purpose)) +
    geom_point(alpha = .2, show.legend = FALSE) +
    geom_smooth(se = FALSE) +
    # keep axis ranges consistent
    scale_x_continuous(limits = range(fannie_sub$orig_rate)) +
    scale_y_continuous(limits = range(fannie_sub$dti)) +
    scale_color_manual(values = c("#FFB306", "#05314D")) +
    labs(title = grp, x = "Interest rate", y = "Debt-to-income ratio", color = NULL)
}

trends_monthly("July")

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
plots[[9]]

plots <- purrr::map(month.name[1:12], trends_monthly) ## also: ~ trends_monthly(.x)
patchwork::wrap_plots(plots)

plot_density <- function(data, var, grp = "") {
  ggplot(data, aes(x = !!sym(var))) +
    geom_density(aes(fill = !!sym(grp)), position = "identity",
                 color = "grey30", alpha = .3) +
    coord_cartesian(expand = FALSE, clip = "off") +
    scale_y_continuous(labels = scales::label_number()) +
    scale_fill_brewer(palette = "Dark2", name = NULL) +
    theme(legend.position = "top")
}

plot_density(
  fannie_sub, "dti"
)

plots <- purrr::map(
  c("dti", "cscore_b", "orig_rate", "orig_upb"), 
  ~ plot_density(data = fannie_sub, var = .x, grp = "purpose")
)
patchwork::wrap_plots(plots, nrow = 1)

plots <- purrr::map(
  c("sleep_total", "sleep_rem", "sleep_cycle"), 
  ~ plot_density(data = filter(msleep, !is.na(vore)), var = .x, grp = "vore")
)
patchwork::wrap_plots(plots, nrow = 1)

plots <- purrr::map(
  names(select(midwest, where(is.numeric))),
  ~plot_density(data = midwest, var = .x)
)
patchwork::wrap_plots(plots)

plot(fannie_sub[, 2:5])

ggplot(fannie_sub, aes(x = .panel_x, y = .panel_y)) +
  geom_point() +
  ggforce::facet_matrix(
    vars(orig_rate, cscore_b, dti, orig_upb)
  )

ggplot(fannie_sub, aes(x = .panel_x, y = .panel_y)) +
  geom_point(aes(color = purpose), alpha = .25) +
  ggdensity::geom_hdr_lines(aes(color = purpose), linewidth = .5) +
  ggforce::geom_autodensity() +
  scale_color_brewer(palette = "Set2", name = NULL) +
  ggforce::facet_matrix(
    vars(orig_rate, cscore_b, dti, orig_upb),
    layer.lower = 2, layer.diag = 3
  )

p1 <- 
  ggplot(fannie_agg, aes(x = orig_date, y = loans, color = purpose, group = purpose)) +
  ggiraph::geom_line_interactive(aes(tooltip = purpose, data_id = purpose), linewidth = 1) +
  scale_color_manual(values = c("#FFB306", "#05314D"), guide = "none")

ggiraph::set_girafe_defaults(
  opts_zoom = ggiraph::opts_zoom(min = 1, max = 4),
  opts_toolbar = ggiraph::opts_toolbar(position = "bottomright")
)

ggiraph::girafe(
  ggobj = p1, width_svg = 9, height_svg = 5.5,
  options = list(
    ggiraph::opts_hover_inv(css = "opacity:0.3;"),
    ggiraph::opts_hover(css = "stroke-width:5;")
  )
)

p2 <- 
  ggplot(fannie_agg, aes(x = orig_date, y = loans, color = purpose)) +
  ggiraph::geom_point_interactive(aes(tooltip = paste("<b style='font-size:12pt;'>", sprintf("%3.1f", loans / 1000), "K loans</b><br>in", format(orig_date, "%B %Y")), data_id = orig_date), size = 3, alpha = .7) +
  ggforce::geom_mark_rect(
    aes(label = "First Year of COVID", filter = loans > 190000),
    description = "Refinance mortgage loans between April '20 and April '21",
    color = "black", label.family = "Asap SemiCondensed", label.fontsize = c(18, 14)
  ) +
  coord_cartesian(clip = "off") +
  scale_color_manual(values = c("#E39F03", "#05314D"), guide = "none") +
  ggtitle("<b style='color:#FFB306;'>Purchase money mortgages</b> versus <b style='color:#05314D;'>refinance mortgages</b>") +
  theme(plot.title = ggtext::element_markdown(size = 20, margin = margin(b = 25))) 

ggiraph::girafe(
  ggobj = p2, width_svg = 9, height_svg = 5.5,
  options = list(
    ggiraph::opts_tooltip(use_fill = TRUE, css = "font-size:9pt;color:white;padding:7px;font-family:asap;"), 
    ggiraph::opts_hover(css = "stroke-width:8px;opacity:1;"),
    ggiraph::opts_hover_inv(css = "opacity:0.3;")
  )
)
