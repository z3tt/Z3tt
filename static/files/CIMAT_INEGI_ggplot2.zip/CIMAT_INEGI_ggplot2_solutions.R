#------------------------------------------------------------------------------#
#                                                                              #
#                        Hands-On Data Visualization in R:                     # 
#                   How to create engaging charts with ggplot2                 #
#                                                                              #
#                                  SOLUTIONS                                   #
#                                                                              #
#                     Dr. Cédric Scherer | January 14, 2022                    #
#                                                                              #
#------------------------------------------------------------------------------#



## GEOMETRICAL LAYERS (EXERCISE) ###############################################

library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/z3tt/ggplot-courses/master/data/chicago-nmmaps-custom.csv",
  col_types = cols(season = col_factor(), year = col_factor())
)

# Turn our scatter plot into a line chart and into a bar chart!

ggplot(chic, aes(x = date, y = temp)) +
  geom_line()

ggplot(chic, aes(x = date, y = temp)) +
  geom_bar()

?geom_bar

ggplot(chic, aes(x = date, y = temp)) +
  geom_col()

# What’s the difference between `geom_path()` and `geom_line()`?

?geom_line ## or ?geom_path

# Create a box plot of temperature per date.

ggplot(chic, aes(x = date, y = temp)) +
  geom_boxplot()

# What is the problem? How could you find out why this is happening?

ggplot(chic, aes(factor(date), temp)) +
  geom_boxplot()

ggplot(chic, aes(factor(month_numeric), temp)) +
  geom_boxplot()

ggplot(chic, aes(year, temp)) +
  geom_boxplot()

ggplot(chic, aes(x = season, y = temp)) +
  geom_boxplot()



## AESTHETICS + SCALES (EXERCISE) ##############################################

# A training data set focusing on cars comes with `ggplot2` and is called `mpg`.
# Create the following visualization:

ggplot(mpg, aes(x = hwy, y = displ, color = hwy < 33)) +
  geom_point(
    size = 3,
    alpha = .3
  )

ggplot(mpg, aes(x = hwy, y = displ, color = hwy < 33)) +
  stat_smooth() +
  geom_point(
    size = 3,
    alpha = .3
  )

ggplot(mpg, aes(x = hwy, y = displ, color = hwy < 33)) +
  stat_smooth() +
  geom_point(
    aes(color = hwy < 33),
    size = 3,
    alpha = .3
  )

ggplot(mpg, aes(x = hwy, y = displ)) +
  stat_smooth(
    color = "black",
    fill = "grey80"
  ) +
  geom_point(
    aes(color = hwy < 33),
    size = 3,
    alpha = .3
  ) +
  scale_color_manual(values = c("red", "black"))

ggplot(mpg, aes(x = hwy, y = displ)) +
  stat_smooth(
    color = "black",
    fill = "grey80"
  ) +
  geom_point(
    aes(color = hwy < 33),
    size = 3,
    alpha = .3
  ) +
  scale_color_manual(values = c("red", "black")) +
  labs(
    x = "Highway Miles per Gallon",
    y = "Engine Displacement (litres)"
  )

## END #########################################################################
