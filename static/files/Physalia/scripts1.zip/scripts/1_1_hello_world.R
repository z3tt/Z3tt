########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 9-13 2020 #
########################################################################

#### INTRODUCTION ######################################################
#-----------------------------------------------------------------------

## This is the script pane

## A line starting with a hash (#) is a comment,
## a line without is actual code to run

print("hello world!") # <- this is code!

## In the folllowing, I am going to indicate 
## TASKS as #!! and QUESTIONS as #??

#!! Go back to line 9 and hit the "Run" button or 
#!! Ctrl+Enter on Win and Linux/Cmd+Enter on Mac

#!! Now look at the pane below, the console:

## There is a line starting with ">":
## -> This is the R code you have run

## And there is a line starting with "[1]":
## -> This is the output of R

#?? What happens if you just run `"hello world!"`?
#?? What if you run `hello world` without the quotes?
