########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 9-13 2020 #
########################################################################


#### THE STRUCTURE OF GGPLOT2 (continued) ##############################
#-----------------------------------------------------------------------

## Geometric Layers: geom_*() ------------------------------------------

## geom_*() are geometrical layers directly applied to the data:

## Our scatter plot as a line plot:
ggplot(chic, aes(date, temp)) +
  geom_line()

## ... or as a bar plot:
ggplot(chic, aes(date, temp)) +
  geom_col()

## ... or a box and whiskers plot:
ggplot(chic, aes(date, temp)) +
  geom_boxplot()

## We need to specify the variable as categorial, not as continuous:
ggplot(chic, aes(as.factor(date), temp))
  geom_boxplot() 

class(chic$year)
class(chic$season)
    
ggplot(chic, aes(year, temp)) +
    geom_boxplot() 

ggplot(chic, aes(season, temp)) +
  geom_boxplot() 

## Other layers can be added to an existing plot
## For example, we add a line and a rug representation:

ggplot(chic, aes(date, temp)) +
  geom_point() +
  geom_line()
  geom_rug(sides = "r")
  
## Add labels

## You can change the axes titles by adding `xlab()` and `ylab()` 
## to your ggplot:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  xlab("Day of the Year") +
  ylab("Temperature (°F)")

## ... and a title by adding `ggtitle()`:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  xlab("Day of the Year") + 
  ylab("Temperature (°F)") +
  ggtitle("Seasonal Change of Temperatures in Chicago")

## Using `labs()` you can also change all and more in one go:
ggplot(chic, aes(date, temp)) +
  geom_point() +
  labs( #<<
    x = "Day of the Year",  
    y = "Temperature (°F)", 
    title = "Seasonal Change of Temperatures in Chicago",
    subtitle = "Daily temperatures (°F) in the city of Chicago, IL,\nmeasured between 1997 and 2001",
    caption = "Data: National Morbidity and Mortality Air Pollution Study (NMMAPS)",
    tag = "Fig. 1"
  )

## Side note: ggplots as objects
g <- ggplot(chic, aes(date, temp)) +
  geom_point()

g + 
  geom_line() +
  geom_rug(sides = "r")

## Side note: save ggplots
ggsave(filename = "my_first_ggplot.pdf", fig.width = 10, fig.height = 7, device = cairo_pdf)
ggsave(filename = "my_first_ggplot.png", fig.width = 10, fig.height = 7, dpi = 300)

ggsave(filename = "my_first_ggplot.pdf", plot = g, fig.width = 10, fig.height = 7, device = cairo_pdf)
ggsave(filename = "my_first_ggplot.png", plot = g, fig.width = 10, fig.height = 7, dpi = 300)


#!! Open Exercise_3_1.R
