########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 9-13 2020 #
########################################################################

#### DATA TRANSFORMATION WITH DPLYR ####################################
#-----------------------------------------------------------------------

  
## The package ---------------------------------------------------------

## `dplyr` is a package designed for data wrangling in R
  
## `dplyr` is part of the tidyverse, a set of packages
## that work in harmony to manipulate and explore data.
## (https://blog.rstudio.org/2016/09/15/tidyverse-1-0-0/)
  
library(tidyverse)

## The data ------------------------------------------------------------

## We use count and proportional data of baby names used for at least 
## five children in the US per sex and year from 1880 to 2017.
## Data source: US  Social Security Administration (SSA)

# Available as data set `babynames` in the package `babynames`:
install.packages("babynames")

## See also `??babynames`

## Inspect data
tibble::glimpse(babynames)

## Train Your ggplot muscles!
#!! Create the two example plots (exercise-4-1.png and exercise-4-2.png)


## Main functions (verbs) of dyplr --------------------------------------

## filter(): pick rows with matching criteria
## arrange(): reorder rows
## select(): pick columns with matching criteria
## mutate(): create new variables
## summarise(): sum up data
## group_by(): create subsets


## Syntax --------------------------------------------------------------

## Consistent Syntax of `dplyr`

## All functions take the same main arguments:
## The first argument is your data, subsequent arguments say what to do 
## with the data frame, using the variable names-

## `verb(data, condition)`


## filter() -------------------------------------------------------------
## allows you to select a subset of rows

filter(babynames, year == 2000, n > 25000)

## Equivalent code in base R:
babynames[babynames$year == 2000 & babynames$n > 25000, ]

filter(babynames, (name == "Cedric" | name == "Robert"))

filter(babynames, (name == "Cedric" | name == "Robert") & year %in% 1900:1905)


## select() -------------------------------------------------------------
## allows you to select a subset of columns

select(babynames, name, year, n)

## Equivalent code in base R:
babynames[, c("name", "year", "n")]

select(babynames, -prop, -sex)


## arrange() -------------------------------------------------------------
## allows you to order rows by variables

arrange(babynames, prop)

## Equivalent code in base R:
babynames[order(babynames$prop), ]

arrange(babynames, year, sex, -prop)


## mutate() --------------------------------------------------------------
## allows you to create new variables

# either based on some other variables:
mutate(babynames, decade = year %% 10 * 10)

## Equivalent code in base R:
transform(babynames, decade = year %% 10 * 10)

mutate(babynames, name = str_to_lower(name))

mutate(babynames, note = if_else(year < 1900, "Please check!", "Ok"))

## ... or independent from the rest of your data:
mutate(babynames, note = "Please check!")

mutate(babynames, id = row_number())

## You can use new variables in the same mutate call for other operations:
mutate(mpg2, diff = hwy - cty, perc = diff / hwy)

## Equivalent code in base R:
mpg_diff <- transform(mpg2, diff = hwy - cty)
transform(mpg_diff, perc = diff / hwy)

## mutate_if() 
## allows you to conditionally create several new columns in one step:

mpg2 <- select(mpg, model, hwy, cty) ## only to see what happens

mutate_if(mpg2, is.numeric, as.character)

mutate_if(mpg2, is.numeric, list(avg = mean, log_2 = log2))

mutate_if(mpg2, is.numeric, list(~mean(., na.rm = T), ~log2(.)))

mutate_at(mpg2, c("hwy", "cty"), mean, na.rm = TRUE)

mutate_all(mpg2, mean, na.rm = TRUE)

## muate_all()
## allows you to transform all columns in one step

mutate_all(mpg2, mean, na.rm = TRUE)

mutate_all(mpg2, list(~mean(., na.rm = T), ~nchar(.)))


## summarize() -----------------------------------------------------------
## allows you to calculate summary statistics for particular variables

summarize(babynames, unique_children = sum(n, na.rm = TRUE))

## Equivalent code in base R:
sum(babynames$n, na.rm = TRUE)

summarize(babynames, n = n())

## group_by() -----------------------------------------------------------
## allows you to break down your data into groups based on variables

group_by(babynames, sex)

grouped <- group_by(babynames, sex, year)
ungroup(grouped)

## group_by() in combination with other `dplyr` verbs allows you to 
## calculate summary statistics for specified groups:

(names_group <- group_by(babynames, sex))

summarize(names_group, sum = sum(n))

names_cent <- filter(babynames, year %in% c(1890, 1900))
names_cent <- group_by(names_cent, sex, year)
names_cent

names_cent <- mutate(names_cent, sum = sum(n))
names_cent <- group_by(names_cent, sex, year, name)
names_cent

names_sum <- summarize(
  names_cent, 
  prop = prop, 
  prop_check = sum(n) / unique(sum)
)
arrange(names_sum, desc(sex), -prop_check)

## Issues with code readability

names_cent <-
  group_by(mutate(group_by(filter(babynames, year %in% c(1890, 1900)), sex, year), sum = sum(n)), sex, year, name)
names_sum <-
  ungroup(arrange(summarize(names_cent, prop = prop, prop_check = sum(n) / unique(sum)), desc(sex), -prop_check))
names_sum

names_cent <-
  group_by(
    mutate(
      group_by(
        filter(
          babynames,
          year %in% c(1890, 1900)
        ),
        sex, year
      ),
      sum = sum(n)
    ),
    sex, year, name
  )
names_sum <-
  ungroup(
    arrange(
      summarize(
        names_cent,
        prop = prop,
        prop_check = sum(n) / unique(sum)
      ),
      desc(sex), -prop_check
    )
  )


## The `magrittr` package --------------------------------------------------

## The `magrittr` offers the so-called pipe: %>%

## two steps
names_cent <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name)

names_sum <-
  names_cent %>%
  summarize(
    prop = prop,
    prop_check = sum(n) / unique(sum)
  ) %>%
  arrange(desc(sex), -prop_check) %>%
  ungroup()

names_sum

## in one step:
names_sum <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name) %>%
  summarize(
    prop = prop,
    prop_check = sum(n) / unique(sum)
  ) %>%
  arrange(desc(sex), -prop_check) %>%
  ungroup()

names_sum

## This way, you can also easily inactivate verbs or single conditions:

names_sum <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name) %>%
  summarize(
    #prop = prop, #<<
    prop_check = sum(n) / unique(sum)
  ) %>%
  arrange(desc(sex), -prop_check) %>%
  ungroup()

names_sum <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name) %>%
  summarize(
    #prop = prop,
    prop_check = sum(n) / unique(sum)
  ) %>%
  #arrange(desc(sex), -prop_check) %>% #<<
  ungroup()

names_sum <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name) %>%
  summarize(
    #prop = prop,
    prop_check = sum(n) / unique(sum)
  ) %>%  
  #arrange(desc(sex), -prop_check) %>%
  #ungroup()
  
names_sum <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name) %>%
  summarize(
    #prop = prop,
    prop_check = sum(n) / unique(sum)
  ) #%>% #<< ## comment as well
  #arrange(desc(sex), -prop_check) %>%
  #ungroup()

names_sum <-
  babynames %>%
  filter(year %in% c(1890, 1900)) %>%
  group_by(sex, year) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, year, name) %>%
  summarize(
    #prop = prop,
    prop_check = sum(n) / unique(sum)
  ) %>%
  #arrange(desc(sex), -prop_check) %>%
  #ungroup() %>%
  {} ##<< ... or add this

## You can also pipe into a `ggplot()` call 
## (but don't forget to use `+` afterwards, not `%>%`): 

babynames %>%
  filter(year == 1900) %>%
  group_by(sex) %>%
  mutate(sum = sum(n)) %>%
  group_by(sex, name) %>%
  summarize(
    prop = sum(n) / unique(sum)
  ) %>%
  filter(prop >= .02) %>% 
  ggplot(aes(prop, name,
         color = sex)) +
    geom_segment(
      aes(xend = 0, yend = name),
      size = 2
    ) +
    geom_point(
      size = 4
    )


#!! Inspect the `flights` data set from the `nycflights13` package.

#!! Count the number of flights in June and July 2013.

#!! Find out how many flights did catch up their departure delay.

#!! Create a table that contains the average delays per origin and month, ordered by maximum arrival delay. (Bonus: Delays with 1 digit only.)

#!! Explore the relationship between the average distance and average delay per season and destination. 

#!! Create the Post-WII line plot (exercise-4-3.png)


