########################################################################
# Physalia Course "Introduction to DataVisualization in R with ggplot2 #
# Cédric Scherer (cedricphilippscherer@gmail.com) | November 9-13 2020 #
########################################################################

#### SCALES + COORDINATE SYSTEMS #######################################
#-----------------------------------------------------------------------


## One can use scale_*() functions to change properties of all the 
## aesthetic dimensions mapped to the data.

## Consequently, there are functions for all aesthetics such as:
##    * positions via scale_x_*() and scale_y_*()
##    * colors via scale_color_*() and scale_fill_*()
##    * sizes via scale_size_*() and scale_radius_*()
##    * shapes via scale_shape_*()  and scale_linetype_*()
##    * transparency via scale_alpha_*()


## Preparation ---------------------------------------------------------

library(tidyverse)

chic <- read_csv(
  "https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/chicago-nmmaps.csv",
    col_types = cols(season = col_factor(), year = col_factor())
)

(g <- ggplot(chic, aes(year, temp, color = season)) +
  geom_jitter(size = 3, alpha = .3,
              position = position_jitter(width = .35, seed = 2020)))


## SCALE_X|Y_*() #######################################################

## scale_x|y_continuous() ----------------------------------------------

g + scale_y_continuous(limits = c(0, 50))

g + scale_y_continuous(limits = c(0, NA))

g + scale_y_continuous(limits = c(0, NA), expand = c(0, 0))

g + scale_y_continuous(limits = c(0, NA), expand = c(1, 1))

g + scale_y_continuous(limits = c(0, NA), expand = c(.02, .02))

g + scale_y_continuous(
      name = "Temperature in Chicago (°F)",
      limits = c(0, NA),
      expand = c(.02, .02)
    )

g + scale_y_continuous(
      name = "Temperature in Chicago (°F)",
      limits = c(0, NA),
      expand = c(.02, .02),
      breaks = seq(0, 80, by = 10)
    )

g + scale_y_continuous(
        name = "Temperature in Chicago",
        limits = c(0, NA),
        expand = c(.02, .02),
        breaks = seq(0, 80, by = 10),
        labels = glue::glue("{seq(0, 80, by = 10)}°F"),
      )

g + scale_y_continuous(
      name = "Temperature in Chicago",
      limits = c(0, NA),
      expand = c(.02, .02),
      breaks = seq(0, 80, by = 10),
      labels = glue::glue("{seq(0, 80, by = 10)}°F"),
      position = "right" 
    )

g + scale_y_continuous(
      name = "Temperature in Chicago",
      limits = c(0, NA),
      expand = c(.02, .02),
      breaks = seq(0, 80, by = 10),
      labels = glue::glue("{seq(0, 80, by = 10)}°F"),
      sec.axis = dup_axis(name = "") 
    )

g + scale_y_continuous(
      name = "Temperature in Chicago",
      limits = c(0, NA),
      expand = c(.02, .02),
      breaks = seq(0, 80, by = 10),
      labels = glue::glue("{seq(0, 80, by = 10)}°F"),
      sec.axis = sec_axis(~ . + 10)
    )

      
## scale_x|y_discrete() ------------------------------------------------

g + scale_x_discrete(name = "Year", expand = c(.1, .1))

g + scale_x_discrete(
      name = "Year",
      expand = c(.1, .1),
      breaks = c(1997, 2000), 
      labels = c("MCMXCVII", "MMI") 
    )


## scale_x|y_reverse() -------------------------------------------------

g + 
  #scale_x_reverse() + 
  ## doen't work with factors
  scale_y_reverse() 

  
## scale_x|y_log10() ---------------------------------------------------

g +
  #scale_x_log10() +
  ## doen't work with factors
  scale_y_log10() 


## scale_x|y_sqrt() ----------------------------------------------------
  
  g + 
    #scale_x_sqrt() + 
    ## doen't work with factors
    scale_y_sqrt() 


## scale_x|y_date() ----------------------------------------------------

chic %>% 
  filter(year %in% 1997:1998) %>% 
  ggplot(aes(temp, date)) +
  geom_point(aes(color = season)) +
  scale_y_date( 
    date_breaks = "1 month", 
    date_labels = "%Y-%m-%d", 
    expand = c(.01, .01) 
  ) 


## SCALE_COLOR|FILL_*() ################################################

## scale_fill|color_continuous() ---------------------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_continuous( 
    guide = "none" 
  ) 

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_continuous(
    name = "Ozone\nLevel" 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_continuous(
    name = "Ozone\nLevel",
    type = "viridis" 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_continuous(
    name = "Ozone\nLevel",
    type = "viridis",
    breaks = seq(0, 60, length.out = 5) 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_continuous(
    name = "Ozone\nLevel",
    type = "viridis",
    breaks = seq(0, 60, length.out = 4),
    limits = c(0, 60) 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_continuous(
    name = "Ozone\nLevel",
    type = "viridis",
    breaks = seq(0, 60, length.out = 4),
    limits = c(0, 60),
    labels = c("very low", "low", 
               "high", "very high") 
  )


## scale_fill|color_discrete() -----------------------------------------

g +
  scale_color_discrete( 
    h = c(0, 260), ## hue: [0,360] 
    c = 500, ## chroma: [0,x] 
    l = 90 ## luminance: [0,100] 
  ) 
g +
  scale_color_discrete(
    h = c(0, 260), ## hue: [0,360]
    c = 500, ## chroma: [0,x] 
    l = 90, ## luminance: [0,100]
    labels = c("Dec-Feb", "Mar-May", 
               "June-Aug", "Sep-Nov") 
  )

chic %>% 
  group_by(date) %>% 
  mutate( 
    season = if_else( 
      runif(1, min = 0, max = 1) > .9,  
      NA_integer_,  
      as.integer(season) 
    )) %>%  
  ggplot(
    aes(
      year, temp, 
      color = as.factor(season)
    )) +
  geom_jitter(
    size = 1.3, 
    width = .35
  ) +
  scale_color_discrete(
    h = c(0, 60),  ## hue: [0,360]
    na.value = "black" 
  )


## scale_fill|color_manual() -------------------------------------------
g +
  scale_color_manual( 
    values = c("blue", "seagreen", 
               "firebrick", "orange") 
  ) 


## scale_fill|color_gradient() -----------------------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_gradient( 
    low = "dodgerblue", 
    high = "red" 
  ) 


## scale_fill|color_gradient2() ----------------------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_gradient2( 
    low = "dodgerblue",
    mid = "grey80", 
    high = "red"
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_gradient2(
    low = "dodgerblue",
    mid = "grey80",
    high = "red",
    midpoint = mean(chic$o3) 
  )


## scale_fill|color_brewer() -------------------------------------------

g + scale_color_brewer() 

g + scale_color_brewer(palette = 8)

g + scale_color_brewer(palette = "YlGnBu")

g + scale_color_brewer(
      type = "seq", ## the default  
      palette = "YlGnBu"
    )

g +
  scale_color_brewer(
    type = "qual" 
  )

g +
  scale_color_brewer(
    type = "qual",
    palette = "Dark2" 
  )

g +
  scale_color_brewer(
    type = "div" 
  )


## scale_fill|color_distiller() ----------------------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_distiller() 

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_distiller(
    palette = "PuRd" 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_distiller(
    palette = "PuRd",
    direction = 1 ## note that -1 is the default
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_distiller(
    type = "div" 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_distiller(
    type = "div",
    palette = "Spectral" 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scale_color_distiller(
    type = "qual" 
  )


## Several packages offer predefined palettes, e.g.:
  
## viridis for perceptually uniform palettes
## scico for more perceptually uniform palettes
## rcartocolor for map color palettes
## ggsci for scientific journal and sci-fi themed color
## ggthemes for colors of popular software & publishers
## LaCroixColoR for vibrant summery colors

## Also check this collection for an extensive list of color palettes:
## https://github.com/EmilHvitfeldt/r-color-palettes/blob/master/type-sorted-palettes.md)
  

## viridis::scale_fill|color_viridis() ---------------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  viridis::scale_color_viridis( 
    option = "magma" 
  ) 

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  viridis::scale_color_viridis(
    option = "magma",
    end = .8 
  )

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  viridis::scale_color_viridis(
    option = "cividis", 
    direction = -1 
  )


## scico::scale_color|fill_scico() -------------------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  scico::scale_color_scico( 
    palette = "berlin" 
  ) 


## rcartocolor::scale_color|fill_carto_c() -----------------------------

ggplot(chic, aes(date, temp)) + 
  geom_point(aes(color = o3)) +
  rcartocolor::scale_color_carto_c( 
    palette = "Temps" 
  ) 


## ggsci::scale_color|fill_*() -----------------------------------------

ggplot(chic, aes(season, temp)) + 
  geom_boxplot(aes(fill = year)) +
  ggsci::scale_fill_npg()



## SCALE_SIZE|RADIUS_*() ###############################################


chic2k <- filter(chic, year == 2000)
    
ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  )


## scale_size() --------------------------------------------------------

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  ) +
  scale_size( 
    range = c(.1, 5) 
  ) 

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  ) +
  scale_size(
    range = c(.1, 5),
    breaks = c(25, 75, 125) 
  )

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  ) +
  scale_size(
    range = c(.1, 5),
    breaks = c(25, 75, 125),
    trans = "reverse" 
  )

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  ) +
  scale_size(
    range = c(.1, 5),
    breaks = c(25, 75, 125),
    trans = "exp" 
  )

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  ) +
  scale_size_binned( 
    n.breaks = 3, 
    range = c(.5, 5) 
  ) 


## scale_radius() ------------------------------------------------------

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(size = pm10),
    alpha = .4
  ) +
  scale_radius()


## SCALE_SIZE|LINETYPE_*() #############################################

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(shape = season),
    size = 2.5
  )


## scale_shape() -------------------------------------------------------

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(shape = season),
    size = 2.5
  ) +
  scale_shape( 
    name = "Season of\nthe Year" 
  ) 


## scale_shape_manual() ------------------------------------------------
  
ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(shape = season),
    size = 2.5
  ) +
  scale_shape_manual( 
    name = "Season of\nthe Year", 
    values = 9:12 
  ) 

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(
      shape = season,
      fill = season 
    ),
    size = 2.5,
    alpha = .75
  ) +
  scale_shape_manual(
    name = "Season of\nthe Year",
    values = 21:24 
  ) +
  scale_fill_brewer( 
    palette = "Dark2" 
  ) 

ggplot(chic2k, aes(date, temp)) +
  geom_point(
    aes(
      shape = season,
      fill = season
    ),
    size = 2.5,
    alpha = .75
  ) +
  scale_shape_manual(
    name = "Season of\nthe Year",
    values = 21:24
  ) +
  scale_fill_brewer(
    palette = "Dark2",
    name = "Season of\nthe Year" 
  )


## scale_linetype_*() --------------------------------------------------

chic_wy <- 
  chic %>% 
  mutate(
    week = lubridate::week(date)
  ) %>% 
  group_by(week, year) %>% 
  summarize(temp = mean(temp))

ggplot(chic_wy, aes(week, temp)) +
  geom_line(
    aes(linetype = year),
    size = .7
  )


## scale_linetype_manual() ---------------------------------------------

ggplot(chic_wy, aes(week, temp)) +
  geom_line(
    aes(linetype = year),
    size = .7
  ) +
  scale_linetype_manual( 
    name = "Year:", 
    values = c("dotted", 
               "twodash", 
               "longdash", 
               "dotdash") 
  ) 

ggplot(chic_wy, aes(week, temp)) +
  geom_line(
    aes(
      linetype = year,
      color = year 
    ),
    size = .7
  ) +
  scale_linetype_manual(
    name = "Year:",
    values = c("dotted",
               "twodash",
               "longdash",
               "dotdash")
  ) +
  scale_color_brewer( 
    name = "Year:", 
    palette = "Set1", 
  ) 


## SCALE_ALPHA_*() #####################################################

chic_month <-
  chic %>% 
  mutate(
    month = lubridate::month(
      date,
      label = T
    )
  ) %>% 
  group_by(month) %>% 
  summarize(
    temp = mean(temp),
    n = n()
  ) %>% 
  ungroup()

chic_month

ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = n), 
    size = 8,
    color = "purple"
  )


## scale_alpha() -------------------------------------------------------
  
ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = n), 
    size = 8,
    color = "purple"
  ) +
  scale_alpha( 
    range = c(.3, 1) 
  ) 

ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = n), 
    size = 8,
    color = "purple"
  ) +
  scale_alpha( 
    range = c(.3, 1),
    breaks = c( 
      min(chic_month$n), 
      floor(mean(chic_month$n)), 
      max(chic_month$n) 
    ) 
  )

ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = n), 
    size = 8,
    color = "purple"
  ) +
  scale_alpha( 
    name = "Observations:", 
    range = c(.3, 1),
    breaks = c(
      min(chic_month$n),
      floor(mean(chic_month$n)),
      max(chic_month$n) 
    ),
    labels = c( 
      "Minimum (113)", 
      "Average (121)", 
      "Maximum (124)" 
    ) 
  )


## scale_alpha_continuous() --------------------------------------------

ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = n), 
    size = 8,
    color = "purple"
  ) +
  scale_alpha_continuous(  
    name = "Observations:",
    range = c(.3, 1),
    breaks = c(
      min(chic_month$n),
      floor(mean(chic_month$n)),
      max(chic_month$n) 
    ),
    labels = c(
      "Minimum (113)",
      "Average (121)",
      "Maximum (124)" 
    )
  )


## scale_alpha_discrete() ----------------------------------------------

ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = as.factor(n)), 
    size = 8,
    color = "purple"
  ) +
  scale_alpha_discrete(  
    name = "Observations:",
    range = c(.3, 1)
  )

ggplot(chic_month, aes(month, temp)) +
  geom_point(
    aes(alpha = as.factor(n)), 
    size = 8,
    color = "purple"
  ) +
  scale_alpha_manual(  
    name = "Observations:",
    values = c(.3, .8, 1) 
  )


#!! Visualize the relationship of temperature and Ozone in Chicago using a 
#   hexagonal binning and a (non-green) viridis color palette.
#!! Afterwards, make the axis title more decriptive and change the legend 
#   title to "Count:".
#!! Now change the x axis so it shows the temperature every 10°F in a range 
#   of -10°F to 90°F.
#!! Turn the labels on the y axis into two string labels (e.g. "low" and 
#   "high).
#!! Explore some other color palettes that are available in other packages, 
##  pick one you like and change the color palette of the plot.
#!! Check if your final plot is color-blindness safe either online, e.g. 
##  color-blindness.com/coblis-color-blindness-simulator or using the package `
##  colorblindr` (You need to install again some development versions of
#   packages, follow the instructions on https://github.com/clauswilke/colorblindr)



## CONTROL LEGENDS #####################################################

ggplot(chic, aes(temp, o3)) +
  geom_hex(aes(color = ..count..)) +
  viridis::scale_color_viridis(
    guide = "colorbar"
  ) +
  viridis::scale_fill_viridis(
    guide = "legend"
  ) 

ggplot(chic, aes(temp, o3)) +
  geom_hex(aes(color = ..count..)) +
  viridis::scale_color_viridis(
    guide = "colorsteps"
  ) +
  viridis::scale_fill_viridis(
    guide = "bins"
  )
 
ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(
      color = temp,
      size = pm10
    )
  ) +
  viridis::scale_color_viridis() +
  guides(
    color = "legend"
  )
    
ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(
      color = temp,
      size = pm10
    )
  ) +
  viridis::scale_color_viridis() +
  guides(
    color = guide_legend(
      override.aes = list(size = 5)
    )
  )
    
ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(
      color = temp,
      size = pm10
    )
  ) +
  viridis::scale_color_viridis() +
  guides(
    size = guide_legend(order = 1),
    color = guide_colorbar(order = 2)
  )
    
ggplot(chic, aes(temp, o3)) +
  geom_point(
    aes(color = temp, size = pm10)
  ) +
  viridis::scale_color_viridis() +
  guides(
    color = guide_colorbar(
      direction = "vertical",
      barwidth = unit(0.3, "lines")
    ),
    size = guide_legend(
      nrow = 2,
      bins = 6,
      title.position = "top",
      label.position = "bottom"
    )
  ) +
  theme(legend.position = "bottom")
    
## Since ggplot 3.0.0 it is possible to modify aesthetics after the data has been transformed and mapped:
ggplot(chic, aes(season, o3)) +
  geom_boxplot(
    aes(
      color = season,
      fill = after_scale(alpha(color, .2))
    ),
    size = 1.2
  )

ggplot(chic, aes(season, o3)) +
  geom_boxplot(
    aes(
      color = season,
      fill = after_scale(colorspace::darken(color, .2))
    ),
    size = 1.2
  )

ggplot(chic, aes(season, o3)) +
  geom_boxplot(
    aes(
      color = season,
      fill = after_scale(ggdark::invert_color(color))
    ),
    size = 1.2
  )

## Note that one can also overwrite the same aesthetic (note that you have to put the aesthetic inside the geom):

ggplot(chic, aes(season, o3)) +
  geom_boxplot(
    aes(
      color = season,
      color = after_scale(darken(color, .3))
    ),
    size = 1.2,
    outlier.shape = NA
  ) +
  geom_jitter(
    aes(color = season),
    width = .15
  )
