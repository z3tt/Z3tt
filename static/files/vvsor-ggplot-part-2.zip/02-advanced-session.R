#------------------------------------------------------------------------------#
#                “Data Visualization in R — Part 2: Advanced”                 #
#                     Cédric Scherer | December 1, 2021                        #
#                                                                              #
#             “Data Visualization Workshop Series” presented by                #
#       Nederlandse Vereniging voor Statistiek & Operations Research           #
#------------------------------------------------------------------------------#

# The Setup --------------------------------------------------------------------

#install.packages("tidyverse")
#install.packages("scico")
#install.packages("rcartocolor")
#install.packages("colorspace")
#install.packages("systemfonts")
#install.packages("sf")
#install.packages("rnaturalearth")
#install.packages("ggforce")
#install.packages("ggtext")

library(tidyverse)

graham <- 
  readr::read_csv("https://raw.githubusercontent.com/Z3tt/ggplot-courses/master/data/caribous_graham.csv",
                  col_types = cols(season = col_factor(), sex = col_character()))

graham_ind <- graham %>% 
  dplyr::filter(animal_id == "GR_C12") %>% 
  dplyr::select(-animal_id, -sex)

tibble::glimpse(graham_ind)


# Recap ------------------------------------------------------------------------

ggplot(graham_ind, aes(longitude, latitude,
       fill = factor(year))) +
  geom_path(color = "grey67") +
  geom_point(shape = 21, size = 3)  

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67") +
  geom_point(
    aes(fill = factor(year)),
    shape = 21, size = 3
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67") +
  geom_point(
    aes(fill = factor(year)),
    shape = 21, size = 3
  ) +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  ) +
  scale_fill_manual(
    values = c("#215921", "#A5A580", "#9C6F1E"),
    name = NULL
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67") +
  geom_point(
    aes(fill = factor(year)),
    shape = 21, size = 3
  ) +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  ) +
  scale_fill_manual(
    values = c("#215921", "#A5A580", "#9C6F1E"),
    name = NULL
  ) +
  labs(  
    x = NULL, y = NULL, 
    title = "Trajectory of Caribou C12",
    caption = "Data: B.C. Ministry of Environment & Climate Change",
    tag = "1a." 
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_path(color = "grey67") +
  geom_point(
    aes(fill = factor(year)),
    shape = 21, size = 3
  ) +
  facet_wrap(~ season, ncol = 1) +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  ) +
  scale_fill_manual(
    values = c("#215921", "#A5A580", "#9C6F1E"),
    name = NULL
  ) +
  labs(
    x = NULL, y = NULL,
    title = "Trajectory of Caribou C12",
    caption = "Data: B.C. Ministry of Environment & Climate Change",
    tag = "1a."
  )


# Statistical Transformations --------------------------------------------------

ggplot(graham_ind,
       aes(longitude, latitude)) +
  stat_identity(geom = "point")

ggplot(graham_ind,
       aes(longitude, latitude)) +
  geom_point(stat = "identity")

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  stat_smooth()

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  stat_smooth(
    method = "lm",
    formula = y ~ x + I(x^2) + 
                  I(x^3) + I(x^4),
    se = FALSE
  )

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point() +
  geom_smooth(
    method = "lm",
    formula = y ~ x + I(x^2) +
                  I(x^3) + I(x^4),
    se = FALSE
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary()

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "pointrange" ## the default
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "errorbar"
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(
    fun.data = mean_se, ## the default
    geom = "errorbar",
    width = .3
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  geom_boxplot() +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  geom_boxplot() +
  geom_point(
    position = position_jitter(
      width = .1,
      seed = 1
    ),
    alpha = .1
  ) +
  stat_summary(
    fun = mean,
    size = 1,
    color = "#28a87d"
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(fun = mean) +
  stat_summary(
    geom = "errorbar",
    width = .3
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(fun = mean) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x), 
    fun.max = function(x) mean(x) + sd(x), 
    geom = "errorbar",
    width = .3
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(fun = mean) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    geom = "errorbar",
    width = .3
  ) +
  stat_summary(
    geom = "text",
    aes(label = round(..y.., 2))
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  stat_summary(fun = mean) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    geom = "errorbar",
    width = .3
  ) +
  stat_summary(
    geom = "text",
    aes(label = round(..y.., 2)),
    size = 5,
    hjust = -.4
  )

ggplot(graham_ind, aes(season, tree_cover, color = factor(year))) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x)
  )

ggplot(graham_ind, aes(season, tree_cover, color = factor(year))) +
  stat_summary(
    fun = mean,
    fun.min = function(x) mean(x) - sd(x),
    fun.max = function(x) mean(x) + sd(x),
    position = position_dodge(width = .5)
  )

ggplot(graham_ind, aes(factor(month))) +
  stat_count(fill = "grey67") +
  coord_flip()

ggplot(graham_ind, aes(factor(month))) +
  geom_bar(fill = "grey67") +
  coord_flip()

ggplot(graham_ind, aes(factor(month))) +
  stat_count(fill = "grey67") +
  stat_count(
    aes(label = ..count..),
    geom = "text",
    hjust = 1,
    position = position_nudge(y = -5)
  ) + 
  coord_flip()

ggplot(graham_ind, aes(forcats::fct_rev(factor(month)))) +
  stat_count(fill = "grey67") +
  stat_count(
    aes(label = ..count..), 
    geom = "text",
    hjust = 1, 
    position = position_nudge(y = -5)
  ) +  
  coord_flip()

ggplot(graham_ind, aes(forcats::fct_infreq(factor(month)))
  ) +
  stat_count(fill = "grey67") +
  stat_count(
    aes(label = ..count..),
    geom = "text",
    hjust = 1,
    position = position_nudge(y = -5)
  ) +
  coord_flip()

ggplot(graham_ind, aes(forcats::fct_rev(forcats::fct_infreq(factor(month))))
  ) +
  stat_count(fill = "grey67") +
  stat_count(
    aes(label = ..count..),
    geom = "text",
    hjust = 1,
    position = position_nudge(y = -5)
  ) +
  coord_flip()


# Custom Colors ----------------------------------------------------------------

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = tree_cover),
    size = 2
  ) +
  scale_color_viridis_c(
    option = "rocket",
    direction = -1,
    end = .9
  )

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = season),
    size = 2
  ) +
  scale_color_viridis_d(
    option = "turbo",
    end = .8
  )

scico::scico_palette_show()

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = tree_cover),
    size = 2
  ) +
  scico::scale_color_scico(
    palette = "romaO",
    limits = c(0, 100),
    name = "Tree Cover:",
    labels = scales::percent_format(scale = 1)
  ) 

ggplot(graham_ind, aes(season, tree_cover)) +
  geom_boxplot(
    aes(
      fill = season,
      color = after_scale(
        colorspace::darken(fill, .4)
    )),
    size = 2
  ) +
  ggsci::scale_fill_npg(
    guide = "none"
  )

ggplot(graham_ind, aes(season, tree_cover)) +
  geom_boxplot(
    aes(
      color = season,
      color = after_scale(
        colorspace::desaturate(color, .4)
    )),
    size = 2
  ) +
  ggsci::scale_color_npg(
    guide = "none"
  )

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = factor(year)),
    size = 2
  ) +
  rcartocolor::scale_color_carto_d(
    palette = "Bold"
  )

my_pal <- 
  rcartocolor::carto_pal(
    name = "Bold",
    n = 3
  )

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = factor(year)),
    size = 2
  ) +
  scale_color_manual(
    values = my_pal
  )

my_pal <-
  rcartocolor::carto_pal(
    name = "Bold",
    n = 4
  )[1:3]

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = factor(year)),
    size = 2
  ) +
  scale_color_manual(
    values = my_pal
  )

my_pal <-
  colorRampPalette(
    c("grey85", "#c49c67", "#134c13")
  )

ggplot(graham_ind, aes(date, tree_cover)) +
  geom_point(
    aes(color = tree_cover),
    size = 2
  ) +
  scale_color_gradientn(
    colors = my_pal(100)
  )


# Custom Legends (Guides) ------------------------------------------------------

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_hex(aes(color = ..count..)) +
  scale_color_distiller(
    palette = "YlOrBr",
    guide = "none"
  ) +
  scale_fill_distiller(
    palette = "YlOrBr",
    guide = "none"
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_hex(aes(color = ..count..)) +
  scale_color_distiller(
    palette = "YlOrBr",
    guide = "colorbar"
  ) +
  scale_fill_distiller(
    palette = "YlOrBr",
    guide = "legend"
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_hex(aes(color = ..count..)) +
  scale_color_distiller(
    palette = "YlOrBr",
    guide = "colorsteps"
  ) +
  scale_fill_distiller(
    palette = "YlOrBr",
    guide = "bins"
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  guides(
    color = "legend"
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  guides(
    color = guide_legend()
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  guides(
    color = guide_legend(
      override.aes = list(
        size = 5,
        shape = 18
      )
    )
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  guides(
    color = guide_colorbar(
      direction = "horizontal",
      title.position = "top",
      label.position = "top",
      barwidth = unit(4.5, "lines"),
      barheight = unit(.3, "lines"),
    )
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  theme(legend.position = c(.2, .2))

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  theme(legend.position = "top")

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  theme(
    legend.position = "top",
    legend.key.height = unit(.5, "lines"),
    legend.key.width = unit(4, "lines")
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point(
    aes(color = tree_cover)
  ) +
  scale_color_viridis_c() +
  theme(
    legend.position = "top",
    legend.key.height = unit(.5, "lines"),
    legend.key.width = unit(4, "lines")
  ) +
  guides(color = guide_colorbar(
    title.position = "top"
  ))


# Custom Theming ---------------------------------------------------------------

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  theme_classic(base_size = 20)

theme_set(theme_classic(base_size = 20))
ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point()

theme_set(theme_light(base_size = 16, base_family = "Roboto Condensed"))

theme_grey

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  theme(
    panel.background = element_rect(
      color = "black",
      fill = "orange",
      size = 2,
      linetype = "dotted"
    )
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  theme(
    axis.line.x = element_line(
      color = "red",
      size = 1,
      linetype = "dashed",
      lineend = "square", # round, butt 
      arrow = arrow(
        angle = 30, 
        length = unit(.2, "inches"),
        type = "closed"
      )
    )
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  theme(
    axis.title = element_text(
      family = "Roboto",
      face = "bold", ## plain, italic, bolditalic
      size = 24,
      color = "firebrick",
      lineheight = .7,
      angle = 180,
      hjust = .5,
      vjust = .0,
      margin = margin(10, ## t (top)
                      0,  ## r (right)
                      30, ## b (bottom)
                      0)  ## l (left)
    )
  )


# Custom Fonts -----------------------------------------------------------------

library(systemfonts)

system_fonts() %>% 
  filter(str_detect(family, "Roboto")) %>% 
  pull(name)

register_variant(
  name = "Roboto Black", 
  family = "Roboto", 
  weight = "heavy"
)

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  labs(
    title = "Movement Trajectory of Caribou GR C12",
    caption = "Data: B.C. Ministry of Environment & Climate Change"
  ) +
  theme_dark(
    base_size = 20,
    base_family = "Roboto Black"
  )

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  labs(
    title = "Movement Trajectory of Caribou GR C12",
    caption = "Data: B.C. Ministry of Environment & Climate Change"
  ) +
  theme_dark(
    base_size = 20,
    base_family = "Roboto Black"
  ) +
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.caption = element_text(hjust = 0)
  )

theme_update(
  panel.grid.major.x = element_line(color = "red"),
  panel.grid.major.y = element_line(color = "blue"),
  panel.grid.minor = element_blank()
)

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point()

theme_set(theme_light(base_size = 16, base_family = "Roboto Condensed"))

theme_dark

theme_ugly <-
  function(base_size = 24, ...) {
    theme_dark(base_size = base_size) %+replace% 
      theme(
        text = element_text(
          color = "coral1", family = "Sniglet", 
          size = base_size
        ),
        axis.text = element_text(color = "grey80", size = rel(.7)),
        axis.ticks = element_line(color = "grey90"),
        plot.title = element_text(
          color = "red", size = rel(1.5), lineheight = 1.2,
          margin = margin(base_size, 0, base_size * 2, 0)
        ),
        plot.title.position = "plot",
        panel.grid = element_line(color = "red", linetype = "4127"),
        plot.background = element_rect(fill = "grey10", color = "red", size = 5),
        plot.margin = margin(rep(25, 4)),
        legend.background = element_rect(fill = "black", color = "red", size = 2)
      )
} 

ggplot(graham_ind, aes(longitude, latitude)) +
  geom_point() +
  labs(title = "My Fancy Title") +
  theme_ugly()


# Maps -------------------------------------------------------------------------

library(sf)
library(rnaturalearth)

sf_world <- ne_countries(returnclass = "sf")

tibble::glimpse(sf_world)

ggplot(sf_world) +
  geom_sf()

ggplot(sf_world) + 
  geom_sf(aes(fill = continent), color = "white")

ggplot(sf_world) +
  geom_sf(aes(fill = continent), color = "white") +
  coord_sf(crs = "+proj=moll")

sf_graham <- 
  sf::st_as_sf(
    graham_ind,
    coords = c("longitude", "latitude"),
    crs = sf::st_crs(4326)
  )

sf_graham

ggplot(sf_graham) +
  geom_sf()

ggplot(sf_graham) +
  geom_sf(aes(color = tree_cover), shape = 1, size = 4) +
  scale_color_viridis_c()

ggplot(sf_graham) +
  geom_sf(aes(color = tree_cover), shape = 1, size = 4) +
  coord_sf(crs = "+proj=moll")

ggplot(sf_graham) +
  geom_sf(aes(color = tree_cover), shape = 1, size = 4) +
  coord_sf(crs = sf::st_crs(4267))


# Bringing it all together -----------------------------------------------------

g <- 
  ggplot(filter(graham, animal_id %in% c("GR_C12", "GR_C13", "GR_C14")),
         aes(animal_id, tree_cover, color = season)) +
  ggforce::geom_sina(
    aes(color = season, color = after_scale(colorspace::lighten(color, .6))),
    position = position_dodge(width = .8), 
    scale = "count",
    alpha = .5, size = 2
  ) +
  stat_summary(
    aes(color = season, color = after_scale(colorspace::darken(color, .1))),
    position = position_dodge(width = .8),
    fun = mean,
    fun.min = function(x) mean(x) - sd(x), 
    fun.max = function(x) mean(x) + sd(x),
    size = 1
  ) +
  stat_summary(
    aes(label = paste0(round(..y.., 1), "%"), 
        color = season, color = after_scale(colorspace::darken(color, .1))),
    position = position_dodge(width = .8),
    geom = "text", 
    size = 6, hjust = -.3, fontface = "bold", family = "Amulya"
  ) 

g <- g +
  facet_wrap(~animal_id, scales = "free_x") +
  coord_cartesian(expand = FALSE) +
  scale_x_discrete(guide = "none") +
  scale_y_continuous(
    limits = c(NA, 100), 
    breaks = 0:5*20,
    labels = scales::percent_format(scale = 1)
  ) +
  rcartocolor::scale_color_carto_d(
    palette = "Bold", 
    name = NULL
  ) +
  guides(
    color = guide_legend(
      override.aes = list(size = .8),
      keyheight = unit(3, "lines"))
  ) +
  labs(
    x = NULL, 
    y = "Tree Cover",
    title = "Patterns in Tree Cover Usage by Northern Caribous (*Rangifer tarandus caribou*)",
    subtitle = "Tree cover was extracted for each of the 4.532 locations recorded for three female Northern Caribous<br>tracked in Graham, Canada, between 2001 and 2003. **Errorbars show mean \u00b1 standard deviation.**",
    caption = "Data: B.C. Ministry of Environment & Climate Change"
  ) 

g +
  theme_minimal(base_size = 22, base_family = "Amulya") +
  theme(
    legend.position = "top",
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.spacing = unit(2, "lines"),
    strip.text = element_text(
      face = "bold", size = 20
    ),
    axis.title.x.top = element_text(
      face = "bold"
    ),
    plot.title = ggtext::element_markdown(
      family = "Playfair Display", face = "bold", size = 27
    ),
    plot.subtitle = ggtext::element_markdown(
      size = 20, lineheight = 1.3
    ),
    plot.caption = element_text(
      margin = margin(t = 40), color = "grey30", size = 12
    ),
    plot.title.position = "plot",
    plot.margin = margin(rep(25, 4))
  )

ggsave("tree-cover-patterns.pdf", width = 15, height = 9, device = cairo_pdf)
ggsave("tree-cover-patterns.png", width = 15, height = 9, dpi = 600)

################################################################################
